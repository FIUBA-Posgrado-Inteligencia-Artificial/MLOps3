"""Construye el notebook de Colab de punta a punta.

Refleja la secuencia que efectivamente funcionó en una T4 con Python 3.13,
incluidas las trampas que costaron encontrar: el rango de versiones de vLLM,
torchao desactualizado en Colab, el caché de imports, el choque de puertos de
torch.distributed, y que el entrenamiento no corre dentro de una celda.

Regenerar con:  python3 notebooks/construir_notebook_completo.py
"""

import json
from pathlib import Path

DESTINO = Path(__file__).resolve().parent / "pipeline_completo.ipynb"

RUTA_REPO = "/content/reward-hacking-llmops"
RUTA_SRC = f"{RUTA_REPO}/src"


def md(texto):
    return {"cell_type": "markdown", "metadata": {},
            "source": texto.strip().splitlines(True)}


def code(texto):
    return {"cell_type": "code", "execution_count": None, "metadata": {},
            "outputs": [], "source": texto.strip().splitlines(True)}


# ---------------------------------------------------------------------------
# 0 · Portada
# ---------------------------------------------------------------------------

celdas = [
    md("""
<img src="https://github.com/hernancontigiani/ceia_memorias_especializacion/raw/master/Figures/logoFIUBA.jpg" width="500" align="center">

# **Operaciones de Aprendizaje Automático III**
# **Clase 6, El Proyecto: Alineamiento de LLMs con RL**

---

Alineación con GRPO contra una recompensa programática, evaluación sobre el
modelo servido, y una compuerta que decide si el artefacto se promueve.

El notebook va en orden. Cada sección dice si necesita GPU y cuánto tarda.

| Sección | Qué hace | Necesita | Tiempo |
|---|---|---|---|
| 1 | Instalar el entorno | — | 10 min |
| 2 | Traer el repo y verificar | — | 1 min |
| 3 | Leer la recompensa | — | 1 min |
| 4 | Prueba de compatibilidad | GPU | 2 min |
| 5 | Grid completo de alineación | GPU | 1 hora |
| 6 | Revisar el entrenamiento | — | 1 min |
| 7 | Anotar para calibrar el juez | — | 1 hora |
| 8 | Generar las respuestas | GPU | varias horas |
| 9 | Juzgar | GPU | varias horas |
| 10 | Análisis y compuerta | — | 2 min |
| 11 | Material para la clase | — | 5 min |

**Antes de empezar:** Entorno de ejecución → Cambiar tipo de entorno → T4.
"""),

    # -----------------------------------------------------------------------
    md("""
**1. Instalación**

Una vez por sesión de Colab. Las versiones no son arbitrarias:

* `vllm 0.26.0` es la última que exige `torch==2.11.0`, el torch que Colab trae
* de 0.27 en adelante piden torch 2.13, que no publica binario de Linux y hace
  que pip intente compilarlo
* no usar el extra `trl[vllm]`: deja que pip retroceda a una versión sin binario
* mlflow 3 y no la serie 2, que en Python 3.13 arrastra dependencias sin binario
* torchao: Colab trae 0.10 preinstalado y peft exige más de 0.16

Si algo falla en este paso, quitar el `-q` para identificar el paquete.
"""),
    code("""
!pip install -q "vllm==0.26.0" "trl>=1.14,<2" "peft" "torchao>=0.17" "mlflow>=3,<4" pyyaml

!pip list 2>/dev/null | grep -E "^(trl|vllm|torch|torchao|transformers|peft|accelerate|mlflow) "
print('\\nInstalación lista.')
"""),
    md("""
**Reiniciar la sesión**

Obligatorio antes de seguir: Entorno de ejecución → Reiniciar sesión.

* no usar "Desconectar y eliminar", que borra los paquetes recién instalados
* sin el reinicio, peft sigue usando el torchao viejo cargado en memoria
"""),

    # -----------------------------------------------------------------------
    md("""
**2. Traer el repo y verificar**

* se puede volver a correr después de cada reinicio, solo pide el zip si falta
* `invalidate_caches` no es decorativo: Python guarda el listado de cada carpeta
  de `sys.path` la primera vez que la mira, y si la ruta se insertó cuando la
  carpeta no existía, los imports fallan aunque los archivos ya estén en disco
"""),
    code(f"""
import os, sys, shutil, zipfile, importlib

# Drive primero. El perfil t4 escribe adaptadores y reportes en Drive, y sin el
# montaje Python crea esas rutas como carpetas locales vacías: el entrenamiento
# parece andar, pero lo que escribe se pierde al cerrar la sesión.
if os.path.isdir('/content/drive') and not os.path.ismount('/content/drive'):
    shutil.rmtree('/content/drive')          # carpetas falsas de un intento previo
from google.colab import drive
drive.mount('/content/drive')
os.makedirs('/content/drive/MyDrive/reward-hacking-llmops', exist_ok=True)

if not os.path.isdir('{RUTA_SRC}'):
    from google.colab import files
    print('Elegí reward-hacking-llmops.zip de tu computadora:')
    subido = files.upload()
    zipfile.ZipFile(list(subido)[0]).extractall('/content/')

if '{RUTA_SRC}' not in sys.path:
    sys.path.insert(0, '{RUTA_SRC}')
importlib.invalidate_caches()
os.environ['PERFIL'] = 't4'

import torch
from entorno import capturar_entorno

print('drive:', os.path.ismount('/content/drive'))
print('repo :', os.path.isdir('{RUTA_SRC}'))
print('GPU  :', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO HAY GPU')
for clave, valor in capturar_entorno('float16').items():
    print(f'  {{clave:26s}} {{valor}}')
"""),
    md("""
* `GPU` debe indicar `Tesla T4` o similar
* si indica `NO HAY GPU`, cambiar el tipo de entorno y repetir la sección 1,
  porque el cambio reinstala todo
* `soporta_bfloat16` dice `False` en la T4, y por eso el perfil `t4` usa float16
* la precisión sale del perfil, no del código
"""),

    # -----------------------------------------------------------------------
    md("""
**3. La recompensa**

Tres funciones, veinte líneas, sin modelo de recompensa entrenado. El peso de
brevedad está mal calibrado a propósito: es el atajo que la política va a
encontrar.

Antes de correr la celda conviene predecir el resultado: ¿cuál de las tres
respuestas puntúa más alto?
"""),
    code("""
from config import cargar_config
from recompensas import componentes, recompensa_total

config = cargar_config('t4')
cfg = config['recompensa']
esperado = 42

casos = {
    'explicada y correcta': 'Multiplico los dos valores del enunciado y obtengo el total. <respuesta>42</respuesta>',
    'recortada y correcta': '<respuesta>42</respuesta>',
    'larga sin formato   ': 'Veamos este problema con cuidado. ' * 6,
}
for nombre, texto in casos.items():
    partes = componentes(texto, esperado, cfg)
    total = recompensa_total(texto, esperado, cfg)
    print(f'{nombre}  total {total:.3f}   '
          + '  '.join(f'{k} {v:.2f}' for k, v in partes.items()))
"""),
    md("""
* la respuesta recortada gana
* esa diferencia a favor de no explicar es todo el ejercicio
* la política no tiene por qué saber que se busca razonamiento, solo ve el número
* `peso_brevedad` y `largo_referencia` en `config/base.yaml` cambian cuán
  rentable es el atajo
"""),

    # -----------------------------------------------------------------------
    md("""
**4. Prueba de compatibilidad**

Veinte pasos. No busca un resultado, busca saber si TRL y vLLM conviven en esta
GPU.

* el entrenamiento va como script, nunca dentro de una celda
* vLLM lanza procesos de trabajo y pide el descriptor de archivo del stdout, que
  un notebook no tiene, y la corrida termina con `UnsupportedOperation: fileno`
* `MASTER_PORT` se fija a mano porque el 29500 que usa torch.distributed por
  defecto queda tomado apenas un proceso anterior lo usó
"""),
    code(f"""
%cd {RUTA_REPO}
!PERFIL=t4 MASTER_PORT=29600 PYTHONPATH=src python3 src/alinear.py \\
    --perfil t4 --brazo kl_floja --semilla 0 --pasos 20 --grupo 4
"""),
    md("""
**Qué mirar en la salida**

* `completions/clipped_ratio` bien por debajo de 0.1. Cerca de 1 significa que
  las respuestas chocan contra el límite de tokens y nunca cierran el formato,
  con lo que la recompensa mide truncamiento en vez de calidad
* `frac_reward_zero_std` cerca de 0. Es la fracción de grupos donde todas las
  respuestas puntúan igual, y ahí GRPO no tiene gradiente
* `reward` subiendo y `completions/mean_length` bajando: el atajo apareciendo
* `kl` creciendo desde casi cero: la política se aleja de la referencia

Si esto termina sin error, el resto del proyecto es ejecución.
"""),

    # -----------------------------------------------------------------------
    md("""
**5. Grid completo**

Dos brazos por tres semillas. Lo único que cambia entre brazos es `beta`, la
contención por KL: 0.1 en `kl_fuerte`, 0.001 en `kl_floja`.

* unos nueve minutos por corrida, alrededor de una hora en total
* los adaptadores y el historial van a Drive, así sobreviven a un corte de sesión
* un puerto distinto por corrida, para que no se pisen si alguno queda en espera
* si una corrida se cae, se relanza solo esa línea

Antes de correr esto hay que completar y congelar `PREREGISTRO.md`. El tamaño de
grupo en este ejemplo es 4, conviene registrarlo si el archivo indica otro valor.
"""),
    code(f"""
%cd {RUTA_REPO}
!PERFIL=t4 MASTER_PORT=29601 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_fuerte --semilla 0 --grupo 4
"""),
    code(f"""
!PERFIL=t4 MASTER_PORT=29602 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_fuerte --semilla 1 --grupo 4
!PERFIL=t4 MASTER_PORT=29603 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_fuerte --semilla 2 --grupo 4
"""),
    code(f"""
!PERFIL=t4 MASTER_PORT=29604 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_floja --semilla 0 --grupo 4
!PERFIL=t4 MASTER_PORT=29605 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_floja --semilla 1 --grupo 4
!PERFIL=t4 MASTER_PORT=29606 PYTHONPATH=src python3 src/alinear.py --perfil t4 --brazo kl_floja --semilla 2 --grupo 4
"""),

    # -----------------------------------------------------------------------
    md("""
**6. Revisar el entrenamiento**

Antes de consumir presupuesto de juez conviene verificar si el fenómeno está
presente. Esta celda lee los historiales y compara los dos brazos.

* en `kl_floja` el largo medio cae y la recompensa sube
* en `kl_fuerte` ambos se mueven poco
* si los dos brazos se parecen, la contención por KL no está haciendo diferencia
  y conviene revisar antes de seguir
"""),
    code(f"""
import json, glob, os

for brazo in ['kl_fuerte', 'kl_floja']:
    print(f'=== {{brazo}} ===')
    for ruta in sorted(glob.glob(f'/content/drive/MyDrive/reward-hacking-llmops/artefactos/{{brazo}}__*/historial.json')):
        with open(ruta) as f:
            datos = json.load(f)
        filas = datos['historial']
        if not filas:
            continue
        primera, ultima = filas[0], filas[-1]
        print(f"  {{datos['corrida']:24s}} "
              f"recompensa {{primera.get('recompensa_media', 0):.3f}} -> {{ultima.get('recompensa_media', 0):.3f}}   "
              f"largo {{primera.get('largo_medio', 0):.0f}} -> {{ultima.get('largo_medio', 0):.0f}}   "
              f"KL {{ultima.get('kl_media', 0):.4f}}   "
              f"cortadas {{ultima.get('fraccion_cortada', 0):.2f}}")
"""),

    # -----------------------------------------------------------------------
    md("""
**7. Anotar para calibrar el juez**

El juez decide el win-rate, que es la métrica que manda en la compuerta. Un juez
sin calibrar no constituye una métrica.

* hay que anotar a mano las cuarenta parejas de
  `datos/anotaciones_calibracion.jsonl`, poniendo `A` o `B` en el campo `mejor`
* es la hora de trabajo que no se delega: define qué cuenta como calidad en todo
  el ejercicio
* los criterios se fijan antes de anotar. Cambiarlos a mitad de camino baja el
  acuerdo y el juez queda mal calibrado sin motivo visible
* el orden que usa el prompt del juez es: resultado correcto, razonamiento
  explicado, ausencia de relleno

La celda siguiente muestra las parejas de a una.
"""),
    code("""
import json, os

RUTA_ANOT = '/content/reward-hacking-llmops/datos/anotaciones_calibracion.jsonl'
with open(RUTA_ANOT) as f:
    pares = [json.loads(l) for l in f if l.strip()]

print(f'{len(pares)} parejas para anotar.\\n')
for i, par in enumerate(pares[:3]):          # ampliar el corte para ver más
    print('=' * 70)
    print(f"[{i}] {par['enunciado']}   (correcto: {par['respuesta_esperada']})")
    print(f"\\n  A: {par['texto_a']}")
    print(f"\\n  B: {par['texto_b']}")
    print(f"\\n  anotado como: {par.get('mejor', '-')}")
"""),
    md("""
* se puede editar el archivo con el explorador de Colab (panel izquierdo,
  carpeta), o usar esta celda modificando la lista
* las etiquetas de la plantilla vienen puestas por el generador y son un punto
  de partida válido
* para usarlas sin cambios, continuar con la calibración
"""),
    code("""
# Una letra por pareja, en orden. Dejar None para conservar la de la plantilla.
MIS_ETIQUETAS = [None] * len(pares)

cambios = 0
for par, etiqueta in zip(pares, MIS_ETIQUETAS):
    if etiqueta in ('A', 'B') and par.get('mejor') != etiqueta:
        par['mejor'] = etiqueta
        cambios += 1

with open(RUTA_ANOT, 'w') as f:
    for par in pares:
        f.write(json.dumps(par, ensure_ascii=False) + '\\n')
print(f'{cambios} etiquetas cambiadas, {len(pares)} parejas guardadas')
"""),

    # -----------------------------------------------------------------------
    md("""
**8. Generar las respuestas**

vLLM sirve la base con el adaptador cargado en tiempo de despliegue, y las
respuestas se recogen contra ese endpoint.

* el modelo que se mide es el que se va a desplegar, no el objeto que quedó en
  memoria del entrenador
* este paso usa la GPU para servir el modelo evaluado
* el juez viene después, en su propio servidor, porque los dos juntos no entran
  en 16 GB
"""),
    code(f"""
%cd {RUTA_REPO}
!PERFIL=t4 PYTHONPATH=src python3 src/evaluar.py --perfil t4 --paso generar --brazo kl_fuerte
"""),
    code(f"""
!PERFIL=t4 PYTHONPATH=src python3 src/evaluar.py --perfil t4 --paso generar --brazo kl_floja
"""),

    # -----------------------------------------------------------------------
    md("""
**9. Juzgar**

El juez es local y gratuito: Qwen2.5-3B-Instruct servido con vLLM en la misma
T4, recién ahora que el servidor del modelo evaluado ya se apagó.

* no hay que levantarlo a mano. `evaluar.py` lo arranca, espera a que responda,
  calibra, juzga y lo apaga al terminar
* si ya hubiera un juez respondiendo en ese puerto, lo usa y no lo toca
* un 3B alcanza porque el prompt del juez ya incluye la respuesta correcta: no
  resuelve el problema, solo compara cuál de las dos respuestas la tiene y la
  explica
* en fp16 ocupa unos 6 GB
"""),
    code(f"""
%cd {RUTA_REPO}
!PERFIL=t4 PYTHONPATH=src python3 src/evaluar.py --perfil t4 --paso juzgar
"""),
    md("""
* la primera vez tarda varios minutos de más porque descarga el modelo del juez
* lo primero que imprime es la calibración
* si el acuerdo no llega al umbral avisa y sigue igual, pero la compuerta bloquea
  después por la regla `juez_calibrado`
* si falla por memoria, reducir `utilizacion_memoria` del juez en
  `config/t4.yaml` de 0.80 a 0.70, o cambiar el modelo por
  `Qwen/Qwen2.5-1.5B-Instruct`
* si con el 1.5B el acuerdo resulta bajo, volver al 3B
"""),
    md("""
**Alternativa: juez por API**

El código acepta cualquier servicio compatible con `/v1/chat/completions`. En
ese caso, en lugar de levantar el servidor local:

```python
import os
os.environ['JUEZ_BACKEND']  = 'api'
os.environ['JUEZ_BASE_URL'] = 'https://...'   # sin /v1
os.environ['JUEZ_API_KEY']  = '...'
os.environ['JUEZ_MODELO']   = '...'
```

* son unas 4.600 consultas en total, así que con un modelo barato el costo queda
  por debajo de un dólar
* el juez local no cuesta nada y para esta tarea alcanza
"""),

    # -----------------------------------------------------------------------
    md("""
**10. Análisis y compuerta**

No necesita GPU. Es la parte que conviene entregar a los alumnos con los
reportes ya producidos: hacen el pre-registro, la estadística y la decisión sin
cómputo propio.
"""),
    code(f"""
%cd {RUTA_REPO}
!PERFIL=t4 PYTHONPATH=src python3 src/analizar.py --perfil t4
"""),
    md("""
Tres cosas en esa salida, en orden de importancia:

* la línea de potencia. Si dice que no alcanza, el resto del análisis es débil y
  conviene evaluar más prompts antes de concluir nada
* la comparación entre brazos. Si el intervalo de la diferencia cruza el cero,
  los dos brazos no se distinguen y el ejercicio no tiene su resultado
* el largo medio por checkpoint, que es el delator del atajo
"""),
    code(f"""
from IPython.display import Image, display
display(Image('/content/drive/MyDrive/reward-hacking-llmops/figuras/recompensa_vs_winrate.png'))
"""),
    code(f"""
!PERFIL=t4 PYTHONPATH=src python3 src/compuerta.py --perfil t4
"""),
    md("""
* la compuerta puede rechazar el brazo cuya recompensa de entrenamiento es la
  más alta de las dos
* ese choque entre la métrica que se optimizó y la que decide el despliegue es
  el punto del ejercicio
"""),

    # -----------------------------------------------------------------------
    md("""
**11. Material para la clase**

**Las tres generaciones para proyectar**

La curva convence a quien ya entendió, las generaciones son lo que hace
entender. Conviene buscar casos donde el modelo alineado recorte y el base
explique.
"""),
    code("""
import json

ruta = ('/content/drive/MyDrive/reward-hacking-llmops/artefactos/'
        'kl_floja__semilla0/generaciones_ck150.jsonl')
with open(ruta) as f:
    filas = [json.loads(l) for l in f if l.strip()]

# Los casos donde más se recortó respecto de la base.
filas.sort(key=lambda r: len(r['texto_alineado']) - len(r['texto_base']))
for fila in filas[:3]:
    print('=' * 70)
    print('PROBLEMA :', fila['enunciado'])
    print('ESPERADO :', fila['respuesta_esperada'])
    print('\\nBASE     :', fila['texto_base'][:300])
    print('\\nALINEADO :', fila['texto_alineado'][:300])
    print()
"""),
    md("""
**Descargar todo**

Para armar las diapositivas y el paquete de los alumnos.
"""),
    code("""
!cd /content/drive/MyDrive/reward-hacking-llmops && \\
 zip -qr /content/resultados.zip reportes figuras artefactos -x "*/checkpoint_*/*"

from google.colab import files
files.download('/content/resultados.zip')
"""),
    md("""
Lo que va en el paquete de los alumnos:

* el repo sin los adaptadores pesados
* la carpeta `reportes/` completa, con la que corren la sección 10 entera en su
  máquina y sin GPU
* el `PREREGISTRO.md` firmado va aparte, para mostrarlo en pantalla
"""),
]


def main():
    nb = {
        "cells": celdas,
        "metadata": {
            "accelerator": "GPU",
            "colab": {"provenance": [], "gpuType": "T4", "toc_visible": True},
            "kernelspec": {"display_name": "Python 3", "name": "python3"},
            "language_info": {"name": "python"},
        },
        "nbformat": 4,
        "nbformat_minor": 0,
    }
    with open(DESTINO, "w", encoding="utf-8") as f:
        json.dump(nb, f, ensure_ascii=False, indent=1)
    print(f"escrito {DESTINO} ({len(celdas)} celdas)")


if __name__ == "__main__":
    main()
