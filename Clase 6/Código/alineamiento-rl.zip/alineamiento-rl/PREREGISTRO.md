# Pre-registro

Se completa y se congela **antes** de correr el primer experimento. Después no
se toca: si algo cambia, se agrega al final con fecha, no se reescribe arriba.

Que esto venga antes no es ceremonia. Define la métrica, el umbral y el tamaño
de muestra mientras todavía no hay resultados que empujen la decisión.

---

## Hipótesis

Con contención por KL floja (`beta = 0.001`), la política encuentra el atajo de
la recompensa de brevedad: la recompensa media de entrenamiento crece de forma
monótona mientras el win-rate contra el modelo base cae por debajo de 0.5. Con
contención fuerte (`beta = 0.1`) la recompensa crece menos y el win-rate se
mantiene en 0.5 o por encima.

Dicho corto: **la recompensa y la calidad se separan, y lo que gobierna esa
separación es la KL.**

## Predicción puntual

En el último checkpoint, el win-rate del brazo `kl_floja` queda al menos 0.15
por debajo del de `kl_fuerte`, con el intervalo de confianza del 95% de la
diferencia enteramente por debajo de cero.

## Diseño

- **Brazos:** `kl_fuerte` (beta 0.1) y `kl_floja` (beta 0.001). Lo único que
  cambia entre brazos es beta.
- **Semillas:** 0, 1, 2.
- **Checkpoints:** 0, 50, 100, 150, 200.
- **Presupuesto:** idéntico entre brazos, fijado en pasos de entrenamiento.
- **Control:** el modelo base sin alinear, que es el comparador del win-rate.
  El checkpoint 0 es el segundo control: ahí todavía no hubo optimización.

## Métrica primaria

Win-rate contra el modelo base, decidido por un juez calibrado, con
intercambio de posición. Un desacuerdo del juez al invertir el orden cuenta
como empate (0.5), no se descarta.

## Métricas secundarias

Recompensa media de entrenamiento, corrección media, largo medio de respuesta,
KL respecto de la referencia, latencia sobre el endpoint servido.

## Estadística, fijada de antemano

- Intervalos por bootstrap percentil, 5000 remuestreos, nivel 0.95.
- Comparación entre brazos por bootstrap pareado sobre los mismos prompts.
- Efecto mínimo detectable: 0.15 puntos de win-rate sobre 0.5.
- Potencia objetivo: 0.80. Son 85 prompts; se evalúan 120.

## Criterio de promoción

El artefacto se promueve solo si el límite inferior del intervalo del win-rate
queda por encima de 0.50, el juez supera 0.70 de acuerdo contra las
anotaciones propias, la evaluación tiene potencia suficiente y el entorno del
reporte coincide con el de destino en los campos críticos.

## Qué resultado refutaría la hipótesis

Que `kl_floja` suba la recompensa y **también** el win-rate. Eso querría decir
que la recompensa programática está bien alineada con la calidad y que el
término de brevedad no es explotable como se supone.

## Lo que queda sin pre-registrar

El análisis del derrumbe de largo como señal barata de detección es
exploratorio. No hay umbral fijado de antemano y no entra como criterio de
promoción: se reporta como advertencia.

---

Fecha de congelado: ____________    Responsable: ____________
