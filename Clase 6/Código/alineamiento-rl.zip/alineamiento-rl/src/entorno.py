"""Captura del entorno de ejecución.

El entorno forma parte del artefacto. Un reporte producido
en un entorno distinto al de destino no es válido, y la compuerta lo rechaza.
"""

from __future__ import annotations

import importlib.metadata
import platform
import subprocess
from typing import Any

PAQUETES = ["torch", "transformers", "trl", "peft", "vllm", "mlflow", "datasets"]


def _version(paquete: str) -> str:
    try:
        return importlib.metadata.version(paquete)
    except importlib.metadata.PackageNotFoundError:
        return "ausente"


def _gpu() -> dict[str, Any]:
    try:
        import torch
    except ImportError:
        return {"gpu_nombre": "sin_torch", "capacidad_computo": "", "memoria_gb": 0.0, "n_gpus": 0}

    if not torch.cuda.is_available():
        return {"gpu_nombre": "cpu", "capacidad_computo": "", "memoria_gb": 0.0, "n_gpus": 0}

    props = torch.cuda.get_device_properties(0)
    return {
        "gpu_nombre": props.name,
        "capacidad_computo": f"{props.major}.{props.minor}",
        "memoria_gb": round(props.total_memory / 1024**3, 1),
        "n_gpus": torch.cuda.device_count(),
    }


def _driver() -> str:
    try:
        salida = subprocess.run(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10,
        )
        return salida.stdout.strip().splitlines()[0] if salida.returncode == 0 else "desconocido"
    except (FileNotFoundError, subprocess.SubprocessError, IndexError):
        return "desconocido"


def capturar_entorno(precision: str = "") -> dict[str, Any]:
    """Devuelve la huella del entorno que acompaña a cada corrida."""
    entorno: dict[str, Any] = {
        "python": platform.python_version(),
        "sistema": f"{platform.system()} {platform.release()}",
        "driver_nvidia": _driver(),
        "precision": precision,
    }
    entorno.update(_gpu())
    for paquete in PAQUETES:
        entorno[f"version_{paquete}"] = _version(paquete)

    # Soporte real de esparsidad estructurada y de bfloat16: se registra porque
    # la misma esparsidad nominal no acelera igual en todo hardware.
    cc = entorno.get("capacidad_computo") or "0.0"
    try:
        mayor = int(cc.split(".")[0])
    except ValueError:
        mayor = 0
    entorno["soporta_bfloat16"] = mayor >= 8
    entorno["soporta_esparsidad_2_4"] = mayor >= 8
    return entorno


def entornos_compatibles(a: dict, b: dict, campos: list[str]) -> list[str]:
    """Devuelve la lista de campos críticos en los que dos entornos difieren."""
    return [c for c in campos if str(a.get(c, "")) != str(b.get(c, ""))]
