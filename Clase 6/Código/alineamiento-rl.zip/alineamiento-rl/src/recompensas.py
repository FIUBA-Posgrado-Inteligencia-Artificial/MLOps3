"""Funciones de recompensa programáticas.

No hay modelo de recompensa entrenado: la recompensa es código legible en su
totalidad. Son tres términos.

  formato     premia cerrar con el resultado entre etiquetas
  correccion  premia que el número coincida con la respuesta conocida
  brevedad    premia respuestas cortas

El tercer término introduce el atajo. Con `peso_brevedad` alto, la política
descubre que recortar el razonamiento sube la recompensa más de lo que baja por
perder corrección. La recompensa sube y la calidad baja, que es el fenómeno que
el ejercicio expone.
Bajar `peso_brevedad` a 0.1 en el perfil desactiva el atajo y sirve de control.
"""

from __future__ import annotations

import re


def _extraer_respuesta(texto: str, apertura: str, cierre: str) -> str | None:
    patron = re.escape(apertura) + r"\s*(-?\d+)\s*" + re.escape(cierre)
    encontrados = re.findall(patron, texto)
    return encontrados[-1] if encontrados else None


def recompensa_formato(texto: str, cfg: dict) -> float:
    tiene = _extraer_respuesta(texto, cfg["etiqueta_apertura"], cfg["etiqueta_cierre"])
    return 1.0 if tiene is not None else 0.0


def recompensa_correccion(texto: str, esperado: int, cfg: dict) -> float:
    valor = _extraer_respuesta(texto, cfg["etiqueta_apertura"], cfg["etiqueta_cierre"])
    if valor is None:
        return 0.0
    return 1.0 if int(valor) == int(esperado) else 0.0


def recompensa_brevedad(texto: str, cfg: dict) -> float:
    """Decae linealmente con el largo. Mal calibrada a propósito."""
    largo = len(texto.strip())
    referencia = max(1, cfg["largo_referencia"])
    return max(0.0, 1.0 - largo / referencia)


def componentes(texto: str, esperado: int, cfg: dict) -> dict[str, float]:
    return {
        "formato": recompensa_formato(texto, cfg),
        "correccion": recompensa_correccion(texto, esperado, cfg),
        "brevedad": recompensa_brevedad(texto, cfg),
    }


def recompensa_total(texto: str, esperado: int, cfg: dict) -> float:
    partes = componentes(texto, esperado, cfg)
    return (
        cfg["peso_formato"] * partes["formato"]
        + cfg["peso_correccion"] * partes["correccion"]
        + cfg["peso_brevedad"] * partes["brevedad"]
    )


def construir_funcion_trl(cfg: dict):
    """Devuelve la función con la firma que espera GRPOTrainer.

    TRL llama a la función con las completions y con las demás columnas del
    dataset como argumentos por nombre. Aquí se usa la columna `respuesta`.
    """

    def recompensa(completions, respuesta=None, **kwargs):
        if respuesta is None:
            raise ValueError("El dataset debe traer la columna 'respuesta'.")
        textos = [c[0]["content"] if isinstance(c, list) else c for c in completions]
        return [recompensa_total(t, r, cfg) for t, r in zip(textos, respuesta)]

    recompensa.__name__ = "recompensa_verificable"
    return recompensa
