"""Generación del conjunto de problemas con respuesta verificable.

Los datos se generan localmente y de forma determinista: no hay descarga, no
hay dependencia de un dataset externo, y la respuesta correcta se conoce, que
es lo que permite una recompensa programática.

La tarea pide razonar brevemente y cerrar con la respuesta entre etiquetas.
Esa consigna es la que el modelo puede aprender a cumplir de forma parcial cuando la
recompensa premia demasiado la brevedad.
"""

from __future__ import annotations

import json
import random
from pathlib import Path

from config import cargar_config, resolver_ruta

CONSIGNA = (
    "Resolvé el problema paso a paso, en no más de tres oraciones, y cerrá "
    "con el resultado numérico entre las etiquetas <respuesta> y </respuesta>."
)

PLANTILLAS = [
    ("Una tienda vende {a} cajas por día durante {b} días. ¿Cuántas cajas vendió en total?",
     lambda a, b: a * b),
    ("Un depósito tenía {a} unidades y se despacharon {b}. ¿Cuántas quedaron?",
     lambda a, b: a - b),
    ("Se reparten {a} libros en partes iguales entre {b} aulas. ¿Cuántos libros recibe cada aula?",
     lambda a, b: a // b),
    ("Un curso tiene {a} estudiantes y se suman {b} más. ¿Cuántos estudiantes hay ahora?",
     lambda a, b: a + b),
    ("Cada equipo necesita {a} herramientas y hay {b} equipos. ¿Cuántas herramientas hacen falta?",
     lambda a, b: a * b),
]


def _generar_item(rng: random.Random, minimo: int, maximo: int) -> dict:
    indice = rng.randrange(len(PLANTILLAS))
    plantilla, operacion = PLANTILLAS[indice]

    a = rng.randint(minimo, maximo)
    b = rng.randint(minimo, maximo)
    if indice == 1 and b > a:          # resta sin negativos
        a, b = b, a
    if indice == 2:                    # división exacta
        b = rng.randint(2, 8)
        a = b * rng.randint(minimo, maximo)

    return {
        "enunciado": plantilla.format(a=a, b=b),
        "respuesta": int(operacion(a, b)),
        "plantilla": indice,
    }


def construir_dataset(config: dict) -> dict[str, Path]:
    """Escribe los conjuntos de entrenamiento y evaluación en JSONL."""
    cfg = config["datos"]
    minimo, maximo = cfg["rango_valores"]
    rng = random.Random(cfg["semilla_datos"])

    total = cfg["n_entrenamiento"] + cfg["n_evaluacion"]
    vistos: set[tuple] = set()
    items: list[dict] = []
    while len(items) < total:
        item = _generar_item(rng, minimo, maximo)
        clave = (item["enunciado"], item["respuesta"])
        if clave in vistos:
            continue
        vistos.add(clave)
        item["prompt"] = f"{CONSIGNA}\n\nProblema: {item['enunciado']}"
        items.append(item)

    rng.shuffle(items)
    particiones = {
        "entrenamiento": items[: cfg["n_entrenamiento"]],
        "evaluacion": items[cfg["n_entrenamiento"] :],
    }

    rutas = {}
    for nombre, filas in particiones.items():
        ruta = resolver_ruta(config, "datos", f"{nombre}.jsonl")
        with open(ruta, "w", encoding="utf-8") as f:
            for fila in filas:
                f.write(json.dumps(fila, ensure_ascii=False) + "\n")
        rutas[nombre] = ruta
    return rutas


def leer_jsonl(ruta: Path) -> list[dict]:
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(linea) for linea in f if linea.strip()]


if __name__ == "__main__":
    configuracion = cargar_config()
    for nombre, ruta in construir_dataset(configuracion).items():
        print(f"{nombre}: {ruta} ({len(leer_jsonl(ruta))} items)")
