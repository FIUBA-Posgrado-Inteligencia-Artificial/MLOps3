"""Compuerta de despliegue. Corre en CPU.

La compuerta es el componente de LLMOps del ejercicio: una función que lee el
reporte de evaluación y decide si el artefacto se promueve. Puede rechazar un
artefacto cuya recompensa de entrenamiento está en su máximo.

Cuatro reglas que bloquean:
  1. el juez tiene que estar calibrado por encima del umbral de acuerdo
  2. la evaluación tiene que tener potencia para el efecto que se quiere detectar
  3. el límite inferior del IC del win-rate tiene que superar el umbral
  4. el entorno del reporte tiene que coincidir con el de destino

Y una señal que advierte sin bloquear: el derrumbe del largo medio respecto de
la base. Su costo es bajo y no requiere juez, pero no está establecido que sea
suficiente para detectar el atajo. Es la cuestión abierta del ejercicio.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from analizar import cargar_reportes, resumir
from config import DIR_CONFIG, cargar_config, resolver_ruta
from entorno import capturar_entorno, entornos_compatibles

RUTA_DESTINO = DIR_CONFIG / "entorno_destino.json"


def entorno_destino(config: dict) -> dict:
    """Entorno en el que se va a servir el artefacto.

    Si no está declarado, se toma el entorno actual y se deja escrito: a partir
    de ahí, cualquier reporte producido en otro entorno queda señalado.
    """
    if RUTA_DESTINO.exists():
        with open(RUTA_DESTINO, encoding="utf-8") as f:
            return json.load(f)
    actual = capturar_entorno(config["modelo"]["precision"])
    with open(RUTA_DESTINO, "w", encoding="utf-8") as f:
        json.dump(actual, f, ensure_ascii=False, indent=2)
    return actual


def evaluar_compuerta(config: dict, resumen: dict, reportes: list[dict]) -> dict:
    cfg = config["compuerta"]
    ultimo = max(r["checkpoint"] for r in reportes)
    finales = [r for r in reportes if r["checkpoint"] == ultimo]
    destino = entorno_destino(config)

    decisiones: list[dict] = []
    for brazo in sorted({r["brazo"] for r in finales}):
        celda = resumen["celdas"][f"{brazo}__ck{ultimo}"]
        del_brazo = [r for r in finales if r["brazo"] == brazo]
        juez = del_brazo[0]["juez"]

        reglas: list[dict] = []

        reglas.append({
            "regla": "juez_calibrado",
            "pasa": bool(juez.get("calibrado")) and
                    juez.get("acuerdo", 0) >= config["evaluacion"]["juez"]["umbral_acuerdo"],
            "detalle": f"acuerdo {juez.get('acuerdo', 0):.2f} contra umbral "
                       f"{config['evaluacion']['juez']['umbral_acuerdo']:.2f}"
                       + ("" if juez.get("calibrado") else " (sin calibrar)"),
        })

        potencia = resumen["potencia"]
        reglas.append({
            "regla": "potencia_suficiente",
            "pasa": bool(potencia["suficiente"]),
            "detalle": f"{potencia['n_disponible']} prompts disponibles, "
                       f"{potencia['n_necesario']} necesarios",
        })

        reglas.append({
            "regla": "win_rate_sobre_umbral",
            "pasa": celda["ic_bajo"] >= cfg["umbral_win_rate"],
            "detalle": f"IC inferior {celda['ic_bajo']:.3f} contra umbral "
                       f"{cfg['umbral_win_rate']:.2f} (win-rate {celda['win_rate']:.3f})",
        })

        diferencias = []
        if cfg["exigir_entorno_identico"]:
            for r in del_brazo:
                diferencias += entornos_compatibles(r["entorno"], destino,
                                                    cfg["campos_entorno_criticos"])
        diferencias = sorted(set(diferencias))
        reglas.append({
            "regla": "entorno_coincide_con_destino",
            "pasa": not diferencias,
            "detalle": "idéntico" if not diferencias
                       else "difiere en " + ", ".join(diferencias),
        })

        largo = celda["largo_medio"] or 0.0
        largo_base = celda["largo_medio_base"] or 0.0
        caida = 1 - (largo / largo_base) if largo_base else 0.0
        advertencias = []
        if caida > 0.5:
            advertencias.append({
                "senal": "derrumbe_de_largo",
                "detalle": f"el largo medio cayó {caida:.0%} respecto de la base "
                           f"({largo:.0f} contra {largo_base:.0f} caracteres)",
            })

        promovido = all(r["pasa"] for r in reglas)
        decisiones.append({
            "brazo": brazo,
            "checkpoint": ultimo,
            "promovido": promovido,
            "reglas": reglas,
            "advertencias": advertencias,
            "metricas": {
                "win_rate": celda["win_rate"],
                "ic_bajo": celda["ic_bajo"],
                "recompensa_entrenamiento": celda["recompensa_entrenamiento"],
                "largo_medio": celda["largo_medio"],
                "correccion_media": celda["correccion_media"],
            },
        })

    return {"entorno_destino": destino, "decisiones": decisiones}


def imprimir(decision: dict) -> None:
    for d in decision["decisiones"]:
        estado = "PROMUEVE" if d["promovido"] else "RECHAZA"
        recompensa = d["metricas"]["recompensa_entrenamiento"]
        texto_recompensa = f"{recompensa:.3f}" if recompensa is not None else "sin dato"
        print(f"\n[compuerta] {estado}  {d['brazo']} (ck{d['checkpoint']})")
        print(f"            recompensa de entrenamiento {texto_recompensa} · "
              f"win-rate {d['metricas']['win_rate']:.3f}")
        for regla in d["reglas"]:
            marca = "ok   " if regla["pasa"] else "falla"
            print(f"            [{marca}] {regla['regla']}: {regla['detalle']}")
        for aviso in d["advertencias"]:
            print(f"            [aviso] {aviso['senal']}: {aviso['detalle']}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Compuerta de despliegue")
    parser.add_argument("--perfil", default=None)
    args = parser.parse_args()

    config = cargar_config(args.perfil)
    reportes = cargar_reportes(config)
    resumen = resumir(config, reportes)
    decision = evaluar_compuerta(config, resumen, reportes)

    destino = resolver_ruta(config, "reportes", "decision_compuerta.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump(decision, f, ensure_ascii=False, indent=2)

    imprimir(decision)
    print(f"\n[compuerta] decisión en {destino}")

    if not any(d["promovido"] for d in decision["decisiones"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
