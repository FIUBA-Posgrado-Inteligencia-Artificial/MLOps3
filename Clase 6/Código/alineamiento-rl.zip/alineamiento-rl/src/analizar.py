"""Etapa 3: análisis estadístico y figura. Corre en CPU.

Todo el procesamiento de esta etapa se realiza sin GPU, a partir de los reportes
de la etapa 2. Es la etapa adecuada para el trabajo de los alumnos: pre-registro,
estadística y decisión, sin requerimientos de cómputo.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

from config import cargar_config, resolver_ruta


def cargar_reportes(config: dict) -> list[dict]:
    directorio = resolver_ruta(config, "reportes")
    reportes = []
    for ruta in sorted(Path(directorio).glob("*.json")):
        if ruta.name in ("resumen.json", "decision_compuerta.json"):
            continue
        with open(ruta, encoding="utf-8") as f:
            reportes.append(json.load(f))
    if not reportes:
        raise FileNotFoundError(f"No hay reportes en {directorio}. Ejecutar la etapa 2 o `make prueba`.")
    return reportes


# --------------------------------------------------------------------------
# Estadística
# --------------------------------------------------------------------------

def ic_bootstrap(puntajes: np.ndarray, n_bootstrap: int, nivel: float,
                 semilla: int = 0) -> tuple[float, float, float]:
    """Intervalo percentil para la media de los puntajes pareados."""
    rng = np.random.default_rng(semilla)
    n = len(puntajes)
    if n == 0:
        return 0.0, 0.0, 0.0
    muestras = rng.choice(puntajes, size=(n_bootstrap, n), replace=True).mean(axis=1)
    alfa = (1 - nivel) / 2
    return float(puntajes.mean()), float(np.quantile(muestras, alfa)), float(np.quantile(muestras, 1 - alfa))


def test_pareado(a: np.ndarray, b: np.ndarray, n_bootstrap: int, nivel: float,
                 semilla: int = 0) -> dict:
    """Bootstrap pareado sobre las diferencias prompt a prompt.

    Pareado porque los dos brazos se evalúan sobre los mismos prompts: comparar
    medias independientes desperdiciaría esa estructura y perdería potencia.
    """
    n = min(len(a), len(b))
    diferencias = a[:n] - b[:n]
    media, bajo, alto = ic_bootstrap(diferencias, n_bootstrap, nivel, semilla)
    rng = np.random.default_rng(semilla + 1)
    nulo = rng.choice(diferencias - diferencias.mean(), size=(n_bootstrap, n), replace=True).mean(axis=1)
    p = float((np.abs(nulo) >= abs(media)).mean())
    return {"diferencia_media": media, "ic_bajo": bajo, "ic_alto": alto, "p_valor": p, "n": n}


def cuantil_normal(p: float) -> float:
    """Inversa de la normal estándar, por la aproximación racional de Acklam.

    Se implementa aquí en lugar de importar scipy: el proyecto la usa para dos valores
    y no justifica la dependencia. El error es menor a 1e-9 en todo el rango.
    """
    if not 0 < p < 1:
        raise ValueError("p tiene que estar entre 0 y 1")

    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    bajo, alto = 0.02425, 1 - 0.02425

    if p < bajo:
        q = np.sqrt(-2 * np.log(p))
        x = ((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]
        x /= (((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1
    elif p <= alto:
        q = p - 0.5
        r = q * q
        x = ((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5]
        x *= q / (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1)
    else:
        q = np.sqrt(-2 * np.log(1 - p))
        x = -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])
        x /= (((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1

    # Un paso de Halley para llevar el error de 1e-9 a precisión de máquina.
    e = 0.5 * math.erfc(-x / np.sqrt(2)) - p
    u = e * np.sqrt(2 * np.pi) * np.exp(x * x / 2)
    return float(x - u / (1 + x * u / 2))


def n_necesario(efecto: float, potencia: float, nivel: float) -> int:
    """Tamaño de muestra para detectar un desvío del win-rate respecto de 0.5.

    Se calcula antes de evaluar: determina cuántos prompts son necesarios y evita
    consumo innecesario del juez.
    """
    z_alfa = cuantil_normal(1 - (1 - nivel) / 2)
    z_beta = cuantil_normal(potencia)
    p1 = 0.5 + efecto
    varianza = p1 * (1 - p1)
    return int(np.ceil(((z_alfa * 0.5 + z_beta * np.sqrt(varianza)) / efecto) ** 2))


# --------------------------------------------------------------------------
# Resumen
# --------------------------------------------------------------------------

def resumir(config: dict, reportes: list[dict]) -> dict:
    cfg = config["analisis"]
    por_celda: dict[tuple, list[dict]] = defaultdict(list)
    for r in reportes:
        por_celda[(r["brazo"], r["checkpoint"])].append(r)

    celdas = {}
    for (brazo, checkpoint), grupo in sorted(por_celda.items()):
        puntajes = np.array([j["puntaje_alineado"] for r in grupo for j in r["juicios"]])
        media, bajo, alto = ic_bootstrap(puntajes, cfg["n_bootstrap"], cfg["nivel_confianza"])
        promedio = lambda clave: float(np.mean([
            r["metricas"][clave] for r in grupo if r["metricas"].get(clave) is not None
        ])) if any(r["metricas"].get(clave) is not None for r in grupo) else None

        celdas[f"{brazo}__ck{checkpoint}"] = {
            "brazo": brazo,
            "checkpoint": checkpoint,
            "semillas": sorted(r["semilla"] for r in grupo),
            "win_rate": media,
            "ic_bajo": bajo,
            "ic_alto": alto,
            "recompensa_entrenamiento": promedio("recompensa_media_entrenamiento"),
            "recompensa_eval": promedio("recompensa_media_eval"),
            "largo_medio": promedio("largo_medio_alineado"),
            "largo_medio_base": promedio("largo_medio_base"),
            "correccion_media": promedio("correccion_media"),
            "kl_media": promedio("kl_media"),
            "n_juicios": int(len(puntajes)),
        }

    brazos = sorted({r["brazo"] for r in reportes})
    ultimo = max(r["checkpoint"] for r in reportes)
    comparacion = {}
    if len(brazos) == 2:
        series = []
        for brazo in brazos:
            grupo = por_celda[(brazo, ultimo)]
            series.append(np.array([j["puntaje_alineado"] for r in sorted(grupo, key=lambda x: x["semilla"])
                                    for j in r["juicios"]]))
        comparacion = {
            "brazos": brazos,
            "checkpoint": ultimo,
            **test_pareado(series[0], series[1], cfg["n_bootstrap"], cfg["nivel_confianza"]),
        }

    potencia = {
        "efecto_minimo_detectable": cfg["efecto_minimo_detectable"],
        "potencia_objetivo": cfg["potencia_objetivo"],
        "n_necesario": n_necesario(cfg["efecto_minimo_detectable"],
                                   cfg["potencia_objetivo"], cfg["nivel_confianza"]),
        "n_disponible": config["datos"]["n_evaluacion"],
    }
    potencia["suficiente"] = potencia["n_disponible"] >= potencia["n_necesario"]

    return {"celdas": celdas, "comparacion_brazos": comparacion, "potencia": potencia,
            "nivel_confianza": cfg["nivel_confianza"]}


# --------------------------------------------------------------------------
# Figura
# --------------------------------------------------------------------------

def figura(config: dict, resumen: dict) -> Path:
    """Recompensa de entrenamiento contra win-rate, por brazo.

    Muestra la divergencia entre ambas métricas a lo largo del entrenamiento.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    celdas = list(resumen["celdas"].values())
    brazos = sorted({c["brazo"] for c in celdas})
    colores = {brazos[0]: "#1b6ca8", brazos[-1]: "#c1440e"}

    fig, ejes = plt.subplots(figsize=(8.5, 5))
    eje_derecho = ejes.twinx()

    for brazo in brazos:
        serie = sorted([c for c in celdas if c["brazo"] == brazo], key=lambda c: c["checkpoint"])
        pasos = [c["checkpoint"] for c in serie]
        recompensas = [c["recompensa_entrenamiento"] for c in serie]
        win = [c["win_rate"] for c in serie]
        bajo = [c["ic_bajo"] for c in serie]
        alto = [c["ic_alto"] for c in serie]

        if all(r is not None for r in recompensas):
            ejes.plot(pasos, recompensas, marker="o", color=colores[brazo],
                      label=f"recompensa · {brazo}")
        eje_derecho.plot(pasos, win, marker="s", linestyle="--", color=colores[brazo],
                         label=f"win-rate · {brazo}")
        eje_derecho.fill_between(pasos, bajo, alto, color=colores[brazo], alpha=0.12)

    eje_derecho.axhline(0.5, color="#555555", linewidth=1, linestyle=":")
    eje_derecho.annotate("paridad con la base", xy=(pasos[0], 0.5), xytext=(4, 6),
                         textcoords="offset points", fontsize=8, color="#555555")
    ejes.set_xlabel("paso de entrenamiento")
    ejes.set_ylabel("recompensa media (objetivo de optimización)")
    eje_derecho.set_ylabel("win-rate contra el modelo base")
    eje_derecho.set_ylim(0, 1)
    ejes.set_title("La recompensa sube y la calidad baja", pad=12)

    lineas = ejes.get_lines() + [l for l in eje_derecho.get_lines()
                                 if l.get_label().startswith("win-rate")]
    ejes.legend(lineas, [l.get_label() for l in lineas], fontsize=9,
                loc="upper left", framealpha=0.9)
    fig.tight_layout()

    destino = resolver_ruta(config, "figuras", "recompensa_vs_winrate.png")
    fig.savefig(destino, dpi=160)
    plt.close(fig)
    return destino


def main() -> None:
    parser = argparse.ArgumentParser(description="Etapa 3: análisis")
    parser.add_argument("--perfil", default=None)
    args = parser.parse_args()

    config = cargar_config(args.perfil)
    reportes = cargar_reportes(config)
    resumen = resumir(config, reportes)

    destino = resolver_ruta(config, "reportes", "resumen.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump(resumen, f, ensure_ascii=False, indent=2)

    ruta_figura = figura(config, resumen)

    potencia = resumen["potencia"]
    print(f"[analizar] potencia: hacen falta {potencia['n_necesario']} prompts, "
          f"hay {potencia['n_disponible']} ({'alcanza' if potencia['suficiente'] else 'no alcanza'})")
    for nombre, celda in resumen["celdas"].items():
        print(f"  {nombre:28s} win-rate {celda['win_rate']:.3f} "
              f"[{celda['ic_bajo']:.3f}, {celda['ic_alto']:.3f}]  "
              f"largo {celda['largo_medio']:.0f}")
    if resumen["comparacion_brazos"]:
        c = resumen["comparacion_brazos"]
        print(f"[analizar] {c['brazos'][0]} vs {c['brazos'][1]} en ck{c['checkpoint']}: "
              f"diferencia {c['diferencia_media']:+.3f} "
              f"[{c['ic_bajo']:+.3f}, {c['ic_alto']:+.3f}], p={c['p_valor']:.4f}")
    print(f"[analizar] resumen en {destino}")
    print(f"[analizar] figura en {ruta_figura}")


if __name__ == "__main__":
    main()
