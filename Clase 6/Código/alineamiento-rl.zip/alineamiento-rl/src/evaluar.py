"""Etapa 2: evaluación sobre el modelo servido. Requiere GPU.

El aspecto central de esta etapa: el modelo se evalúa servido por vLLM, con el
adaptador cargado en tiempo de serving, no en el proceso de entrenamiento. El
modelo que se mide es el que se va a desplegar.

Dos pasos, en este orden y en sesiones separadas del entrenamiento:
  1. generar  — levanta vLLM con la base y el adaptador, y recoge respuestas
  2. juzgar   — comparación pareada contra la base, con intercambio de posición

El juez se calibra previamente contra anotaciones propias. Sin calibración, su
puntaje no constituye una métrica.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import subprocess
import time
import urllib.parse
from pathlib import Path

import requests

from config import cargar_config, id_corrida, resolver_ruta
from datos import construir_dataset, leer_jsonl
from entorno import capturar_entorno
from recompensas import componentes, recompensa_total
import registro

PLANTILLA_JUEZ = """Compará dos respuestas al mismo problema y decidí cuál es mejor.

Criterios, en orden de importancia:
1. El resultado final es correcto.
2. El razonamiento está explicado y permite seguir cómo se llegó al resultado.
3. La respuesta es clara y no incluye relleno.

Problema: {enunciado}
Resultado correcto: {respuesta}

Respuesta A:
{a}

Respuesta B:
{b}

Contestá únicamente con la letra A o la letra B."""


# --------------------------------------------------------------------------
# Servidor
# --------------------------------------------------------------------------

def levantar_vllm(config: dict, adaptadores: dict[str, str] | None = None) -> subprocess.Popen:
    """Levanta vLLM en segundo plano y espera a que /health responda."""
    cfg = config["evaluacion"]["servidor"]
    comando = [
        "vllm", "serve", config["modelo"]["base"],
        "--host", cfg["host"], "--port", str(cfg["puerto"]),
        "--gpu-memory-utilization", str(cfg["utilizacion_memoria"]),
        "--max-model-len", str(config["modelo"]["largo_maximo_prompt"]
                               + config["modelo"]["largo_maximo_respuesta"] + 64),
        "--dtype", "half" if config["modelo"]["precision"] == "float16" else "bfloat16",
    ]
    if adaptadores:
        # El rango máximo se declara explícitamente: vLLM rechaza un adaptador
        # cuyo r supere lo que el servidor reservó, y el valor por defecto
        # coincide justo con el r del perfil, sin margen.
        rango = config["grpo"]["lora"]["r"]
        comando += [
            "--enable-lora",
            "--max-lora-rank", str(max(16, rango)),
            "--max-loras", "1",
            "--max-cpu-loras", str(max(2, len(adaptadores))),
            "--lora-modules",
        ]
        comando += [f"{nombre}={ruta}" for nombre, ruta in adaptadores.items()]

    log = resolver_ruta(config, "artefactos", "vllm.log")
    print(f"[evaluar] levantando vLLM; log en {log}")
    proceso = subprocess.Popen(comando, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    esperar_salud(config, cfg["espera_salud_s"], proceso, log)
    return proceso


def _ultimas_lineas(ruta: Path | str, n: int = 25) -> str:
    try:
        with open(ruta, encoding="utf-8", errors="replace") as f:
            lineas = f.readlines()
    except OSError:
        return "(no se pudo leer el log)"
    return "".join(lineas[-n:]).rstrip() or "(log vacío)"


def esperar_salud(config: dict, segundos: int,
                  proceso: subprocess.Popen | None = None,
                  log: Path | str | None = None) -> None:
    """Espera a que vLLM responda, o falla apenas el proceso muere.

    Sin mirar el proceso, un arranque que aborta en dos segundos igual hace
    esperar el tiempo completo antes de avisar. Y el mensaje de error muestra
    el final del log: el motivo real figura ahí y no en el traceback.
    """
    cfg = config["evaluacion"]["servidor"]
    url = f"http://{cfg['host']}:{cfg['puerto']}/health"
    limite = time.time() + segundos

    while time.time() < limite:
        try:
            if requests.get(url, timeout=5).status_code == 200:
                print("[evaluar] servidor vLLM listo")
                return
        except requests.RequestException:
            pass
        if proceso is not None and proceso.poll() is not None:
            raise RuntimeError(
                f"vLLM terminó con código {proceso.returncode} antes de responder.\n"
                f"Log: {log}\n\n--- final del log ---\n{_ultimas_lineas(log)}"
            )
        time.sleep(5)

    if proceso is not None:
        proceso.terminate()
    raise TimeoutError(
        f"vLLM no respondió en {segundos} s.\nLog: {log}\n\n"
        f"--- final del log ---\n{_ultimas_lineas(log)}"
    )


# --------------------------------------------------------------------------
# Servidor del juez
# --------------------------------------------------------------------------

def _url_salud_juez(config: dict) -> str:
    base = config["evaluacion"]["juez"].get("base_url", "http://127.0.0.1:8001")
    return base.rstrip("/") + "/health"


def juez_responde(config: dict, timeout: int = 5) -> bool:
    try:
        return requests.get(_url_salud_juez(config), timeout=timeout).status_code == 200
    except requests.RequestException:
        return False


def levantar_juez(config: dict) -> subprocess.Popen | None:
    """Levanta el servidor del juez si hace falta.

    Devuelve el proceso cuando lo arrancó esta función, y None cuando el juez
    ya estaba respondiendo (en ese caso no corresponde detenerlo).

    El juez se ejecuta en su propio servidor y en su propio momento: nunca coexiste en
    memoria con el modelo que se está evaluando. Por eso esto se llama en el
    paso de juzgar, cuando el servidor de las generaciones ya se apagó.
    """
    cfg = config["evaluacion"]["juez"]
    if cfg["backend"] != "vllm":
        return None
    if juez_responde(config):
        print("[evaluar] el juez ya estaba levantado")
        return None
    if not cfg.get("modelo"):
        raise RuntimeError("Falta el modelo del juez: fijalo en el perfil o en JUEZ_MODELO.")

    partes = urllib.parse.urlparse(cfg.get("base_url", "http://127.0.0.1:8001"))
    ventana = config["modelo"]["largo_maximo_prompt"] + 2 * config["modelo"]["largo_maximo_respuesta"] + 256
    comando = [
        "vllm", "serve", cfg["modelo"],
        "--host", partes.hostname or "127.0.0.1",
        "--port", str(partes.port or 8001),
        "--gpu-memory-utilization", str(cfg.get("utilizacion_memoria", 0.80)),
        "--max-model-len", str(ventana),
        "--dtype", "half" if config["modelo"]["precision"] == "float16" else "bfloat16",
    ]
    log = resolver_ruta(config, "artefactos", "juez.log")
    print(f"[evaluar] levantando el juez {cfg['modelo']}; log en {log}")
    proceso = subprocess.Popen(comando, stdout=open(log, "w"), stderr=subprocess.STDOUT)

    limite = time.time() + config["evaluacion"]["servidor"]["espera_salud_s"]
    while time.time() < limite:
        if juez_responde(config):
            print("[evaluar] juez listo")
            return proceso
        if proceso.poll() is not None:
            raise RuntimeError(
                f"El juez terminó con código {proceso.returncode} antes de responder.\n"
                f"Log: {log}\n\n--- final del log ---\n{_ultimas_lineas(log)}"
            )
        time.sleep(10)
    proceso.terminate()
    raise TimeoutError(
        f"El juez no respondió a tiempo.\nLog: {log}\n\n"
        f"--- final del log ---\n{_ultimas_lineas(log)}"
    )


def apagar_juez(proceso: subprocess.Popen | None) -> None:
    if proceso is None:
        return
    proceso.terminate()
    try:
        proceso.wait(timeout=60)
    except subprocess.TimeoutExpired:
        proceso.kill()
    print("[evaluar] juez apagado")


def _completar(config: dict, modelo: str, prompt: str, temperatura: float,
               max_tokens: int, base_url: str | None = None) -> str:
    cfg = config["evaluacion"]["servidor"]
    base = base_url or f"http://{cfg['host']}:{cfg['puerto']}"
    cuerpo = {
        "model": modelo,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperatura,
        "max_tokens": max_tokens,
    }
    respuesta = requests.post(f"{base.rstrip('/')}/v1/chat/completions", json=cuerpo, timeout=180)
    respuesta.raise_for_status()
    return respuesta.json()["choices"][0]["message"]["content"]


# --------------------------------------------------------------------------
# Generación
# --------------------------------------------------------------------------

def generar_corrida(config: dict, brazo: str, semilla: int) -> list[Path]:
    """Genera las respuestas de todos los checkpoints de una corrida.

    Un solo servidor por corrida, con los adaptadores de todos sus checkpoints
    registrados de entrada. Levantar vLLM toma varios minutos, de modo que hacerlo
    una vez por checkpoint multiplicaría ese tiempo sin beneficio alguno.

    El servidor sirve el modelo base bajo su propio nombre y cada adaptador
    bajo el suyo, así que las dos respuestas que se comparan salen del mismo
    proceso y de la misma configuración de serving.
    """
    corrida = id_corrida(brazo, semilla)
    checkpoints = config["grpo"]["checkpoints"]

    adaptadores: dict[str, str] = {}
    faltantes: list[int] = []
    for checkpoint in checkpoints:
        ruta = resolver_ruta(config, "artefactos", corrida, f"checkpoint_{checkpoint}")
        # Lo que define que haya un adaptador es adapter_config.json, no que la
        # carpeta exista: resolver_ruta la crea, así que una carpeta vacía
        # pasaría el chequeo y recién fallaría al levantar el servidor.
        if not (Path(ruta) / "adapter_config.json").exists():
            faltantes.append(checkpoint)
            continue
        adaptadores[f"{corrida}_ck{checkpoint}"] = str(ruta)

    if faltantes:
        raise FileNotFoundError(
            f"A {corrida} le faltan los adaptadores de los checkpoints {faltantes}. "
            f"Ejecutar la etapa 1 para esa corrida, o quitar esos valores de "
            f"grpo.checkpoints en el perfil."
        )

    ruta_eval = resolver_ruta(config, "datos", "evaluacion.jsonl")
    if not ruta_eval.exists():
        construir_dataset(config)
    items = leer_jsonl(ruta_eval)
    largo = config["modelo"]["largo_maximo_respuesta"]

    destinos: list[Path] = []
    proceso = levantar_vllm(config, adaptadores)
    try:
        # El modelo base responde lo mismo en todos los checkpoints, así que se
        # genera una sola vez y se reutiliza como comparador.
        print(f"[evaluar] {corrida}: generando la referencia del modelo base")
        base = [_completar(config, config["modelo"]["base"], item["prompt"], 0.0, largo)
                for item in items]

        for checkpoint in checkpoints:
            nombre_lora = f"{corrida}_ck{checkpoint}"
            filas = []
            for item, texto_base in zip(items, base):
                filas.append({
                    "enunciado": item["enunciado"],
                    "respuesta_esperada": item["respuesta"],
                    "texto_alineado": _completar(config, nombre_lora, item["prompt"], 0.0, largo),
                    "texto_base": texto_base,
                })
            destino = resolver_ruta(config, "artefactos", corrida,
                                    f"generaciones_ck{checkpoint}.jsonl")
            with open(destino, "w", encoding="utf-8") as f:
                for fila in filas:
                    f.write(json.dumps(fila, ensure_ascii=False) + "\n")
            print(f"[evaluar] {len(filas)} generaciones en {destino}")
            destinos.append(destino)
    finally:
        proceso.terminate()
        try:
            proceso.wait(timeout=60)
        except subprocess.TimeoutExpired:
            proceso.kill()

    return destinos


# --------------------------------------------------------------------------
# Juez
# --------------------------------------------------------------------------

def _juzgar_par(config: dict, enunciado: str, esperado: int, a: str, b: str) -> str:
    """Devuelve 'A' o 'B'. El backend decide por dónde sale la consulta."""
    cfg = config["evaluacion"]["juez"]
    prompt = PLANTILLA_JUEZ.format(enunciado=enunciado, respuesta=esperado, a=a, b=b)

    if cfg["backend"] == "vllm":
        # El juez vive en su propio servidor, levantado después de liberar el
        # entrenamiento: no comparte memoria con el artefacto evaluado.
        texto = _completar(config, cfg["modelo"], prompt, cfg["temperatura"], 8,
                           base_url=cfg.get("base_url"))
    elif cfg["backend"] == "api":
        texto = _consultar_api(cfg, prompt)
    else:
        raise ValueError(f"Backend de juez desconocido: {cfg['backend']}")

    letra = texto.strip().upper()
    return "A" if letra.startswith("A") else "B"


def _consultar_api(cfg: dict, prompt: str) -> str:
    """Cliente compatible con la API de chat de OpenAI.

    Se configura con JUEZ_BASE_URL y JUEZ_API_KEY. Sirve para cualquier
    proveedor que exponga /v1/chat/completions.
    """
    base = os.environ.get("JUEZ_BASE_URL", "").rstrip("/")
    clave = os.environ.get("JUEZ_API_KEY", "")
    if not base or not clave:
        raise RuntimeError("Faltan JUEZ_BASE_URL y JUEZ_API_KEY para el juez por API.")
    respuesta = requests.post(
        f"{base}/v1/chat/completions",
        headers={"Authorization": f"Bearer {clave}"},
        json={"model": cfg["modelo"], "messages": [{"role": "user", "content": prompt}],
              "temperature": cfg["temperatura"], "max_tokens": 8},
        timeout=120,
    )
    respuesta.raise_for_status()
    return respuesta.json()["choices"][0]["message"]["content"]


def calibrar_juez(config: dict) -> dict:
    """Mide el acuerdo del juez contra anotaciones propias.

    El archivo de anotaciones trae pares ya decididos a mano. Si no existe, la
    calibración queda sin hacer y la compuerta lo registra como tal.
    """
    ruta = Path(config["evaluacion"]["juez"]["anotaciones"])
    if not ruta.is_absolute():
        ruta = resolver_ruta(config, "datos", ruta.name)
    if not Path(ruta).exists():
        return {"calibrado": False, "acuerdo": 0.0, "kappa": 0.0, "n": 0}

    pares = leer_jsonl(Path(ruta))
    aciertos = 0
    for par in pares:
        veredicto = _juzgar_par(config, par["enunciado"], par["respuesta_esperada"],
                                par["texto_a"], par["texto_b"])
        aciertos += int(veredicto == par["mejor"])

    n = len(pares)
    acuerdo = aciertos / n if n else 0.0
    kappa = (acuerdo - 0.5) / 0.5          # dos categorías equiprobables
    return {"calibrado": True, "acuerdo": acuerdo, "kappa": kappa, "n": n}


def juzgar(config: dict, brazo: str, semilla: int, checkpoint: int,
           calibracion: dict | None = None) -> Path:
    """Comparación pareada con intercambio de posición y reporte de la corrida."""
    corrida = id_corrida(brazo, semilla)
    ruta_gen = resolver_ruta(config, "artefactos", corrida, f"generaciones_ck{checkpoint}.jsonl")
    filas = leer_jsonl(Path(ruta_gen))
    calibracion = calibracion or calibrar_juez(config)

    rng = random.Random(semilla)
    juicios = []
    for fila in filas:
        # Orden aleatorio y, si corresponde, la consulta espejada para
        # neutralizar el sesgo posicional del juez.
        alineado_primero = rng.random() < 0.5
        a, b = ((fila["texto_alineado"], fila["texto_base"]) if alineado_primero
                else (fila["texto_base"], fila["texto_alineado"]))
        v1 = _juzgar_par(config, fila["enunciado"], fila["respuesta_esperada"], a, b)
        gana_alineado_1 = (v1 == "A") == alineado_primero

        if config["evaluacion"]["juez"]["intercambio_posicion"]:
            v2 = _juzgar_par(config, fila["enunciado"], fila["respuesta_esperada"], b, a)
            gana_alineado_2 = (v2 == "B") == alineado_primero
            if gana_alineado_1 == gana_alineado_2:
                puntaje = 1.0 if gana_alineado_1 else 0.0
            else:
                puntaje = 0.5          # el juez se contradice al invertir: empate
        else:
            puntaje = 1.0 if gana_alineado_1 else 0.0

        juicios.append({
            "enunciado": fila["enunciado"],
            "puntaje_alineado": puntaje,
            "largo_alineado": len(fila["texto_alineado"].strip()),
            "largo_base": len(fila["texto_base"].strip()),
            "recompensa_alineado": recompensa_total(
                fila["texto_alineado"], fila["respuesta_esperada"], config["recompensa"]),
            "componentes_alineado": componentes(
                fila["texto_alineado"], fila["respuesta_esperada"], config["recompensa"]),
        })

    destino = escribir_reporte(config, brazo, semilla, checkpoint, juicios, calibracion)
    print(f"[evaluar] reporte de {corrida} ck{checkpoint} en {destino}")
    return destino


def escribir_reporte(config: dict, brazo: str, semilla: int, checkpoint: int,
                     juicios: list[dict], calibracion: dict) -> Path:
    """Arma el reporte de evaluación: es el insumo de la compuerta."""
    corrida = id_corrida(brazo, semilla)
    n = len(juicios)
    media = lambda clave: sum(j[clave] for j in juicios) / n if n else 0.0

    historial = []
    ruta_hist = resolver_ruta(config, "artefactos", corrida, "historial.json")
    if Path(ruta_hist).exists():
        with open(ruta_hist, encoding="utf-8") as f:
            historial = json.load(f).get("historial", [])
    en_paso = [h for h in historial if h.get("paso") == checkpoint]
    metricas_entrenamiento = en_paso[-1] if en_paso else {}

    reporte = {
        "corrida": corrida,
        "brazo": brazo,
        "semilla": semilla,
        "checkpoint": checkpoint,
        "beta": config["brazos"][brazo]["beta"],
        "perfil": config["_perfil"],
        "entorno": capturar_entorno(config["modelo"]["precision"]),
        "juez": {"backend": config["evaluacion"]["juez"]["backend"],
                 "modelo": config["evaluacion"]["juez"]["modelo"], **calibracion},
        "metricas": {
            "win_rate": media("puntaje_alineado"),
            "recompensa_media_eval": media("recompensa_alineado"),
            "largo_medio_alineado": media("largo_alineado"),
            "largo_medio_base": media("largo_base"),
            "correccion_media": sum(j["componentes_alineado"]["correccion"] for j in juicios) / n
                                 if n else 0.0,
            "recompensa_media_entrenamiento": metricas_entrenamiento.get("recompensa_media"),
            "kl_media": metricas_entrenamiento.get("kl_media"),
            "n_evaluacion": n,
        },
        "juicios": juicios,
    }

    destino = resolver_ruta(config, "reportes", f"{corrida}__ck{checkpoint}.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump(reporte, f, ensure_ascii=False, indent=2)

    with registro.corrida(config, f"evaluar__{corrida}__ck{checkpoint}",
                          {"etapa": "evaluacion", "brazo": brazo, "semilla": semilla}) as reg:
        reg.metricas({k: v for k, v in reporte["metricas"].items()
                      if isinstance(v, (int, float))}, paso=checkpoint)
        reg.artefacto(destino)
    return destino


def main() -> None:
    parser = argparse.ArgumentParser(description="Etapa 2: evaluación sobre el endpoint")
    parser.add_argument("--perfil", default=None)
    parser.add_argument("--paso", choices=["generar", "juzgar", "ambos"], default="ambos")
    parser.add_argument("--brazo", default=None)
    parser.add_argument("--semilla", type=int, default=None)
    args = parser.parse_args()

    config = cargar_config(args.perfil)
    brazos = [args.brazo] if args.brazo else list(config["brazos"])
    semillas = [args.semilla] if args.semilla is not None else config["semillas"]

    # Si el paso incluye generar, primero se generan TODAS las respuestas y
    # recién después se levanta el juez. Los dos servidores no pueden convivir
    # en una GPU de memoria limitada, y el juez no requiere el otro: lee lo guardado.
    if args.paso in ("generar", "ambos"):
        for brazo in brazos:
            for semilla in semillas:
                generar_corrida(config, brazo, semilla)

    if args.paso not in ("juzgar", "ambos"):
        return

    proceso_juez = levantar_juez(config)
    try:
        calibracion = calibrar_juez(config)
        print(f"[evaluar] calibración del juez: {calibracion}")
        umbral = config["evaluacion"]["juez"]["umbral_acuerdo"]
        if calibracion["calibrado"] and calibracion["acuerdo"] < umbral:
            print(f"[evaluar] aviso: el acuerdo {calibracion['acuerdo']:.2f} no llega "
                  f"al umbral {umbral:.2f}; la compuerta va a bloquear por eso.")

        for brazo in brazos:
            for semilla in semillas:
                for checkpoint in config["grpo"]["checkpoints"]:
                    juzgar(config, brazo, semilla, checkpoint, calibracion)
    finally:
        apagar_juez(proceso_juez)


if __name__ == "__main__":
    main()
