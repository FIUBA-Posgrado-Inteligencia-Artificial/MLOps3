"""Registro de corridas en MLflow, con degradación elegante.

Si MLflow no está instalado (por ejemplo en el modo de prueba sin GPU), el
registro se vuelve una escritura a JSONL y el pipeline sigue funcionando.
"""

from __future__ import annotations

import json
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from config import resolver_ruta

try:
    import mlflow

    HAY_MLFLOW = True
except ImportError:
    HAY_MLFLOW = False


def _uri(config: dict) -> str:
    ruta = Path(config["rutas"]["mlflow"])
    if not ruta.is_absolute():
        ruta = resolver_ruta(config, "artefactos", ruta.name)
    return f"sqlite:///{ruta}"


@contextmanager
def corrida(config: dict, nombre: str, etiquetas: dict[str, Any] | None = None):
    """Abre una corrida de MLflow, o un registro local si no está disponible."""
    if not HAY_MLFLOW:
        acumulado: dict[str, Any] = {"nombre": nombre, "parametros": {}, "metricas": {}}
        yield _RegistroLocal(config, acumulado)
        return

    mlflow.set_tracking_uri(_uri(config))
    mlflow.set_experiment(config["proyecto"])
    with mlflow.start_run(run_name=nombre):
        if etiquetas:
            mlflow.set_tags({k: str(v) for k, v in etiquetas.items()})
        yield _RegistroMlflow()


class _RegistroMlflow:
    def parametros(self, valores: dict) -> None:
        mlflow.log_params({k: str(v)[:250] for k, v in _aplanar(valores).items()})

    def metricas(self, valores: dict, paso: int | None = None) -> None:
        numericas = {k: float(v) for k, v in valores.items() if isinstance(v, (int, float))}
        mlflow.log_metrics(numericas, step=paso)

    def artefacto(self, ruta: str | Path) -> None:
        mlflow.log_artifact(str(ruta))


class _RegistroLocal:
    def __init__(self, config: dict, acumulado: dict):
        self.config = config
        self.acumulado = acumulado

    def parametros(self, valores: dict) -> None:
        self.acumulado["parametros"].update(_aplanar(valores))
        self._volcar()

    def metricas(self, valores: dict, paso: int | None = None) -> None:
        self.acumulado.setdefault("historia", []).append({"paso": paso, **valores})
        self.acumulado["metricas"].update(valores)
        self._volcar()

    def artefacto(self, ruta: str | Path) -> None:
        self.acumulado.setdefault("artefactos", []).append(str(ruta))
        self._volcar()

    def _volcar(self) -> None:
        destino = resolver_ruta(self.config, "artefactos", "registro_local.jsonl")
        with open(destino, "a", encoding="utf-8") as f:
            f.write(json.dumps(self.acumulado, ensure_ascii=False) + "\n")


def _aplanar(datos: dict, prefijo: str = "") -> dict:
    salida = {}
    for clave, valor in datos.items():
        nombre = f"{prefijo}{clave}"
        if isinstance(valor, dict):
            salida.update(_aplanar(valor, f"{nombre}."))
        else:
            salida[nombre] = valor
    return salida
