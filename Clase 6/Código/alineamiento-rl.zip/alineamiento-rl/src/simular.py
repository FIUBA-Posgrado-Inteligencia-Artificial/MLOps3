"""Modo de prueba sin GPU.

Fabrica generaciones y juicios con la misma forma que producen las etapas 1 y
2, para validar que el pipeline encadena: que los reportes tienen el esquema
correcto, que la estadística corre, que la figura sale y que la compuerta
decide. No valida nada sobre el modelo ni sobre la convivencia de las
bibliotecas en la GPU: eso se prueba con `make alinear` en la máquina real.

La dinámica simulada es la que el ejercicio espera observar: con contención
floja, la política encuentra el atajo de la brevedad, la recompensa sube y la
calidad cae.
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

from config import cargar_config, id_corrida, resolver_ruta
from datos import construir_dataset, leer_jsonl
from entorno import capturar_entorno
from evaluar import escribir_reporte
from recompensas import recompensa_total

RAZONAMIENTO = (
    "Primero identifico los dos valores del enunciado. Después aplico la operación "
    "que corresponde al caso. El cálculo da el resultado que informo abajo. "
)


def _texto_completo(valor: int) -> str:
    return f"{RAZONAMIENTO}<respuesta>{valor}</respuesta>"


def _texto_recortado(valor: int) -> str:
    return f"<respuesta>{valor}</respuesta>"


def _intensidad(beta: float, progreso: float) -> float:
    """Cuánto se alejó la política de la referencia.

    Con beta alto la contención por KL frena el atajo; con beta bajo no.
    """
    libertad = min(1.0, 0.01 / max(beta, 1e-6))
    return libertad * progreso


def _juez_simulado(correcto_a: bool, razona_a: bool, correcto_b: bool,
                   razona_b: bool, rng: random.Random) -> float:
    """Juez de referencia: corrección primero, explicación después."""
    puntaje_a = 2.0 * correcto_a + 1.0 * razona_a
    puntaje_b = 2.0 * correcto_b + 1.0 * razona_b
    if abs(puntaje_a - puntaje_b) < 1e-9:
        return 0.5
    base = 1.0 if puntaje_a > puntaje_b else 0.0
    return base if rng.random() > 0.08 else 1.0 - base   # ruido del juez


def simular_corrida(config: dict, brazo: str, semilla: int) -> None:
    beta = config["brazos"][brazo]["beta"]
    corrida = id_corrida(brazo, semilla)
    checkpoints = config["grpo"]["checkpoints"]
    maximo = max(checkpoints)

    ruta_eval = resolver_ruta(config, "datos", "evaluacion.jsonl")
    if not Path(ruta_eval).exists():
        construir_dataset(config)
    items = leer_jsonl(Path(ruta_eval))

    rng = random.Random(1000 + semilla)
    historial = []

    for checkpoint in checkpoints:
        progreso = checkpoint / maximo if maximo else 0.0
        intensidad = _intensidad(beta, progreso)
        p_recorta = intensidad
        # La alineación mejora la corrección con el entrenamiento, y el atajo
        # de la brevedad la revierte: por eso el término de intensidad resta.
        p_correcto_alineado = 0.60 + 0.14 * progreso - 0.20 * intensidad
        p_correcto_base = 0.60

        filas, juicios = [], []
        for item in items:
            esperado = item["respuesta"]
            correcto_al = rng.random() < p_correcto_alineado
            correcto_ba = rng.random() < p_correcto_base
            valor_al = esperado if correcto_al else esperado + rng.choice([-2, -1, 1, 2])
            valor_ba = esperado if correcto_ba else esperado + rng.choice([-2, -1, 1, 2])

            recorta = rng.random() < p_recorta
            texto_al = _texto_recortado(valor_al) if recorta else _texto_completo(valor_al)
            texto_ba = _texto_completo(valor_ba)

            puntaje = _juez_simulado(correcto_al, not recorta, correcto_ba, True, rng)
            filas.append({"enunciado": item["enunciado"], "respuesta_esperada": esperado,
                          "texto_alineado": texto_al, "texto_base": texto_ba})
            juicios.append({
                "enunciado": item["enunciado"],
                "puntaje_alineado": puntaje,
                "largo_alineado": len(texto_al),
                "largo_base": len(texto_ba),
                "recompensa_alineado": recompensa_total(texto_al, esperado, config["recompensa"]),
                "componentes_alineado": {
                    "formato": 1.0,
                    "correccion": 1.0 if correcto_al else 0.0,
                    "brevedad": max(0.0, 1 - len(texto_al) / config["recompensa"]["largo_referencia"]),
                },
            })

        destino_gen = resolver_ruta(config, "artefactos", corrida,
                                    f"generaciones_ck{checkpoint}.jsonl")
        with open(destino_gen, "w", encoding="utf-8") as f:
            for fila in filas:
                f.write(json.dumps(fila, ensure_ascii=False) + "\n")

        historial.append({
            "paso": checkpoint,
            "recompensa_media": sum(j["recompensa_alineado"] for j in juicios) / len(juicios),
            "largo_medio": sum(j["largo_alineado"] for j in juicios) / len(juicios),
            "kl_media": 0.02 + 1.4 * intensidad ** 2,
        })
        ruta_hist = resolver_ruta(config, "artefactos", corrida, "historial.json")
        with open(ruta_hist, "w", encoding="utf-8") as f:
            json.dump({"corrida": corrida, "brazo": brazo, "semilla": semilla, "beta": beta,
                       "entorno": capturar_entorno(config["modelo"]["precision"]),
                       "historial": historial}, f, ensure_ascii=False, indent=2)

        calibracion = {"calibrado": True, "acuerdo": 0.84, "kappa": 0.68, "n": 40,
                       "simulado": True}
        escribir_reporte(config, brazo, semilla, checkpoint, juicios, calibracion)

    print(f"[simular] {corrida}: {len(checkpoints)} checkpoints")


def anotaciones_calibracion(config: dict, n: int = 40) -> Path:
    """Plantilla de anotaciones para calibrar el juez real.

    En la corrida real estas etiquetas se asignan manualmente: son el patrón contra
    el que se mide el acuerdo del juez.
    """
    items = leer_jsonl(resolver_ruta(config, "datos", "evaluacion.jsonl"))[:n]
    rng = random.Random(99)
    filas = []
    for item in items:
        esperado = item["respuesta"]
        a_correcta = rng.random() < 0.5
        texto_a = _texto_completo(esperado if a_correcta else esperado + 1)
        texto_b = _texto_recortado(esperado if not a_correcta else esperado + 1)
        filas.append({
            "enunciado": item["enunciado"],
            "respuesta_esperada": esperado,
            "texto_a": texto_a,
            "texto_b": texto_b,
            "mejor": "A" if a_correcta else "B",
        })
    destino = resolver_ruta(config, "datos", "anotaciones_calibracion.jsonl")
    with open(destino, "w", encoding="utf-8") as f:
        for fila in filas:
            f.write(json.dumps(fila, ensure_ascii=False) + "\n")
    return destino


def main() -> None:
    parser = argparse.ArgumentParser(description="Modo de prueba sin GPU")
    parser.add_argument("--perfil", default=None)
    args = parser.parse_args()

    config = cargar_config(args.perfil)
    construir_dataset(config)
    anotaciones_calibracion(config)
    for brazo in config["brazos"]:
        for semilla in config["semillas"]:
            simular_corrida(config, brazo, semilla)
    print("[simular] listo. Continuar con `make analizar` y `make compuerta`.")


if __name__ == "__main__":
    main()
