"""Etapa 1: alineación con GRPO. Requiere GPU.

vLLM interviene por primera vez en esta etapa, generando los rollouts dentro
del bucle de entrenamiento (modo colocado: corre en el mismo proceso y comparte
memoria con el entrenador). Esto hace viable un método on-policy en una sola GPU.

Salida: un adaptador por checkpoint, más el historial de recompensa, largo y KL.
La evaluación no se realiza en esta etapa, sino contra el modelo servido en la 2.
"""

from __future__ import annotations

import argparse
import json
import os
import socket
from pathlib import Path

from config import cargar_config, id_corrida, resolver_ruta
from datos import construir_dataset, leer_jsonl
from entorno import capturar_entorno
from recompensas import construir_funcion_trl
import registro


def _dataset(config: dict):
    from datasets import Dataset

    ruta = resolver_ruta(config, "datos", "entrenamiento.jsonl")
    if not ruta.exists():
        construir_dataset(config)
    filas = leer_jsonl(ruta)

    # El prompt va en formato conversacional, no como texto plano. TRL aplica
    # la plantilla de conversación del modelo solo cuando el dataset tiene esta
    # forma; sin ella, un modelo instruido no reconoce dónde termina el turno y
    # genera hasta agotar el límite de tokens.
    #
    # Además es lo que hace que entrenamiento y servicio midan lo mismo: la
    # etapa 2 consulta el endpoint de chat, que siempre aplica la plantilla.
    # Entrenar sin ella y evaluar con ella es la brecha que este ejercicio
    # busca evitar.
    return Dataset.from_list(
        [{"prompt": [{"role": "user", "content": f["prompt"]}],
          "respuesta": f["respuesta"]} for f in filas]
    )


def _callback_metricas(config, corrida_id, reg, historial):
    """Guarda adaptador y métricas en los pasos marcados como checkpoint."""
    from transformers import TrainerCallback

    checkpoints = set(config["grpo"]["checkpoints"])

    class Seguimiento(TrainerCallback):
        def on_log(self, args, state, control, logs=None, **kwargs):
            if not logs:
                return
            fila = {"paso": int(state.global_step)}
            for origen, destino in [
                ("reward", "recompensa_media"),
                ("reward_std", "recompensa_desvio"),
                ("kl", "kl_media"),
                ("completions/mean_length", "largo_medio"),
                ("loss", "perdida"),
                # Dos señales de alarma, no de resultado:
                # - fraccion_cortada alta quiere decir que las respuestas chocan
                #   contra el límite de tokens y nunca cierran el formato, así
                #   que la recompensa mide truncamiento en vez de calidad.
                # - grupos_sin_senal es la fracción de grupos donde todas las
                #   respuestas puntúan igual; ahí GRPO no tiene gradiente.
                ("completions/clipped_ratio", "fraccion_cortada"),
                ("frac_reward_zero_std", "grupos_sin_senal"),
                ("entropy", "entropia"),
            ]:
                if origen in logs:
                    fila[destino] = float(logs[origen])
            if len(fila) > 1:
                historial.append(fila)
                reg.metricas({k: v for k, v in fila.items() if k != "paso"}, paso=fila["paso"])

        def _guardar(self, paso, modelo):
            destino = resolver_ruta(config, "artefactos", corrida_id, f"checkpoint_{paso}")
            modelo.save_pretrained(str(destino))
            # Verificar que se haya escrito un adaptador válido. Una carpeta
            # vacía pasa cualquier chequeo de existencia y recién falla al
            # servirla, horas después.
            if not (Path(destino) / "adapter_config.json").exists():
                raise RuntimeError(
                    f"El checkpoint {paso} quedó sin adapter_config.json en {destino}."
                )
            print(f"[alinear] checkpoint {paso} guardado en {destino}")

        def on_train_begin(self, args, state, control, **kwargs):
            # El checkpoint 0 se guarda en este punto: on_step_end se dispara
            # después de cada paso, así que cuando corre por primera vez el
            # contador ya vale 1 y el paso 0 no existe nunca.
            if 0 in checkpoints:
                self._guardar(0, kwargs["model"])

        def on_step_end(self, args, state, control, **kwargs):
            paso = int(state.global_step)
            if paso in checkpoints and paso != 0:
                self._guardar(paso, kwargs["model"])

    return Seguimiento()


def _puerto_libre(puerto: int) -> bool:
    """Verdadero si se puede escuchar en ese puerto ahora mismo."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", puerto))
            return True
        except OSError:
            return False


def _reservar_puerto() -> None:
    """Garantiza que torch.distributed tenga un puerto que pueda escuchar.

    No alcanza con preguntar si MASTER_PORT está definido: el entorno suele
    traerlo fijado en 29500, y ese puerto queda tomado apenas un proceso
    anterior lo usó, situación habitual cuando una corrida se interrumpió o
    cuando el kernel de un notebook ya inicializó un grupo de procesos. Lo que
    corresponde comprobar es si el puerto está libre, no si la variable existe.
    """
    os.environ.setdefault("MASTER_ADDR", "127.0.0.1")
    actual = os.environ.get("MASTER_PORT")

    if actual and actual.isdigit() and _puerto_libre(int(actual)):
        print(f"[alinear] torch.distributed en el puerto {actual} (ya fijado)")
        return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        puerto = s.getsockname()[1]
    os.environ["MASTER_PORT"] = str(puerto)

    motivo = f"{actual} estaba ocupado" if actual else "no había ninguno fijado"
    print(f"[alinear] torch.distributed en el puerto {puerto} ({motivo})")


def _opciones_generacion(config: dict, cfg_grpo: dict) -> dict:
    """Decide si los rollouts los genera vLLM o transformers.

    Con vLLM en modo colocado el generador corre dentro del proceso del
    entrenador y comparte memoria, lo que hace viable un método on-policy en una
    sola GPU. Sin vLLM el entrenamiento funciona igual, con menor velocidad.
    """
    if not cfg_grpo.get("usar_vllm", True):
        print("[alinear] vLLM desactivado: los rollouts los genera transformers")
        return {"use_vllm": False}

    ventana = (config["modelo"]["largo_maximo_prompt"]
               + config["modelo"]["largo_maximo_respuesta"] + 64)
    return {
        "use_vllm": True,
        "vllm_mode": "colocate",
        "vllm_max_model_length": ventana,
        "vllm_gpu_memory_utilization":
            config["evaluacion"]["servidor"]["utilizacion_memoria"] * 0.4,
    }


def alinear(config: dict, brazo: str, semilla: int) -> dict:
    # Antes de importar peft y trl: esas importaciones arrastran accelerate,
    # que deja MASTER_PORT fijado en el entorno.
    _reservar_puerto()

    from peft import LoraConfig
    from trl import GRPOConfig, GRPOTrainer

    cfg_grpo = config["grpo"]
    cfg_lora = cfg_grpo["lora"]
    beta = config["brazos"][brazo]["beta"]
    corrida_id = id_corrida(brazo, semilla)
    entorno = capturar_entorno(config["modelo"]["precision"])

    if entorno["gpu_nombre"] in ("cpu", "sin_torch"):
        raise RuntimeError(
            "La etapa 1 necesita GPU. Para validar el encadenado del pipeline sin "
            "GPU, utilizar `make prueba` (modo simulado)."
        )
    if config["modelo"]["precision"] == "bfloat16" and not entorno["soporta_bfloat16"]:
        raise RuntimeError(
            f"El perfil pide bfloat16 y la GPU {entorno['gpu_nombre']} no lo soporta. "
            "Utilizar el perfil t4."
        )

    dataset = _dataset(config)
    historial: list[dict] = []

    salida = resolver_ruta(config, "artefactos", corrida_id)
    args = GRPOConfig(
        output_dir=str(salida),
        seed=semilla,
        beta=beta,                                   # contención por KL: la variable del experimento
        num_generations=cfg_grpo["tamano_grupo"],
        # TRL exige que el lote de generación sea múltiplo del tamaño de grupo,
        # porque cada prompt produce exactamente un grupo de respuestas. Si se
        # deja librado al cálculo por defecto (lote x acumulación), cualquier
        # combinación que no divida de forma exacta aborta la corrida. Fijarlo aquí lo
        # vuelve válido para cualquier tamaño de grupo del perfil.
        generation_batch_size=cfg_grpo["lote_prompts"] * cfg_grpo["tamano_grupo"],
        per_device_train_batch_size=cfg_grpo["lote_prompts"],
        gradient_accumulation_steps=cfg_grpo["acumulacion_gradiente"],
        learning_rate=cfg_grpo["tasa_aprendizaje"],
        max_steps=cfg_grpo["pasos_totales"],
        # GRPOConfig no tiene max_prompt_length (eso es de DPO y RLOO). El largo
        # del prompt se acota por la ventana que se le da al generador.
        max_completion_length=config["modelo"]["largo_maximo_respuesta"],
        temperature=cfg_grpo["temperatura"],
        **_opciones_generacion(config, cfg_grpo),
        bf16=config["modelo"]["precision"] == "bfloat16",
        fp16=config["modelo"]["precision"] == "float16",
        logging_steps=5,
        save_strategy="no",                          # los checkpoints los maneja el callback
        report_to=[],
    )

    lora = LoraConfig(
        r=cfg_lora["r"],
        lora_alpha=cfg_lora["alpha"],
        lora_dropout=cfg_lora["dropout"],
        target_modules=cfg_lora["modulos"],
        task_type="CAUSAL_LM",
    )

    etiquetas = {"etapa": "alineacion", "brazo": brazo, "semilla": semilla,
                 "perfil": config["_perfil"]}
    with registro.corrida(config, f"alinear__{corrida_id}", etiquetas) as reg:
        reg.parametros({"brazo": brazo, "semilla": semilla, "beta": beta,
                        "modelo": config["modelo"], "grpo": cfg_grpo,
                        "recompensa": config["recompensa"], "entorno": entorno})

        entrenador = GRPOTrainer(
            model=config["modelo"]["base"],
            args=args,
            reward_funcs=construir_funcion_trl(config["recompensa"]),
            train_dataset=dataset,
            peft_config=lora,
            callbacks=[_callback_metricas(config, corrida_id, reg, historial)],
        )
        entrenador.train()

        ruta_hist = resolver_ruta(config, "artefactos", corrida_id, "historial.json")
        with open(ruta_hist, "w", encoding="utf-8") as f:
            json.dump({"corrida": corrida_id, "brazo": brazo, "semilla": semilla,
                       "beta": beta, "entorno": entorno, "historial": historial},
                      f, ensure_ascii=False, indent=2)
        reg.artefacto(ruta_hist)

    print(f"[alinear] {corrida_id} terminada. Historial en {ruta_hist}")
    return {"corrida": corrida_id, "historial": str(ruta_hist)}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Etapa 1: alineación con GRPO. Correr como script, no desde "
                    "un notebook: vLLM necesita descriptores de archivo reales."
    )
    parser.add_argument("--perfil", default=None)
    parser.add_argument("--brazo", default=None, help="Por omisión corre todos los brazos")
    parser.add_argument("--semilla", type=int, default=None)
    parser.add_argument("--pasos", type=int, default=None,
                        help="Sobrescribe pasos_totales; para la prueba de compatibilidad")
    parser.add_argument("--grupo", type=int, default=None,
                        help="Sobrescribe tamano_grupo")
    args = parser.parse_args()

    config = cargar_config(args.perfil)
    if args.pasos is not None:
        config["grpo"]["pasos_totales"] = args.pasos
        config["grpo"]["checkpoints"] = [0, args.pasos]
    if args.grupo is not None:
        config["grpo"]["tamano_grupo"] = args.grupo

    brazos = [args.brazo] if args.brazo else list(config["brazos"])
    semillas = [args.semilla] if args.semilla is not None else config["semillas"]

    for brazo in brazos:
        for semilla in semillas:
            alinear(config, brazo, semilla)


if __name__ == "__main__":
    main()
