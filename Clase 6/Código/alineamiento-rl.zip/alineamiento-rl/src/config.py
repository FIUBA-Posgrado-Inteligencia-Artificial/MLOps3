"""Carga de perfiles de configuración con herencia simple.

Un solo código, varios perfiles. El perfil decide modelo, precisión, tamaños y
rutas; el código no conoce el entorno en el que corre.
"""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any

import yaml

RAIZ = Path(__file__).resolve().parent.parent
DIR_CONFIG = RAIZ / "config"


def _fusionar(base: dict, encima: dict) -> dict:
    """Fusiona dos diccionarios en profundidad. Los valores de `encima` tienen
    precedencia."""
    salida = copy.deepcopy(base)
    for clave, valor in encima.items():
        if clave in salida and isinstance(salida[clave], dict) and isinstance(valor, dict):
            salida[clave] = _fusionar(salida[clave], valor)
        else:
            salida[clave] = copy.deepcopy(valor)
    return salida


def cargar_config(perfil: str | None = None) -> dict[str, Any]:
    """Carga un perfil y resuelve la cadena de herencia.

    El perfil se toma del argumento, de la variable de entorno PERFIL o, en su
    defecto, de 'local'.
    """
    perfil = perfil or os.environ.get("PERFIL", "local")
    nombre = perfil if perfil.endswith(".yaml") else f"{perfil}.yaml"
    ruta = DIR_CONFIG / nombre
    if not ruta.exists():
        disponibles = ", ".join(sorted(p.stem for p in DIR_CONFIG.glob("*.yaml")))
        raise FileNotFoundError(f"No existe el perfil {nombre}. Disponibles: {disponibles}")

    with open(ruta, encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    padre = config.pop("hereda", None)
    if padre:
        config = _fusionar(cargar_config(padre), config)

    config["_perfil"] = Path(nombre).stem

    # El modelo del juez se puede fijar por entorno. Resulta conveniente cuando
    # se ejecuta en Colab o en un contenedor, donde editar el perfil es engorroso.
    modelo_juez = os.environ.get("JUEZ_MODELO")
    if modelo_juez:
        config["evaluacion"]["juez"]["modelo"] = modelo_juez
    backend_juez = os.environ.get("JUEZ_BACKEND")
    if backend_juez:
        config["evaluacion"]["juez"]["backend"] = backend_juez

    return config


def _verificar_drive(base: Path) -> None:
    """Falla si la ruta apunta a Drive y Drive no está montado.

    Sin esto, mkdir crea /content/drive/MyDrive/... como carpetas locales
    vacías y todo parece funcionar: el entrenamiento escribe adaptadores que
    se pierden al cerrar la sesión, y la evaluación no encuentra nada sin que
    quede claro por qué. Por ese motivo la ejecución se detiene en este punto.
    """
    if not str(base).startswith("/content/drive"):
        return
    if os.path.ismount("/content/drive"):
        return
    raise RuntimeError(
        f"El perfil escribe en {base}, pero Drive no está montado. "
        "Debe montarse antes de continuar:\n\n"
        "    from google.colab import drive\n"
        "    drive.mount('/content/drive')\n\n"
        "Si ya hay carpetas locales espurias en /content/drive, deben borrarse antes "
        "con shutil.rmtree('/content/drive')."
    )


def resolver_ruta(config: dict, clave: str, *partes: str) -> Path:
    """Devuelve una ruta del perfil, creando el directorio si hace falta."""
    base = Path(config["rutas"][clave])
    if not base.is_absolute():
        base = RAIZ / base
    _verificar_drive(base)
    ruta = base.joinpath(*partes)
    directorio = ruta.parent if ruta.suffix else ruta
    directorio.mkdir(parents=True, exist_ok=True)
    return ruta


def id_corrida(brazo: str, semilla: int) -> str:
    return f"{brazo}__semilla{semilla}"
