# Clase 6, Destilación de conocimiento con DoRA

Se entrena un modelo de lenguaje de 0.5B parámetros con GRPO contra una función
de recompensa programática deliberadamente mal calibrada: el término que premia
la brevedad tiene mayor peso que el que premia la corrección. La política
converge a una estrategia degenerada, abandona el razonamiento y produce
únicamente la etiqueta con el resultado. La recompensa de entrenamiento alcanza
su máximo mientras la exactitud medida cae por debajo de la del modelo sin
entrenar.

El componente de LLMOps es la compuerta de despliegue. Un modelo juez compara el
artefacto contra su propia base y cuatro reglas conjuntivas determinan si se
promueve. La compuerta rechaza el artefacto cuya métrica de entrenamiento es la
más alta de la corrida.

El objeto del ejercicio es ese desacuerdo: la métrica disponible durante el
entrenamiento no es suficiente para decidir un despliegue.

---

## Contenido de la carpeta

```
src/                         el pipeline, 9 módulos
config/                      perfiles de configuración: base, local, t4
notebooks/
  pipeline_completo.ipynb    notebook de Colab, ejecuta el pipeline completo
que_aprendio_el_modelo.ipynb análisis de resultados, sin GPU
generaciones_ck*.jsonl       respuestas de la corrida realizada en T4
Makefile                     comandos de cada etapa
```

---

## Ejecución

### A · Sin GPU

Ejecuta el pipeline completo con datos simulados, en menos de un minuto, para
verificar el encadenamiento de las etapas y obtener la decisión de la compuerta.

```bash
python3 -m pip install pyyaml numpy matplotlib

make datos                   # construye los conjuntos verificables
make prueba                  # simula, analiza y decide
```

`make prueba` encadena tres pasos: `simular.py` genera respuestas y juicios con
el mismo esquema que producen las etapas reales, `analizar.py` ejecuta la
estadística y produce la figura, y `compuerta.py` emite el veredicto.

Los valores resultantes son sintéticos y no constituyen evidencia experimental.
Lo que se verifica es el encadenamiento de las etapas y el esquema de los
reportes.

### B · Con GPU

Las etapas 1 y 2 requieren GPU y sesiones separadas: una T4 no admite
simultáneamente el entrenamiento y el modelo juez.

```bash
python3 -m pip install -r requirements.txt

make datos     PERFIL=t4
make alinear   PERFIL=t4     # etapa 1 · GRPO + LoRA, vLLM genera     [GPU]
make generar   PERFIL=t4     # etapa 2a · vLLM sirve los adaptadores  [GPU]
make juzgar    PERFIL=t4     # etapa 2b · el juez puntúa los pares    [GPU]
make analizar  PERFIL=t4     # etapa 3 · bootstrap, IC, figura        [CPU]
make compuerta PERFIL=t4     # etapa 3 · decisión de despliegue       [CPU]
```

`make evaluar` ejecuta `generar` y `juzgar` de forma consecutiva, cuando la
memoria disponible lo admite.

En Colab, `notebooks/pipeline_completo.ipynb` reproduce esta secuencia sección
por sección, junto con la instalación de dependencias y el montaje de Drive. No
contiene lógica propia: invoca los mismos scripts.

### C · Análisis de resultados existentes

`que_aprendio_el_modelo.ipynb` lee los archivos `generaciones_ck*.jsonl`
incluidos en la carpeta y documenta el comportamiento aprendido, sin GPU ni
entrenamiento.

```bash
python3 -m pip install pyyaml numpy
jupyter notebook que_aprendio_el_modelo.ipynb
```

### Limpieza entre corridas

```bash
make limpiar                 # elimina artefactos, reportes, figuras y datos
```

---

## Las tres etapas

| Etapa | Función | Recurso |
|---|---|---|
| 1 · alineación | GRPO con LoRA, vLLM genera los rollouts | **GPU** |
| 2 · evaluación | vLLM sirve el artefacto, el juez puntúa | **GPU** |
| 3 · análisis y compuerta | estadística, intervalos, decisión, figura | **CPU** |

La etapa 2 se divide en dos fases que no coexisten. En la primera se sirve el
modelo en el puerto 8000 y las generaciones se escriben a disco. A continuación
ese servidor se detiene y se levanta el del juez en el puerto 8001.

---

## Perfiles

Un único código y tres perfiles con herencia simple. El perfil determina modelo,
precisión, tamaños y rutas. El código no tiene conocimiento del entorno.

| perfil | modelo | pasos | checkpoints | grupo |
|---|---|---|---|---|
| `base` | Qwen2.5-1.5B | 200 | 0, 50, 100, 150, 200 | 8 |
| `local` | hereda de base, GPU de 24 GB | 200 | 0, 50, 100, 150, 200 | 8 |
| `t4` | Qwen2.5-0.5B, float16, rutas en Drive | 150 | 50, 100, 150 | 6 |

La T4 no dispone de bfloat16, por lo que `t4.yaml` reduce la precisión a float16
y emplea un modelo de menor tamaño.

```bash
make alinear PERFIL=t4
```

---

## Componentes de GRPO y de LLMOps

**GRPO.** Se genera un grupo de respuestas por problema, se las puntúa, y la
ventaja relativa dentro del grupo constituye la señal de aprendizaje. Al no
requerir modelo de valor, el consumo de memoria se mantiene acotado.

- la función de recompensa (`src/recompensas.py`) es código legible en su
  totalidad: formato, corrección verificable y brevedad. No hay modelo de
  recompensa entrenado. El peso de brevedad está mal calibrado de forma
  deliberada
- el coeficiente de KL constituye el mecanismo de contención y es la única
  variable que distingue los dos brazos del experimento
- la generación en cada paso domina el presupuesto de cómputo, lo que justifica
  la presencia de vLLM dentro del bucle de entrenamiento

**LLMOps.** vLLM interviene en tres funciones: genera los rollouts durante el
entrenamiento en modo colocado, sirve el artefacto durante la evaluación y sirve
al modelo juez en un puerto distinto.

- la evaluación se ejecuta contra el endpoint servido y no dentro del proceso de
  entrenamiento, con el adaptador cargado en tiempo de serving
- el artefacto es una tupla: modelo base, adaptador, configuración de serving y
  entorno. El reporte registra GPU, capacidad de cómputo, versiones y precisión
- la compuerta es código (`src/compuerta.py`) y consta de cuatro reglas
  conjuntivas más una señal de advertencia que no bloquea
- registro y linaje en MLflow, por corrida, semilla y checkpoint

---

## Estructura del código

```
src/
  config.py      carga de perfiles con herencia
  entorno.py     captura del entorno como parte del artefacto
  datos.py       problemas verificables, generados localmente
  recompensas.py las tres funciones de recompensa
  registro.py    MLflow con degradación elegante
  alinear.py     etapa 1 · GRPO
  evaluar.py     etapa 2 · servir, generar, juzgar
  analizar.py    etapa 3 · bootstrap, test pareado, figura
  compuerta.py   etapa 3 · decisión de despliegue
  simular.py     modo de prueba sin GPU
```

---

## Preparación del paquete

Dos elementos no deben incluirse en la distribución.

```bash
rm -rf src/__pycache__ config/entorno_destino.json
```

`config/entorno_destino.json` lo fija cada máquina la primera vez que ejecuta la
compuerta. Si se incluye en el paquete, la compuerta compara contra el entorno
de otra instalación y rechaza por un motivo que no corresponde.

---

## Uso docente

El entregable recomendado es la etapa 3. Se proporcionan los artefactos y los
reportes de las corridas ya realizadas, y el trabajo consiste en el
pre-registro, la estadística y la decisión de la compuerta. Esto elimina la
dependencia de GPU y las interrupciones de sesión sin reducir el contenido
conceptual.

`PREREGISTRO.md` se completa y se congela antes de ejecutar el primer
experimento.

---

## Línea de trabajo abierta

Queda por determinar si el reward hacking puede detectarse sin modelo juez,
empleando únicamente señales internas como la KL, la entropía de la política y
el largo medio de las respuestas. De ser posible, el costo de la compuerta se
reduciría de forma sustancial. El derrumbe del largo ya se reporta como
advertencia, sin umbral fijado de antemano. Convertirlo en criterio de promoción
exige demostrar que no produce falsos positivos. La cuestión no está resuelta y
constituye una línea de trabajo final.

---

## Restricciones conocidas

- **Las versiones son la restricción más frágil**, con dos dependencias
  encadenadas. TRL declara las versiones de vllm que acepta en su extra `[vllm]`
  (trl 0.28 requiere `>=0.10.2,<0.13.0`, trl 1.14 requiere
  `>=0.20.0,<=0.30.0`). A su vez, cada vllm fija una versión exacta de torch:
  hasta 0.26.0 es `torch==2.11.0`, de 0.27.0 en adelante `torch==2.13.0`, que no
  dispone de wheel de Linux en PyPI y provoca que pip intente compilarlo. Por
  este motivo el proyecto fija `vllm==0.26.0` y no emplea el extra `trl[vllm]`.
  Tras la primera instalación correcta conviene ejecutar
  `python3 -m pip freeze > requirements.lock.txt`.
- **`max_prompt_length` no existe en `GRPOConfig`**, aunque sí en `DPOConfig` y
  `RLOOConfig`. La ventana del generador se fija con `vllm_max_model_length`.
- **La etapa 1 se ejecuta como script y nunca dentro de una celda.** vLLM lanza
  procesos de trabajo y requiere el descriptor de archivo del stdout, del que un
  notebook no dispone. La ejecución termina con `UnsupportedOperation: fileno`.
  Por este motivo los notebooks invocan `src/alinear.py` con `!python`.
- **Colab incluye torchao 0.10 preinstalado** y peft requiere una versión
  superior a 0.16, por lo que debe actualizarse antes de entrenar.
- **GRPO es inestable.** Resulta sensible al tamaño del grupo, al coeficiente de
  KL y a la temperatura, y puede colapsar a respuestas degeneradas. En el aula
  esto constituye contenido, siempre que la corrida se haya realizado con
  anterioridad.
- **El modelo juez domina el presupuesto.** Por ese motivo el análisis de
  potencia se realiza antes de evaluar: determina cuántos prompts son necesarios
  y evita consumo innecesario. Con un efecto mínimo detectable de 0.15 se
  requieren 85 prompts, reducirlo a 0.10 eleva la cifra a 194 y duplica el
  costo.
