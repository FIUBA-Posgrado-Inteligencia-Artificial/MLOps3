"""motor alternativo: MiniCPM5-2B-Jev a traves de su endpoint /v1/systemone

modelo entrenado para decidir, con pesos abiertos (Apache 2.0); lo publica un
tercero (github.com/yuting-ai/minicpm5-2b-jev) y no TypeSafe AI, por lo que
es compatible con Jev pero no es un Jev oficial; es opcional y se usa con
JEV_MOTOR=api

para iniciarlo, en otra terminal:

    cd ~/Documents/llmops/clase7/MiniCPM5-2B-Jev
    source .venv/bin/activate
    python serve.py --host 127.0.0.1 --port 8013
"""

import hashlib
import json
import urllib.error
import urllib.request

import datos

URL = "http://127.0.0.1:8013"
MODELO = "MiniCPM5-2B-Jev"


def consulta(texto: str) -> dict:
    """arma el JSON que requiere este servidor

    el formato difiere del proyecto original aunque ambos usen /v1/systemone:
    aqui questions es un diccionario por nombre, el texto va en instructions y
    las opciones en criteria, cada una con su descripcion
    """
    return {
        "state": texto,
        "questions": {
            "area": {
                "kind": "choice",
                "instructions": "A que area de soporte corresponde este ticket?",
                "criteria": {a: datos.DESCRIPCIONES[a] for a in datos.AREAS},
            }
        },
    }


def buscar_probs(obj, claves: list[str]) -> dict[str, float] | None:
    """busca en la respuesta un diccionario con una probabilidad por area

    la busqueda es recursiva porque el repositorio no documenta el formato
    """
    if isinstance(obj, dict):
        if all(k in obj for k in claves) and all(
                isinstance(obj[k], (int, float)) for k in claves):
            total = sum(float(obj[k]) for k in claves)
            if total > 0:
                return {k: float(obj[k]) / total for k in claves}
        for v in obj.values():
            if (h := buscar_probs(v, claves)):
                return h
    elif isinstance(obj, list):
        for v in obj:
            if (h := buscar_probs(v, claves)):
                return h
    return None


def decidir(texto: str, modelo: str = MODELO, formato: str = "") -> list[float]:
    """devuelve las probabilidades de las cuatro areas, igual que jev.decidir()

    mantener la misma firma permite cambiar de motor sin modificar calibrar.py
    ni correr.py
    """
    pedido = urllib.request.Request(
        f"{URL}/v1/systemone",
        data=json.dumps(consulta(texto)).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(pedido, timeout=120) as r:
            respuesta = json.loads(r.read())
    except urllib.error.URLError as e:
        raise RuntimeError(
            f"No responde el Jev abierto en {URL}: {e}\n"
            "Inicielo con: python serve.py --host 127.0.0.1 --port 8013"
        ) from e

    probs = buscar_probs(respuesta, datos.AREAS)
    if not probs:
        raise RuntimeError(
            "La respuesta no incluye probabilidades por area. Respuesta recibida:\n"
            + json.dumps(respuesta, ensure_ascii=False)[:600]
        )
    return [probs[a] for a in datos.AREAS]


def version(modelo: str = MODELO) -> dict | None:
    """nombre del modelo, o None si no responde; este servidor no informa digest

    prueba /health, que es el documentado, y luego /healthz
    """
    for ruta in ("/health", "/healthz"):
        try:
            with urllib.request.urlopen(f"{URL}{ruta}", timeout=5) as r:
                salud = json.loads(r.read())
            return {"modelo": str(salud.get("model", MODELO)), "digest": "-"}
        except (urllib.error.URLError, TimeoutError, OSError, ValueError):
            pass
    # si no hay endpoint de estado, se prueba con una decision
    try:
        decidir("prueba de conexion")
        return {"modelo": MODELO, "digest": "-"}
    except Exception:
        return None


def huella() -> str:
    """hash del JSON enviado sin el ticket, incluidas las descripciones

    cambiar la descripcion de un area cambia la pregunta, por eso se incluye
    """
    cuerpo = json.dumps(consulta(""), sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(cuerpo.encode("utf-8")).hexdigest()[:12]
