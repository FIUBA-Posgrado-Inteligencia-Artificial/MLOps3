"""compara los dos motores sobre los mismos 50 tickets

    jev       qwen en Ollama, leyendo la probabilidad de cada digito
    jev_api   MiniCPM5-2B-Jev, mediante /v1/systemone

entre ambos cambian el modelo, el entrenamiento y el prompt, por lo que la
diferencia de accuracy no se puede atribuir a un solo factor; lo que si se
puede comparar es la brecha entre confianza y acierto

es opcional y requiere iniciar MiniCPM en otra terminal:

    cd ~/Documents/llmops/clase7/MiniCPM5-2B-Jev
    source .venv/bin/activate
    python serve.py --host 127.0.0.1 --port 8013

    python3 comparar_motores.py
"""

import time

import datos
import jev
import jev_api


def medir(motor) -> dict | None:
    if not motor.version():
        return None
    aciertos, confianzas, t0 = 0, [], time.perf_counter()
    for texto, real in datos.TICKETS:
        p = motor.decidir(texto)
        aciertos += p.index(max(p)) == real
        confianzas.append(max(p))
    acc = aciertos / len(datos.TICKETS)
    conf = sum(confianzas) / len(confianzas)
    return {"accuracy": acc, "confianza": conf, "brecha": conf - acc,
            "ms": (time.perf_counter() - t0) / len(datos.TICKETS) * 1000,
            "altas": sum(c >= 0.9 for c in confianzas)}


def main() -> None:
    print(f"{len(datos.TICKETS)} tickets, los mismos para los dos\n")
    print(f"{'motor':<10}{'accuracy':>10}{'confianza':>11}{'brecha':>9}"
          f"{'ms':>8}{'conf>=0.9':>11}")

    resultados = {}
    for nombre, motor in [("ollama", jev), ("jev_api", jev_api)]:
        r = medir(motor)
        resultados[nombre] = r
        if not r:
            print(f"{nombre:<10}{'no responde en ' + motor.URL:>49}")
            continue
        print(f"{nombre:<10}{r['accuracy']:>10.3f}{r['confianza']:>11.3f}"
              f"{r['brecha']:>+9.3f}{r['ms']:>8.0f}{r['altas']:>11}")

    a, b = resultados.get("ollama"), resultados.get("jev_api")
    if not (a and b):
        print("\nFalta uno de los dos motores. La comparacion necesita ambos")
        return

    print("\nbrecha: confianza media menos accuracy")
    print("Una brecha cercana a cero indica que la confianza coincide con el acierto")
    print("y que no es necesario calibrar")
    print("\nEntre las dos filas cambian tres cosas a la vez: el modelo, su")
    print("entrenamiento y el prompt. Aislar el efecto del entrenamiento")
    print("requiere fijar las otras dos, en un experimento separado")
    print("\nPara usar uno u otro en el resto del proyecto:")
    print("  python3 calibrar.py                 # el metodo sobre Ollama")
    print("  JEV_MOTOR=api python3 calibrar.py   # el Jev abierto")


if __name__ == "__main__":
    main()
