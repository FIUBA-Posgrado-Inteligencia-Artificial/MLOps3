"""monitorea un lote de trafico nuevo frente a los 50 tickets de referencia

en produccion no hay etiquetas, por lo que se vigila:

    configuracion   digest del modelo y huella del prompt frente al artefacto
    entradas        palabras no vistas y largo de los tickets
    salidas         area elegida y nivel de confianza

usa el motor y la temperatura de artefacto.json y agrega cada decision a
monitoreo.jsonl

    python3 monitorear.py semana_1
    python3 monitorear.py semana_2

cada senal incluye una prueba de permutacion (2000 mezclas aleatorias de
referencia y lote) para obtener un valor p; con 30 y 50 tickets el PSI por
si solo es inestable: aqui, dos muestras de la misma distribucion superan
0.2 una de cada diez veces
"""

import importlib
import json
import math
import random
import re
import sys
import time
import unicodedata
from collections import Counter
from datetime import datetime
from pathlib import Path

import calibrar
import datos
import trafico

ARTEFACTO = Path("artefacto.json")
LOG = Path("monitoreo.jsonl")
UMBRAL = 0.75            # igual a la politica equilibrada de correr.py; si se cambia, cambiar ambos
PERMUTACIONES = 2000
SEMILLA = 0
P_DERIVA = 0.01          # son cuatro pruebas; con 0.05 apareceria deriva por azar con frecuencia
P_VIGILAR = 0.05

CAT_LARGO = ["1-6", "7-9", "10-14", "15+"]
CAT_CONF = ["<0.50", "0.50-0.75", "0.75-0.90", ">=0.90"]


# medidas de cada ticket

def palabras(texto: str) -> list[str]:
    """lista de palabras en minuscula y sin tildes ('contraseña' equivale a 'contrasena')"""
    t = unicodedata.normalize("NFKD", texto.lower()).encode("ascii", "ignore").decode()
    return re.findall(r"[a-z0-9]+", t)


def largo(texto: str) -> str:
    n = len(palabras(texto))
    return "1-6" if n <= 6 else "7-9" if n <= 9 else "10-14" if n <= 14 else "15+"


def tramo_confianza(c: float) -> str:
    return ("<0.50" if c < 0.50 else "0.50-0.75" if c < 0.75
            else "0.75-0.90" if c < 0.90 else ">=0.90")


def fuera_de_vocabulario(texto: str, vocab: set[str]) -> float:
    """fraccion de palabras del ticket que no estan en vocab"""
    ws = palabras(texto)
    return sum(w not in vocab for w in ws) / len(ws) if ws else 0.0


# el prompt del sistema y los ejemplos cuentan como vocabulario conocido
BASE = [datos.SISTEMA] + [t for t, _ in datos.EJEMPLOS]


def vocabulario(textos: list[str]) -> set[str]:
    return {w for t in textos for w in palabras(t)}


def oov_referencia() -> list[float]:
    """palabras no vistas de cada ticket de referencia, sin contar ese ticket

    si el vocabulario incluyera al ticket medido, la referencia daria siempre 0%
    y cualquier lote nuevo pareceria distinto
    """
    textos = [t for t, _ in datos.TICKETS]
    return [fuera_de_vocabulario(t, vocabulario(BASE + textos[:i] + textos[i + 1:]))
            for i, t in enumerate(textos)]


# estadisticos y prueba de permutacion

def psi(a: list[str], b: list[str], categorias: list[str]) -> float:
    """indice de estabilidad poblacional (PSI) entre dos listas de categorias

    se suma 0.5 a cada conteo para evitar log(0) cuando falta una categoria
    """
    k = len(categorias)
    ca, cb = Counter(a), Counter(b)
    pa = [(ca[c] + 0.5) / (len(a) + 0.5 * k) for c in categorias]
    pb = [(cb[c] + 0.5) / (len(b) + 0.5 * k) for c in categorias]
    return sum((y - x) * math.log(y / x) for x, y in zip(pa, pb))


def diferencia_medias(a: list[float], b: list[float]) -> float:
    return sum(b) / len(b) - sum(a) / len(a)


def permutacion(ref: list, nuevo: list, estadistico, rng: random.Random) -> tuple[float, float]:
    """devuelve el estadistico observado y su valor p por permutacion"""
    obs = estadistico(ref, nuevo)
    todo, n, extremos = list(ref) + list(nuevo), len(ref), 0
    for _ in range(PERMUTACIONES):
        rng.shuffle(todo)
        if estadistico(todo[:n], todo[n:]) >= obs - 1e-12:
            extremos += 1
    return obs, (extremos + 1) / (PERMUTACIONES + 1)


def veredicto(p: float) -> str:
    return "deriva" if p < P_DERIVA else "a vigilar" if p < P_VIGILAR else "estable"


# ejecucion

def cargar_motor(art: dict):
    """importa el motor indicado en el artefacto"""
    nombre = art.get("motor", "jev")
    if nombre not in ("jev", "jev_api", "jev_destilado"):
        raise SystemExit(f"motor desconocido en el artefacto: {nombre}")
    return importlib.import_module(nombre)


def revisar_configuracion(motor, art: dict) -> list[str]:
    """compara el digest y la huella actuales con los del artefacto

    detecta, por ejemplo, un ollama pull que trajo otros pesos con el mismo
    nombre o un prompt modificado; en ese caso hay que recalibrar
    """
    v = motor.version()
    if not v:
        raise SystemExit(f"No responde el motor {art.get('motor')}. "
                         "Ejecute primero: python3 probar.py")
    cambios = []
    if v["digest"] != art["digest"]:
        cambios.append(f"digest del modelo: calibrado {art['digest']}, "
                       f"sirviendo {v['digest']}")
    if motor.huella() != art["huella"]:
        cambios.append(f"huella del prompt: calibrada {art['huella']}, "
                       f"actual {motor.huella()}")
    return cambios


def referencia(art: dict) -> list[dict]:
    """area, confianza, largo y palabras no vistas de los tickets de referencia

    se obtiene de las probabilidades guardadas en el artefacto, sin consultar el
    modelo
    """
    filas = []
    for (texto, _), oov in zip(datos.TICKETS, oov_referencia()):
        p = calibrar.aplicar_t(art["probabilidades"][datos.clave(texto)],
                               art["temperatura"])
        filas.append({"area": datos.AREAS[p.index(max(p))], "confianza": max(p),
                      "largo": largo(texto), "fuera_vocab": oov})
    return filas


def decidir_lote(motor, art: dict, nombre: str, lote: list) -> tuple[list[dict], int]:
    vocab = vocabulario(BASE + [t for t, _ in datos.TICKETS])
    corrida = datetime.now().isoformat(timespec="seconds")
    registros, errores = [], 0
    for texto, _ in lote:
        t0 = time.perf_counter()
        try:
            p = calibrar.aplicar_t(motor.decidir(texto), art["temperatura"])
        except RuntimeError as e:
            # se registra el error y se continua con el resto
            errores += 1
            print(f"  error en un ticket: {e}")
            continue
        registros.append({
            "corrida": corrida, "lote": nombre, "artefacto": art["hash"],
            "motor": art.get("motor", "jev"), "texto": texto,
            "area": datos.AREAS[p.index(max(p))],
            "confianza": round(max(p), 4), "escala": max(p) < UMBRAL,
            "ms": round((time.perf_counter() - t0) * 1000, 1),
            "largo": largo(texto),
            "fuera_vocab": round(fuera_de_vocabulario(texto, vocab), 3),
        })
    # se agrega al final del registro sin sobrescribirlo
    with LOG.open("a", encoding="utf-8") as f:
        for r in registros:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return registros, errores


def historial() -> None:
    filas = [json.loads(l) for l in LOG.read_text(encoding="utf-8").splitlines() if l.strip()]
    corridas: dict = {}
    for r in filas:
        corridas.setdefault((r["corrida"], r["lote"], r["artefacto"]), []).append(r)
    print(f"\nhistorial ({LOG}, ultimas 8 corridas)")
    print(f"{'corrida':<21}{'lote':<11}{'artefacto':<18}{'n':>4}"
          f"{'conf':>7}{'escala':>8}{'vocab nuevo':>13}")
    for (corrida, lote, art), rs in list(corridas.items())[-8:]:
        n = len(rs)
        print(f"{corrida:<21}{lote:<11}{art:<18}{n:>4}"
              f"{sum(r['confianza'] for r in rs) / n:>7.3f}"
              f"{sum(r['escala'] for r in rs) / n:>8.0%}"
              f"{sum(r['fuera_vocab'] for r in rs) / n:>13.0%}")


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in trafico.LOTES:
        raise SystemExit(f"uso: python3 monitorear.py {{{','.join(trafico.LOTES)}}}")
    nombre = sys.argv[1]
    if not ARTEFACTO.exists():
        raise SystemExit("Falta artefacto.json. Ejecute primero: python3 calibrar.py")
    art = json.loads(ARTEFACTO.read_text(encoding="utf-8"))
    motor = cargar_motor(art)
    lote = trafico.LOTES[nombre]

    print(f"lote {nombre}: {len(lote)} tickets nuevos")
    print(f"desplegado: artefacto {art['hash']}  motor {art.get('motor', 'jev')}"
          f"  T={art['temperatura']}")

    print("\n1. configuracion")
    cambios = revisar_configuracion(motor, art)
    if cambios:
        for c in cambios:
            print(f"   alerta: {c}")
        print("   La temperatura y los umbrales se ajustaron con otra configuracion.")
        print("   Ejecute de nuevo calibrar.py antes de interpretar lo que sigue")
    else:
        print("   el modelo y el prompt son los mismos que se calibraron")
    if art.get("motor") == "jev_destilado" and Path("artefacto_destilado.json").exists():
        dest = json.loads(Path("artefacto_destilado.json").read_text(encoding="utf-8"))
        if nombre in dest.get("lotes_transferencia", []):
            print(f"   alerta: {nombre} se uso para entrenar el mapa del alumno.")
            print("   Este lote mide sobre datos que el modelo ya vio.")
            print("   Para vigilar al alumno, use un lote que no este en")
            print("   LOTES_TRANSFERENCIA de destilar.py")

    ref = referencia(art)
    nuevos, errores = decidir_lote(motor, art, nombre, lote)
    if not nuevos:
        raise SystemExit("No se pudo decidir ningun ticket")

    print("\n2. salud del servicio")
    ms = sorted(r["ms"] for r in nuevos)
    p95 = ms[min(len(ms) - 1, math.ceil(0.95 * len(ms)) - 1)]
    print(f"   {len(nuevos)} decididos, {errores} con error, "
          f"latencia mediana {ms[len(ms) // 2]:.0f} ms, p95 {p95:.0f} ms")
    esc_ref = sum(r["confianza"] < UMBRAL for r in ref) / len(ref)
    esc_lote = sum(r["escala"] for r in nuevos) / len(nuevos)
    print(f"   escalan al LLM (confianza < {UMBRAL}): {esc_lote:.0%} del lote, "
          f"{esc_ref:.0%} en la referencia")

    print("\n3. deriva, contra los 50 tickets de referencia")
    print(f"   {'señal':<32}{'lo que mas cambio':<26}{'estadistico':>12}{'p':>8}   veredicto")
    rng = random.Random(SEMILLA)
    pruebas = []

    a = [r["fuera_vocab"] for r in ref]
    b = [r["fuera_vocab"] for r in nuevos]
    obs, p = permutacion(a, b, diferencia_medias, rng)
    cambio = f"media {sum(a) / len(a):.0%} a {sum(b) / len(b):.0%}"
    pruebas.append(("entrada: palabras nunca vistas", cambio, f"{obs:+.3f}", p))

    for senal, clave, cats in [("entrada: largo en palabras", "largo", CAT_LARGO),
                               ("salida: area elegida", "area", datos.AREAS),
                               ("salida: tramo de confianza", "conf", CAT_CONF)]:
        if clave == "conf":
            a = [tramo_confianza(r["confianza"]) for r in ref]
            b = [tramo_confianza(r["confianza"]) for r in nuevos]
        else:
            a, b = [r[clave] for r in ref], [r[clave] for r in nuevos]
        obs, p = permutacion(a, b, lambda x, y, c=cats: psi(x, y, c), rng)
        # categoria con mayor cambio, para mostrar que se movio y no solo cuanto
        ca, cb = Counter(a), Counter(b)
        cat = max(cats, key=lambda c: abs(cb[c] / len(b) - ca[c] / len(a)))
        cambio = f"{cat} {ca[cat] / len(a):.0%} a {cb[cat] / len(b):.0%}"
        pruebas.append((senal, cambio, f"PSI {obs:.3f}", p))

    for senal, cambio, est, p in pruebas:
        print(f"   {senal:<32}{cambio:<26}{est:>12}{p:>8.4f}   {veredicto(p)}")

    # palabras no vistas mas frecuentes del lote
    vocab = vocabulario(BASE + [t for t, _ in datos.TICKETS])
    nuevas = Counter(w for r in nuevos for w in set(palabras(r["texto"])) if w not in vocab)
    if nuevas:
        print("   palabras nuevas mas repetidas: "
              + ", ".join(f"{w} ({n})" for w, n in nuevas.most_common(8)))

    print("\n4. lectura")
    derivas = [s for s, _, _, p in pruebas if p < P_DERIVA]
    vigilar = [s for s, _, _, p in pruebas if P_DERIVA <= p < P_VIGILAR]
    if cambios:
        print("Hay deriva de configuracion. Debe resolverse antes de revisar los datos")
    if derivas:
        print("Hay deriva en: " + "; ".join(derivas))
        print("Se recomienda revisar una muestra del lote, etiquetarla,")
        print("agregarla a datos.py y volver a calibrar. La temperatura y los umbrales")
        print("se ajustaron con tickets distintos a los que llegan ahora")
    elif vigilar:
        print("Señales a vigilar: " + "; ".join(vigilar))
        print("No alcanza para afirmar deriva. Conviene revisar el proximo lote")
    else:
        print(f"No se detecta deriva. Esto no prueba que no exista: con "
              f"{len(nuevos)} tickets solo se detectan cambios grandes")
    print("Son cuatro pruebas a la vez. Por eso se exige p < 0.01 para afirmar")
    print("deriva y no p < 0.05, que con cuatro pruebas se alcanzaria por azar")

    # auditoria: usa las etiquetas de trafico.py, que en produccion no existirian
    reales = {t: a for t, a in lote}
    ok = [r["area"] == datos.AREAS[reales[r["texto"]]] for r in nuevos]
    resueltas = [o for r, o in zip(nuevos, ok) if not r["escala"]]
    print("\n5. auditoria (solo en clase: en produccion esta etiqueta no existe)")
    print(f"   accuracy real del lote {sum(ok) / len(ok):.3f}; en lo que no escalo, "
          + (f"{sum(resueltas) / len(resueltas):.3f} sobre {len(resueltas)}"
             if resueltas else "no resolvio nada"))
    print(f"   referencia, en prueba: {art['metricas']['sin calibrar']['accuracy']:.3f}")


    historial()


if __name__ == "__main__":
    main()
