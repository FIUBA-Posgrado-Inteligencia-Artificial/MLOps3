# jev-destilacion

Proyecto de LLMOps que clasifica tickets de soporte en cuatro áreas (facturación, técnico, cuenta y otro) con un modelo de lenguaje que corre en su propia computadora. El modelo no genera texto para decidir: se leen las probabilidades que asigna a cada opción. A partir de esa decisión, el proyecto mide, calibra, abarata y monitorea el sistema.

No requiere GPU ni servicios en la nube.

## Requisitos

| recurso | mínimo |
|---|---|
| sistema operativo | macOS, Linux o Windows (probado en macOS) |
| memoria RAM | 8 GB (se recomiendan 16 GB) |
| espacio en disco | 4 GB libres |
| conexión a internet | solo para la instalación |

## 1. Instalar Python

El proyecto necesita Python 3.10 o una versión más reciente. Para saber si ya está instalado, abra una terminal y ejecute:

```bash
python3 --version
```

En Windows el comando es `python --version`.

Si el comando no existe o la versión es anterior a 3.10, instale Python desde https://www.python.org/downloads/. En Windows, durante la instalación marque la opción **Add python.exe to PATH**. En Linux (Ubuntu o Debian) puede instalarlo con:

```bash
sudo apt install python3 python3-pip python3-venv
```

## 2. Instalar Ollama

Ollama ejecuta los modelos de lenguaje en su computadora. Descárguelo desde https://ollama.com/download.

En macOS y Windows, instale la aplicación y ábrala. Mientras esté abierta, el servicio queda activo.

En Linux, ejecute:

```bash
curl -fsSL https://ollama.com/install.sh | sh
```

Para comprobar la instalación:

```bash
ollama --version
```

## 3. Descargar los modelos

Se usan dos modelos. El primero toma las decisiones y el segundo se usa en la destilación.

```bash
ollama pull qwen2.5:1.5b-instruct
ollama pull qwen2.5:3b-instruct
```

La descarga ocupa cerca de 3 GB y se hace una sola vez.

## 4. Descargar el proyecto

Descargue el archivo zip y descomprímalo. Luego abra una terminal dentro de la carpeta del proyecto:

```bash
cd ~/Downloads/jev-destilacion
```

En Windows, desde PowerShell:

```powershell
cd $HOME\Downloads\jev-destilacion
```

Si descomprimió el zip en otra ubicación, ajuste la ruta.

## 5. Comprobar que todo funciona

```bash
python3 probar.py
```

El resultado debe terminar con `Todo listo`. Si aparece un error, consulte la sección de problemas frecuentes.

## 6. Ejecutar el proyecto

Ejecute los comandos en este orden:

```bash
python3 comparar.py
python3 calibrar.py
python3 correr.py
python3 monitorear.py semana_1
python3 destilar.py
JEV_MOTOR=destilado python3 calibrar.py
python3 correr.py
python3 monitorear.py semana_2
```

La ejecución completa toma unos diez minutos.

Si `destilar.py` indica que el modelo destilado no se adopta, el comando siguiente se detiene con un aviso. Es el comportamiento esperado: continúe con los dos últimos comandos.

En Windows, reemplace `python3` por `python` y la sexta línea por:

```powershell
$env:JEV_MOTOR="destilado"; python calibrar.py; Remove-Item Env:JEV_MOTOR
```

## 7. Notebooks (opcional)

El proyecto incluye dos notebooks:

| notebook | contenido |
|---|---|
| `entender_jev.ipynb` | introducción al método de Jev con un ejemplo de reseñas de productos; es independiente del resto del proyecto y conviene revisarlo primero |
| `explorar.ipynb` | ejecuta los pasos del proyecto y muestra los resultados intermedios |

Para usarlos, instale Jupyter una sola vez:

```bash
python3 -m pip install notebook
```

Luego abra el notebook que desea revisar:

```bash
jupyter notebook entender_jev.ipynb
jupyter notebook explorar.ipynb
```

Se abrirá en el navegador. En el menú **Kernel**, elija **Restart Kernel and Run All Cells** (en versiones anteriores de Jupyter se llama **Restart & Run All**). Al terminar, guarde con Ctrl+S (Cmd+S en macOS).

Si modifica un archivo `.py`, reinicie el kernel antes de volver a ejecutar las celdas.

En Windows, algunas celdas de `explorar.ipynb` usan comandos de macOS y Linux y pueden fallar. En ese caso, ejecute los pasos desde la terminal.

## Archivos del proyecto

| archivo | función |
|---|---|
| `datos.py` | áreas, prompt del sistema y tickets etiquetados |
| `probar.py` | verifica que Ollama y el modelo respondan |
| `jev.py` | toma la decisión leyendo probabilidades |
| `comparar.py` | compara dos formatos de prompt |
| `calibrar.py` | evalúa, ajusta la temperatura y guarda `artefacto.json` |
| `correr.py` | aplica umbrales de confianza y estima costos |
| `destilar.py` | entrena el modelo destilado y decide si se adopta |
| `jev_destilado.py` | permite usar el modelo destilado si fue adoptado |
| `trafico.py` | tickets simulados de dos semanas de uso |
| `monitorear.py` | vigila cambios en los tickets que llegan |
| `entender_jev.ipynb` | introducción al método de Jev |
| `explorar.ipynb` | recorrido del proyecto con sus resultados |
| `jev_api.py`, `comparar_motores.py` | motor alternativo opcional, no necesario para el curso |

Los archivos `artefacto.json`, `artefacto_destilado.json`, `decisiones.jsonl` y `monitoreo.jsonl` se generan al ejecutar el proyecto.

## Problemas frecuentes

| mensaje | solución |
|---|---|
| `command not found: python3` | instale Python (paso 1); en Windows use `python` |
| `TypeError: unsupported operand type(s) for \|` al ejecutar cualquier script | su versión de Python es anterior a 3.10; actualícela |
| `Ollama no responde o no tiene el modelo qwen2.5:1.5b-instruct` | abra la aplicación Ollama o ejecute `ollama serve` en otra terminal; luego repita el paso 3 |
| `Ollama no devuelve logprobs` | actualice Ollama a la versión más reciente |
| `Ollama no tiene el maestro qwen2.5:3b-instruct` | ejecute `ollama pull qwen2.5:3b-instruct` |
| `address already in use` al ejecutar `ollama serve` | Ollama ya está activo; no es necesario hacer nada |
| `externally-managed-environment` al instalar Jupyter | cree un entorno virtual: `python3 -m venv .venv`, luego `source .venv/bin/activate` y repita la instalación |
| `has no attribute` en el notebook | reinicie el kernel (menú **Kernel**, opción **Restart**) |
