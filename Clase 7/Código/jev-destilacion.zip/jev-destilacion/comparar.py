"""compara la accuracy del mismo modelo con dos formatos de prompt

    plano    texto sin marcas
    chatml   con las marcas de turno del modelo (<|im_start|> ...)

la diferencia muestra que el formato del prompt afecta la decision; por eso
su huella se guarda en el artefacto

    python3 comparar.py
"""

import datos
import jev

FORMATOS = ["plano", "chatml"]


def main() -> None:
    if not jev.version():
        raise SystemExit("Ollama no responde. Ejecute primero: python3 probar.py")

    print(f"{len(datos.TICKETS)} tickets, modelo {jev.MODELO}")
    print("Con cuatro areas, el azar acierta 0.250\n")
    print(f"{'formato':<10}{'accuracy':>10}{'confianza media':>18}{'brecha':>9}")

    for formato in FORMATOS:
        aciertos, confianzas = 0, []
        for texto, real in datos.TICKETS:
            p = jev.decidir(texto, formato=formato)
            aciertos += p.index(max(p)) == real
            confianzas.append(max(p))
        acc = aciertos / len(datos.TICKETS)
        conf = sum(confianzas) / len(confianzas)
        print(f"{formato:<10}{acc:>10.3f}{conf:>18.3f}{conf - acc:>+9.3f}")

    print("\nbrecha: confianza media menos accuracy")
    print("Un modelo bien calibrado tiene una brecha cercana a cero")
    print("\nSi chatml obtiene mejor resultado, el formato del prompt forma parte")
    print("de la decision. Por eso su hash se guarda en el artefacto")


if __name__ == "__main__":
    main()
