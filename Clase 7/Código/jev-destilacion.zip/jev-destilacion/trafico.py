"""dos semanas de tickets simulados de produccion, distintos de los de datos.py

    semana_1   los mismos temas de siempre con otra redaccion (control)
    semana_2   tickets en portugues, pagos con QR y correos largos (deriva)

cada ticket incluye su area, pero monitorear.py solo la usa en la auditoria
final; en produccion esa etiqueta no existiria

areas: 0 facturacion, 1 tecnico, 2 cuenta, 3 otro
"""

LOTES = {
    "semana_1": [
        ("Me cobraron dos veces el mismo mes.", 0),
        ("El importe del plan anual esta mal.", 0),
        ("Quiero el reembolso del cobro de octubre.", 0),
        ("No me llego la factura de este mes.", 0),
        ("Me cobraron el plan profesional y tengo el basico.", 0),
        ("El cargo de julio aparece dos veces en la tarjeta.", 0),
        ("Cuanto sale agregar un usuario mas al plan?", 0),
        ("Me cobraron impuestos que no me corresponden pagar.", 0),
        ("La app tira error cuando subo un archivo.", 1),
        ("El panel no carga desde ayer a la tarde.", 1),
        ("Los graficos quedan en blanco en el celular.", 1),
        ("El boton de exportar da error en Chrome.", 1),
        ("La aplicacion va muy lenta al buscar.", 1),
        ("Se cierra sola cuando abro el panel.", 1),
        ("Me aparece error 500 en la pagina.", 1),
        ("La sincronizacion de archivos no termina nunca.", 1),
        ("No puedo entrar, dice clave incorrecta.", 2),
        ("Quiero cambiar la contrasena de mi cuenta.", 2),
        ("Necesito dar de baja mi cuenta este mes.", 2),
        ("No me llega el correo de verificacion.", 2),
        ("Quiero agregar a una persona a mi equipo.", 2),
        ("Mi cuenta quedo suspendida y no se por que.", 2),
        ("Quiero pasar del plan basico al plan profesional.", 2),
        ("Como cambio el correo de mi cuenta?", 2),
        ("Tienen oficina en Cordoba?", 3),
        ("Cual es el horario de atencion?", 3),
        ("Hacen descuentos para estudiantes de la universidad?", 3),
        ("Ofrecen capacitacion para todo el equipo de ventas?", 3),
        ("Donde mando mi cv?", 3),
        ("Tienen la aplicacion disponible en ingles?", 3),
    ],
    "semana_2": [
        # lanzamiento en Brasil
        ("Fui cobrado duas vezes na fatura deste mês.", 0),
        ("Não consigo acessar minha conta, a senha não funciona.", 2),
        ("O aplicativo trava quando envio uma foto.", 1),
        ("Quero cancelar minha assinatura.", 2),
        ("O valor da fatura está errado.", 0),
        ("A página fica carregando e não abre.", 1),
        ("Vocês têm suporte por telefone no sábado?", 3),
        ("Como altero o e-mail do meu cadastro?", 2),
        ("O relatório não exporta para PDF.", 1),
        ("Quero o reembolso da cobrança duplicada.", 0),
        ("Onde fica o escritório de vocês em São Paulo?", 3),
        ("Recebi um código de verificação que não pedi.", 2),
        # producto nuevo: pagos con QR
        ("El pago con QR me descuenta la plata pero el plan sigue impago.", 0),
        ("Escaneo el QR de pago y la camara se queda negra.", 1),
        ("Pague con QR y no me llego el comprobante.", 0),
        ("El QR de cobro vence antes de que pueda pagar.", 1),
        ("Mercado Pago rechaza el QR del plan anual.", 0),
        ("El QR acepta billeteras virtuales?", 3),
        ("Me debitaron dos veces al pagar con QR.", 0),
        ("Desde la actualizacion del QR la app se cierra al pagar.", 1),
        ("Como activo los cobros con QR para mis clientes?", 3),
        # clientes corporativos: correos largos con saludo y firma
        ("Buenas tardes, les escribo porque desde el martes pasado, cuando "
         "intento ingresar con mi usuario habitual, el sistema me informa que "
         "la cuenta fue deshabilitada. Agradeceria una pronta respuesta. "
         "Saludos cordiales, Ing. Martin Gomez, Gerente de Operaciones", 2),
        ("Estimados: por medio de la presente solicito la refacturacion del "
         "comprobante emitido el 3 de septiembre, dado que figura la razon "
         "social anterior de nuestra empresa. Quedo atento. Atte., Lic. "
         "Carolina Ruiz, Administracion", 0),
        ("Hola equipo, como estan? Estamos evaluando migrar toda la empresa a "
         "su plataforma el proximo trimestre y quisieramos coordinar una "
         "reunion para conocer los planes corporativos y las condiciones de "
         "soporte. Muchas gracias!", 3),
        ("Buen dia. El modulo de reportes presenta una demora considerable al "
         "generar los informes mensuales, en algunos casos superior a diez "
         "minutos, lo cual afecta el cierre contable. Adjunto capturas. "
         "Saludos.", 1),
        ("Hola, que tal. Hace dos semanas solicite la baja del servicio por "
         "correo y hoy veo que me volvieron a debitar la cuota mensual completa "
         "de la tarjeta corporativa. Necesito que me devuelvan ese importe. "
         "Gracias.", 0),
        ("Buenas, consulto si existe la posibilidad de transferir la "
         "titularidad de la cuenta a otro integrante de la organizacion, ya "
         "que la persona responsable dejo la empresa. Desde ya, muchas "
         "gracias.", 2),
        ("Estimado soporte: al intentar sincronizar el calendario con la "
         "aplicacion movil se produce un error inesperado y luego se pierden "
         "los cambios realizados sin conexion. Cordialmente, Pablo.", 1),
        ("Buen dia, queria felicitarlos por la atencion recibida la semana "
         "pasada, la persona que me atendio fue muy amable y resolvio todo "
         "rapidamente. Sigan asi. Saludos, Laura.", 3),
        ("Hola! El descuento anual que figura en la web, se aplica tambien si "
         "ya estoy pagando el plan mensual o tengo que esperar al vencimiento "
         "para pasarme? Gracias de antemano.", 0),
    ],
}
