"""areas, prompt del sistema, ejemplos y tickets etiquetados

cada area incluye su definicion en el prompt; sin ella el modelo tiene que
adivinar que significa "cuenta" u "otro"; la division entre desarrollo y
prueba se hace por hash del texto para que no dependa del orden en que se
escribieron los tickets
"""

import hashlib

AREAS = ["facturacion", "tecnico", "cuenta", "otro"]

SISTEMA = """Clasificas tickets de soporte en un area.

0 facturacion: cobros, importes, facturas, reembolsos, precios.
1 tecnico: la aplicacion falla, da error, no carga, va lenta.
2 cuenta: acceso, contrasena, datos personales, suscripcion, baja.
3 otro: cualquier otra cosa.

Un cargo mal hecho es facturacion, no cuenta.
No poder entrar es cuenta, no tecnico.
Responde solo con el numero del area entre corchetes."""

# descripcion de cada area para jev_api.py, que la exige su contrato;
# debe coincidir con lo que dice SISTEMA
DESCRIPCIONES = {
    "facturacion": "cobros, importes, facturas, reembolsos, precios",
    "tecnico": "la aplicacion falla, da error, no carga, va lenta",
    "cuenta": "acceso, contrasena, datos personales, suscripcion, baja",
    "otro": "consultas generales, comerciales o cualquier otra cosa",
}

EJEMPLOS = [
    ("Me cobraron dos veces el plan de marzo.", 0),
    ("La aplicacion se cierra sola al abrir el panel.", 1),
    ("Olvide mi contrasena y no me llega el correo.", 2),
    ("Quiero saber si tienen oficinas en Cordoba.", 3),
]

TICKETS = [
    ("Me cobraron 49 dolares y el plan cuesta 29.", 0),
    ("El importe de la factura de octubre esta mal.", 0),
    ("Pague dos veces por error, quiero el reembolso.", 0),
    ("No entiendo por que me cobraron impuestos aparte.", 0),
    ("La promocion del 20% no se aplico a mi cobro.", 0),
    ("Me siguen facturando un plan que ya no uso.", 0),
    ("Necesito la factura de setiembre con mi CUIT.", 0),
    ("El cargo aparece dos veces en el resumen.", 0),
    ("Me cobraron en dolares y pedi en pesos.", 0),
    ("Quiero saber cuanto sale el plan anual.", 0),
    ("Cancele en junio y me cobraron en julio.", 0),
    ("El reembolso que me prometieron no llego.", 0),
    ("La app tira error 500 cuando guardo.", 1),
    ("No carga el panel, queda en blanco.", 1),
    ("Se cierra sola cada vez que subo un archivo.", 1),
    ("Los graficos no se actualizan desde ayer.", 1),
    ("La busqueda devuelve resultados de otro usuario.", 1),
    ("Tarda mas de un minuto en abrir cualquier pagina.", 1),
    ("El boton de exportar no hace nada.", 1),
    ("Me aparece pantalla negra en el celular.", 1),
    ("La sincronizacion quedo trabada hace dos dias.", 1),
    ("Al imprimir salen los datos corridos.", 1),
    ("El mapa no carga en Firefox, en Chrome si.", 1),
    ("Subo una foto y se corta a la mitad.", 1),
    ("No puedo entrar, dice usuario o clave incorrectos.", 2),
    ("Quiero cambiar el correo de mi cuenta.", 2),
    ("Necesito dar de baja la suscripcion.", 2),
    ("No me llega el codigo de verificacion.", 2),
    ("Quiero agregar a un companero a mi equipo.", 2),
    ("Mi cuenta aparece suspendida y no se por que.", 2),
    ("Quiero cambiar del plan basico al profesional.", 2),
    ("Perdi el acceso al segundo factor.", 2),
    ("Como borro mi cuenta y todos mis datos?", 2),
    ("Necesito cambiar el nombre de la empresa en el perfil.", 2),
    ("Me desloguea cada cinco minutos.", 2),
    ("Quiero reactivar la cuenta que cerre el ano pasado.", 2),
    ("Tienen atencion telefonica los sabados?", 3),
    ("Donde queda su oficina en Rosario?", 3),
    ("Quiero trabajar con ustedes, donde mando el cv?", 3),
    ("Hacen descuentos para organizaciones sin fines de lucro?", 3),
    ("Me gusto mucho la ultima actualizacion, felicitaciones.", 3),
    ("Tienen la aplicacion en portugues?", 3),
    ("Puedo integrar esto con mi sistema de facturacion?", 3),
    ("Quien es el responsable de datos personales?", 3),
    ("Ofrecen capacitacion para equipos grandes?", 3),
    ("Cual es el horario de soporte?", 3),
    # ambiguos a proposito: mencionan palabras de un area pero pertenecen a otra
    ("Me cobraron de mas y encima no puedo entrar a reclamar.", 0),
    ("No puedo pagar porque el boton de pago da error.", 1),
    ("Quiero cancelar porque me parece caro.", 2),
    ("La factura no se descarga, tira error.", 1),
]


def espacio() -> list[str]:
    """opciones numeradas, tal como aparecen en el prompt"""
    return [f"{i} {a}" for i, a in enumerate(AREAS)]


def clave(texto: str) -> str:
    """hash del texto; identifica al ticket en el artefacto y en la division"""
    return hashlib.sha1(texto.encode("utf-8")).hexdigest()


def split(frac_dev: float = 0.6) -> tuple[list[int], list[int]]:
    """division estratificada por area entre desarrollo y prueba, 60/40 por defecto

    dentro de cada area los tickets se ordenan por hash y no por orden de
    aparicion; en el proyecto original, dividir por orden cambiaba la accuracy
    en 0.067 entre desarrollo y prueba
    """
    dev, test = [], []
    for area in range(len(AREAS)):
        idx = [i for i, (_, a) in enumerate(TICKETS) if a == area]
        idx.sort(key=lambda i: clave(TICKETS[i][0]))
        corte = round(len(idx) * frac_dev)
        dev += idx[:corte]
        test += idx[corte:]
    return sorted(dev), sorted(test)
