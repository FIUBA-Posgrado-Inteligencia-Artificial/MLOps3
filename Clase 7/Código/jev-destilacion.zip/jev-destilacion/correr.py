"""aplica tres umbrales de confianza a las decisiones y estima el costo

si la confianza alcanza el umbral, el ticket se resuelve; si no, escala al
modelo generativo, que es la parte costosa; las decisiones se leen de
artefacto.json sin volver a consultar el modelo; ademas se redactan tres
borradores de muestra para medir tokens y tiempo

    python3 correr.py
"""

import json
from pathlib import Path

import calibrar
import datos
import jev        # la generacion se hace siempre con Ollama

# USD_DECISION: precio publicado de Jev por millon de tokens de entrada
# USD_GENERATIVO: valor de referencia; debe reemplazarse por el del proveedor
# TOKENS_ENTRADA: largo del prompt con cuatro ejemplos, medido en destilar.py
# con prompt_eval_count (247.6)
USD_DECISION = 0.042
USD_GENERATIVO = 3.00
TOKENS_ENTRADA = 248
TOKENS_SALIDA = 120     # maximo de num_predict en redactar()

POLITICAS = [("conservadora", 0.95), ("equilibrada", 0.75), ("agresiva", 0.50)]
# al pedir solo "dos oraciones" el modelo devolvia listas y negritas; por
# eso se prohibe el formato y se corta en el primer salto de linea doble
PLANTILLA = ("Formas parte del equipo de soporte del area de {area}.\n"
             "Escribe la respuesta al cliente en un solo parrafo corrido de dos "
             "oraciones.\n"
             "No uses listas, numeracion, vinetas, titulos ni negritas.\n"
             "No saludes ni te despidas. No prometas plazos.\n\n"
             "Ticket: {texto}\n\n"
             "Respuesta al cliente:")


def redactar(texto: str, area: str) -> dict | None:
    """pide un borrador de respuesta al modelo generativo; devuelve texto, tokens y ms"""
    try:
        d = jev.pedir({"model": jev.MODELO,
                       "prompt": PLANTILLA.format(area=area, texto=texto),
                       "stream": False,
                       "options": {"num_predict": TOKENS_SALIDA, "temperature": 0.3,
                                   "stop": ["\n\n", "\n1.", "\n- ", "\n*"]}})
    except Exception:
        return None
    return {"texto": d.get("response", "").strip(),
            "tokens": int(d.get("eval_count", 0)),
            "ms": d.get("total_duration", 0) / 1e6}

def comentario(medidas: list[tuple]) -> None:
    """imprime la conclusion solo si la tabla la respalda

    advierte cuando una politica resuelve menos de 10 casos y no afirma que un
    umbral mayor mejora el acierto si los datos no lo muestran
    """
    MINIMO = 10
    chicas = [(n, r) for n, _, r, a in medidas if a is not None and r < MINIMO]
    utiles = [(n, r, a) for n, _, r, a in medidas if a is not None and r >= MINIMO]
    monotona = all(x[2] >= y[2] for x, y in zip(utiles, utiles[1:]))

    if chicas:
        print()
        for nombre, r in chicas:
            print(f"La fila {nombre} resuelve solo {r} casos, su acierto "
                  f"no es confiable")
        print(f"Se necesitan al menos {MINIMO} casos para interpretarlo")

    if len(utiles) < 2:
        print("\nNo hay filas con casos suficientes para comparar umbrales")
    elif monotona:
        print("\nEn las filas con casos suficientes, un umbral mas alto resuelve")
        print("menos tickets y acierta mas. Esto es abstenerse, y es lo que hace util")
        print("a una probabilidad")
    else:
        print("\nEn las filas con casos suficientes, la relacion no es monotona.")
        print("Con esta muestra no se puede afirmar que un umbral mas alto mejore el")
        print("acierto, aunque sea lo esperado. Se necesitan mas tickets")


def tokens_decision(art: dict) -> float:
    """tokens de entrada por decision segun el motor del artefacto

    se leen de artefacto_destilado.json, donde los midio destilar.py; para
    jev_api no hay medicion y se usa TOKENS_ENTRADA
    """
    ruta = Path("artefacto_destilado.json")
    if ruta.exists():
        d = json.loads(ruta.read_text(encoding="utf-8"))
        if art.get("motor") == "jev_destilado":
            return d["tokens_alumno"]
        if art.get("motor", "jev") == "jev":
            return d.get("tokens_desplegado", d["tokens_maestro"])
    return TOKENS_ENTRADA


def main() -> None:
    ruta = Path("artefacto.json")
    if not ruta.exists():
        raise SystemExit("Falta artefacto.json. Ejecute primero: python3 calibrar.py")
    art = json.loads(ruta.read_text(encoding="utf-8"))

    print(f"nivel de decision   artefacto {art['hash']}  T={art['temperatura']}"
          f"  motor {art.get('motor', 'jev')}")
    tok_dec = tokens_decision(art)
    v = jev.version()
    print(f"nivel de generacion {v['modelo'] if v else 'Ollama no responde'}"
          f"{'  digest ' + v['digest'] if v else ''}\n")

    # las probabilidades ya estan en el artefacto; no se consulta el modelo
    decisiones = []
    for texto, real in datos.TICKETS:
        p = calibrar.aplicar_t(art["probabilidades"][datos.clave(texto)],
                               art["temperatura"])
        decisiones.append({"texto": texto, "real": datos.AREAS[real],
                           "area": datos.AREAS[p.index(max(p))],
                           "confianza": max(p)})

    print(f"{'politica':<14}{'umbral':>8}{'resuelve':>10}{'escala':>8}"
          f"{'acierto':>9}{'USD':>9}")
    medidas = []
    for nombre, umbral in POLITICAS:
        resueltas = [d for d in decisiones if d["confianza"] >= umbral]
        escalan = len(decisiones) - len(resueltas)
        ok = sum(d["area"] == d["real"] for d in resueltas)
        acierto = ok / len(resueltas) if resueltas else None
        # un ticket que escala paga la entrada y la salida del modelo generativo,
        # igual que en "todo al LLM"
        usd = (len(decisiones) * tok_dec / 1e6 * USD_DECISION
               + escalan * (TOKENS_ENTRADA + TOKENS_SALIDA) / 1e6 * USD_GENERATIVO)
        medidas.append((nombre, umbral, len(resueltas), acierto))
        texto = "-" if acierto is None else f"{acierto:.3f}"
        print(f"{nombre:<14}{umbral:>8.2f}{len(resueltas):>10}{escalan:>8}"
              f"{texto:>9}{usd:>9.5f}")

    todo = len(decisiones) * (TOKENS_ENTRADA + TOKENS_SALIDA) / 1e6 * USD_GENERATIVO
    print(f"{'todo al LLM':<14}{'-':>8}{0:>10}{len(decisiones):>8}"
          f"{'-':>9}{todo:>9.5f}")
    print(f"tokens de entrada: {tok_dec:.0f} por decision, "
          f"{TOKENS_ENTRADA} por llamada al LLM")
    print(f"USD: decision a {USD_DECISION} por millon (precio publicado de Jev);"
          f" generativo a {USD_GENERATIVO:.2f}, valor de referencia")

    # la conclusion se basa en los resultados de la tabla
    comentario(medidas)



    # borradores reales para los tres primeros tickets dudosos
    dudosas = [d for d in decisiones if d["confianza"] < 0.75][:3]
    if dudosas and v:
        print(f"\nescalado real de {len(dudosas)} tickets dudosos")
        bs = [b for d in dudosas if (b := redactar(d["texto"], d["area"]))]
        if bs:
            ms_gen = sum(b["ms"] for b in bs) / len(bs)
            print(f"  {sum(b['tokens'] for b in bs) // len(bs)} tokens y "
                  f"{ms_gen:.0f} ms por borrador, medidos por Ollama")
            print(f"  ejemplo: {bs[0]['texto'][:120]}...")
            print(f"\nUn borrador tarda {ms_gen:.0f} ms, mucho mas que una decision "
                  f"(ver calibrar.py)")
            print("Esa diferencia justifica la capa de decision")

    Path("decisiones.jsonl").write_text(
        "\n".join(json.dumps(d, ensure_ascii=False) for d in decisiones),
        encoding="utf-8")
    bajas = sum(d["confianza"] < 0.6 for d in decisiones)
    print(f"\ndecisiones.jsonl: {len(decisiones)} lineas, "
          f"{bajas} con confianza menor a 0.6, para revision humana")


if __name__ == "__main__":
    main()
