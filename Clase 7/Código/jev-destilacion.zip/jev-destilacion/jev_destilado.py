"""motor del alumno destilado: prompt corto y mapa de destilar.py

tiene la misma interfaz que jev.py, por lo que calibrar.py y correr.py lo
usan sin cambios; antes de decidir verifica tres condiciones y se detiene si
alguna no se cumple:

    adoptado      destilar.py lo aprobo
    modelo        es el mismo modelo con el que se entreno el mapa
    huella        el prompt corto no cambio

el mapa se entreno con un modelo y un prompt especificos y no es valido con
otros

    python3 destilar.py
    JEV_MOTOR=destilado python3 calibrar.py
    python3 correr.py
"""

import hashlib
import json
from pathlib import Path

import jev

URL = jev.URL
MODELO = jev.MODELO
ARTEFACTO = Path("artefacto_destilado.json")

_cache: dict = {}


def _mapa() -> dict:
    """lee artefacto_destilado.json y verifica las tres condiciones"""
    if "d" in _cache:
        return _cache["d"]
    if not ARTEFACTO.exists():
        raise SystemExit("Falta artefacto_destilado.json. "
                         "Ejecute primero: python3 destilar.py")
    d = json.loads(ARTEFACTO.read_text(encoding="utf-8"))
    if "adoptado" not in d:
        raise SystemExit("artefacto_destilado.json es de una version anterior y no "
                         "indica si se adopto.\nEjecute de nuevo: python3 destilar.py")
    if not d["adoptado"]:
        raise SystemExit("El criterio de destilar.py no adopto el mapa, por lo que el alumno "
                         "no puede reemplazar al modelo desplegado.\nContinue con: "
                         "python3 calibrar.py")
    if d["modelo"] != jev.MODELO:
        raise SystemExit(f"El mapa se entreno sobre {d['modelo']} y ahora el modelo "
                         f"es {jev.MODELO}.\nEjecute de nuevo: python3 destilar.py")
    if d.get("huella_alumno") != jev.huella("corto"):
        raise SystemExit("El prompt corto cambio desde que se entreno el mapa.\n"
                         "Ejecute de nuevo: python3 destilar.py")
    _cache["d"] = d
    return d


def decidir(texto: str, modelo: str = MODELO, formato: str = "") -> list[float]:
    """obtiene la decision con el prompt corto y le aplica el mapa"""
    import destilar          # importacion local: destilar importa calibrar y se generaria un ciclo
    d = _mapa()
    p = jev.decidir(texto, modelo, formato="corto")
    return destilar.aplicar((d["W"], d["b"]), p)


def version(modelo: str = MODELO) -> dict | None:
    """modelo de Ollama y hash del mapa"""
    v = jev.version(modelo)
    if not v:
        return None
    d = _mapa()
    return {"modelo": f"{v['modelo']} + mapa {d['hash']}", "digest": v["digest"]}


def huella() -> str:
    """hash del prompt corto combinado con el hash del mapa"""
    base = jev.huella("corto") + _mapa()["hash"]
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:12]
