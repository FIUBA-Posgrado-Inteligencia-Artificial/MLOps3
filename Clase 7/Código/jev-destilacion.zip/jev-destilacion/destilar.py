"""destilacion: un mapa de 20 parametros para que el alumno imite al maestro

    maestro     qwen2.5:3b con cuatro ejemplos     (se imita, no se despliega)
    desplegado  qwen2.5:1.5b con cuatro ejemplos   (decide actualmente)
    alumno      qwen2.5:1.5b sin ejemplos          (menor costo)
    mapa        W de 4x4 y b de 4, aplicados a las probabilidades del alumno

los pesos de qwen no se modifican; el mapa solo recibe las cuatro
probabilidades, no el texto, por lo que corrige sesgos del alumno pero no le
agrega conocimiento

el entrenamiento compara con la distribucion del maestro (KL), no con la
etiqueta; las etiquetas se usan solo para evaluar y para el criterio de
adopcion

    python3 destilar.py
"""

import hashlib
import json
import math
import random
import time
from pathlib import Path

import calibrar
import correr
import datos
import jev
import trafico

ARTEFACTO = Path("artefacto_destilado.json")
MAESTRO = "qwen2.5:3b-instruct"     # debe descargarse antes: ollama pull qwen2.5:3b-instruct
SEMILLA = 0
PASOS = 1000     # se conserva el mejor paso en validacion
PASO_LR = 0.1
PISO = 1e-6      # con 1e-12 el logaritmo vale -27.6 y el gradiente diverge (ver _z)
RECORTE = 5.0    # norma maxima del gradiente
VALIDACION = 6          # tickets de desarrollo reservados para validacion

# semanas de trafico que se suman al entrenamiento sin etiqueta;
# basta con las probabilidades del maestro
#
# se agrega cada semana completa, no solo los tickets dudosos; una semana
# usada aqui no debe usarse para monitorear al alumno (monitorear.py lo
# advierte); validacion y prueba siguen siendo los tickets de datos.py
LOTES_TRANSFERENCIA = ["semana_1"]


def softmax(v: list[float]) -> list[float]:
    m = max(v)
    e = [math.exp(x - m) for x in v]
    s = sum(e)
    return [x / s for x in e]


def _z(p: list[float]) -> list[float]:
    """logaritmo de las probabilidades con piso y centrado; es la entrada del mapa

    sin el piso, una probabilidad cercana a 0 produce un logaritmo muy grande y
    el entrenamiento diverge, como ocurrio en la primera version; centrar no
    altera el softmax y mantiene los valores acotados
    """
    z = [math.log(max(x, PISO)) for x in p]
    m = sum(z) / len(z)
    return [x - m for x in z]


def aplicar(mapa: tuple[list[list[float]], list[float]],
            p: list[float]) -> list[float]:
    """aplica W y b a las probabilidades del alumno y devuelve las corregidas"""
    W, b = mapa
    z = _z(p)
    return softmax([sum(W[j][k] * z[k] for k in range(len(z))) + b[j]
                    for j in range(len(b))])


def kl(p: list[float], q: list[float]) -> float:
    """divergencia KL(p || q): distancia de q (alumno) a p (maestro)"""
    return sum(pi * math.log(max(pi, 1e-12) / max(qi, 1e-12))
               for pi, qi in zip(p, q))


def entrenar(alumno: list[list[float]], maestro: list[list[float]],
             val_alumno: list[list[float]], val_maestro: list[list[float]]
             ) -> tuple[tuple, list[tuple[int, float, float]]]:
    """entrena W y b por descenso de gradiente con el lote completo

    el gradiente de la KL respecto de los logits es q menos p, por lo que no se
    necesita ninguna biblioteca; W inicia como identidad y b en cero, de modo que
    el paso 0 es el alumno sin corregir; cada 20 pasos se mide en validacion y
    se conserva el mejor resultado
    """
    n = len(datos.AREAS)
    W = [[1.0 if j == k else 0.0 for k in range(n)] for j in range(n)]
    b = [0.0] * n
    curva, mejor, mejor_paso, mejor_mapa = [], float("inf"), 0, None

    for paso in range(PASOS + 1):
        if paso % 20 == 0:
            p_tr = sum(kl(m, aplicar((W, b), a))
                       for a, m in zip(alumno, maestro)) / len(alumno)
            p_va = sum(kl(m, aplicar((W, b), a))
                       for a, m in zip(val_alumno, val_maestro)) / len(val_alumno)
            curva.append((paso, p_tr, p_va))
            if p_va < mejor - 1e-6:
                mejor, mejor_paso = p_va, paso
                mejor_mapa = ([fila[:] for fila in W], b[:])

        if paso == PASOS:
            break

        gW = [[0.0] * n for _ in range(n)]
        gb = [0.0] * n
        for a, m in zip(alumno, maestro):
            q = aplicar((W, b), a)
            z = _z(a)
            for j in range(n):
                d = q[j] - m[j]          # gradiente respecto del logit j
                gb[j] += d / len(alumno)
                for k in range(n):
                    gW[j][k] += d * z[k] / len(alumno)

        # recorte por norma para que un paso grande no deshaga lo aprendido
        norma = math.sqrt(sum(x * x for f in gW for x in f) + sum(x * x for x in gb))
        escala = min(1.0, RECORTE / norma) if norma > 0 else 1.0
        for j in range(n):
            b[j] -= PASO_LR * escala * gb[j]
            for k in range(n):
                W[j][k] -= PASO_LR * escala * gW[j][k]

    return (mejor_mapa or (W, b)), curva, mejor_paso


def metricas(probs: list[list[float]], reales: list[int]) -> dict:
    conf = [max(p) for p in probs]
    return {"accuracy": calibrar.accuracy(probs, reales),
            "ece": calibrar.ece(probs, reales),
            "brecha": sum(conf) / len(conf) - calibrar.accuracy(probs, reales)}


def costo_politica(probs: list[list[float]], tok_decision: float) -> tuple[float, int]:
    """costo estimado con la politica equilibrada y cantidad de tickets que escalan

    usa los mismos precios que correr.py: todos los tickets pagan la decision y
    los que no alcanzan el umbral pagan ademas el modelo generativo
    """
    umbral = dict(correr.POLITICAS)["equilibrada"]
    escalan = sum(max(p) < umbral for p in probs)
    usd = (len(probs) * tok_decision / 1e6 * correr.USD_DECISION
           + escalan * (correr.TOKENS_ENTRADA + correr.TOKENS_SALIDA) / 1e6
           * correr.USD_GENERATIVO)
    return usd, escalan


def adoptar(filas: dict, tok_desplegado: float, tok_alumno: float,
            n_test: int, costos: dict) -> tuple[bool, list]:
    """decide si el alumno reemplaza a lo desplegado; deben cumplirse cuatro condiciones

        1. la accuracy no baja mas de un ticket
        2. la brecha entre confianza y accuracy es menor
        3. el ahorro de tokens supera el 10%
        4. el costo total con la politica equilibrada no aumenta

    historial del criterio:

        1. al inicio solo se consideraba la accuracy
        2. se agrego la brecha, porque la confianza determina que tickets escalan
        3. con el maestro de 3b, la comparacion paso a ser contra lo desplegado y
           no contra el maestro, al que el alumno no puede alcanzar; se decidio
           antes de ejecutar
        4. se agrego el costo total, porque el alumno ahorraba tokens pero
           escalaba mas tickets y resultaba mas caro

    modificar el criterio despues de ver un resultado puede sesgar la
    evaluacion; cada cambio debe justificarse por el objetivo del sistema
    """
    actual, mapa = filas["desplegado"], filas["alumno + mapa"]
    crudo, maestro = filas["alumno sin mapa"], filas["maestro"]

    tolerancia = 1.0 / n_test                      # equivale a un ticket
    caida = actual["accuracy"] - mapa["accuracy"]
    mejora_brecha = abs(actual["brecha"]) - abs(mapa["brecha"])
    ahorro = 1 - tok_alumno / tok_desplegado

    print(f"\nEl mapa movio al alumno {mapa['accuracy'] - crudo['accuracy']:+.3f} "
          f"en accuracy y {abs(crudo['brecha']) - abs(mapa['brecha']):+.3f} en brecha")
    print(f"Le falta {maestro['accuracy'] - mapa['accuracy']:+.3f} de accuracy para "
          "igualar al maestro, que es el limite superior")
    print("\ncriterio de adopcion, contra lo desplegado hoy")
    cond = [
        (f"la accuracy no cae mas de un ticket ({tolerancia:.3f})",
         caida <= tolerancia + 1e-9, f"cae {caida:+.3f}"),
        ("la brecha mejora respecto de lo desplegado",
         mejora_brecha > 0, f"mejora {mejora_brecha:+.3f}"),
        ("el ahorro de tokens supera el 10%",
         ahorro > 0.10, f"ahorra {ahorro:.0%}"),
        ("el costo total estimado no sube",
         costos["alumno"][0] <= costos["desplegado"][0] + 1e-12,
         f"{costos['alumno'][0] - costos['desplegado'][0]:+.5f} USD"),
    ]
    for texto, ok, valor in cond:
        print(f"  [{'si' if ok else 'no'}] {texto:<48} {valor}")

    adopta = all(ok for _, ok, _ in cond)
    if adopta:
        print(f"\nSe adopta. El alumno destilado usa {ahorro:.0%} menos tokens "
              "por decision que el modelo desplegado,\ntiene menor brecha y el sistema "
              "completo no cuesta mas")
    else:
        print("\nNo se adopta: no se cumple al menos una condicion")
    print(f"\nCon {n_test} tickets de prueba, {tolerancia:.3f} de accuracy es un "
          "solo ticket.\nSea cual sea el resultado, la diferencia esta dentro "
          "del ruido de muestreo")
    return adopta, [[texto, bool(ok), valor] for texto, ok, valor in cond]


def main() -> None:
    if not jev.version():
        raise SystemExit("Ollama no responde. Ejecute primero: python3 probar.py")
    v_maestro = jev.version(MAESTRO)
    if not v_maestro:
        raise SystemExit(f"Ollama no tiene el maestro {MAESTRO}.\n"
                         f"solucion: ollama pull {MAESTRO}")
    random.seed(SEMILLA)

    print(f"maestro {MAESTRO} (digest {v_maestro['digest']}), alumno {jev.MODELO}")
    print("Cada ticket se decide tres veces: con el maestro, con el modelo "
          "desplegado y con el alumno")
    maestro, desplegado, alumno = {}, {}, {}
    tok_m, tok_d, tok_a, t0 = [], [], [], time.perf_counter()
    for i, (texto, _) in enumerate(datos.TICKETS, 1):
        pm, tm = jev.decidir_detalle(texto, modelo=MAESTRO, formato="chatml")
        pd, td = jev.decidir_detalle(texto, formato="chatml")
        pa, ta = jev.decidir_detalle(texto, formato="corto")
        maestro[texto], desplegado[texto], alumno[texto] = pm, pd, pa
        tok_m.append(tm)
        tok_d.append(td)
        tok_a.append(ta)
        if i % 10 == 0:
            print(f"  {i}/{len(datos.TICKETS)}")

    # trafico de produccion: solo maestro y alumno, sin etiqueta
    transf_m, transf_a = [], []
    for nombre in LOTES_TRANSFERENCIA:
        for texto, _ in trafico.LOTES[nombre]:      # la etiqueta no se usa
            pm, _ = jev.decidir_detalle(texto, modelo=MAESTRO, formato="chatml")
            pa, _ = jev.decidir_detalle(texto, formato="corto")
            transf_m.append(pm)
            transf_a.append(pa)
    if transf_m:
        print(f"  + {len(transf_m)} tickets sin etiqueta de "
              f"{', '.join(LOTES_TRANSFERENCIA)}")

    med_m = sum(tok_m) / len(tok_m)
    med_d = sum(tok_d) / len(tok_d)
    med_a = sum(tok_a) / len(tok_a)
    print(f"{len(datos.TICKETS) * 3 + len(transf_m) * 2} decisiones en "
          f"{time.perf_counter()-t0:.0f} s")
    print(f"tokens de entrada: desplegado {med_d:.0f}, alumno {med_a:.0f} "
          f"({100*(1-med_a/med_d):.0f}% menos por llamada)")
    print("el maestro lee los mismos tokens que el modelo desplegado, con un "
          "modelo del doble de tamaño\n")

    idx_dev, idx_test = datos.split()
    random.shuffle(idx_dev)
    idx_val, idx_tr = idx_dev[:VALIDACION], idx_dev[VALIDACION:]

    def conj(idx, fuente):
        return [fuente[datos.TICKETS[i][0]] for i in idx]

    y_test = [datos.TICKETS[i][1] for i in idx_test]
    mapa, curva, mejor_paso = entrenar(
        conj(idx_tr, alumno) + transf_a, conj(idx_tr, maestro) + transf_m,
        conj(idx_val, alumno), conj(idx_val, maestro))

    print(f"entrenamiento: {len(idx_tr)} etiquetados + {len(transf_m)} sin "
          f"etiqueta, {VALIDACION} de validacion, semilla {SEMILLA}")
    print(f"{'paso':>6}{'KL entrenamiento':>20}{'KL validacion':>16}")
    for paso, tr, va in curva[::max(1, len(curva) // 6)]:
        print(f"{paso:>6}{tr:>20.4f}{va:>16.4f}")
    print(f"se conserva el paso {mejor_paso}, el mejor en validacion")
    subidas = sum(1 for a, b2 in zip(curva, curva[1:]) if b2[1] > a[1] + 1e-9)
    if subidas:
        print(f"Aviso: la perdida de entrenamiento subio en {subidas} de "
              f"{len(curva)-1} mediciones. Con lote completo eso significa que "
              "el paso es muy grande y el entrenamiento no es confiable")
    else:
        print("La perdida de entrenamiento baja en todas las mediciones, como "
              "corresponde con lote completo")
    print()

    filas = {
        "maestro": metricas(conj(idx_test, maestro), y_test),
        "desplegado": metricas(conj(idx_test, desplegado), y_test),
        "alumno sin mapa": metricas(conj(idx_test, alumno), y_test),
        "alumno + mapa": metricas([aplicar(mapa, p) for p in conj(idx_test, alumno)],
                                  y_test),
    }
    modelos = {"maestro": MAESTRO.split(":")[1].split("-")[0],
               "desplegado": jev.MODELO.split(":")[1].split("-")[0]}
    tokens = {"maestro": med_m, "desplegado": med_d}
    print(f"{'en prueba':<18}{'modelo':>8}{'accuracy':>10}{'ECE':>9}{'brecha':>9}{'tokens':>9}")
    for nombre, m in filas.items():
        print(f"{nombre:<18}{modelos.get(nombre, modelos['desplegado']):>8}"
              f"{m['accuracy']:>10.3f}{m['ece']:>9.4f}"
              f"{m['brecha']:>+9.3f}{tokens.get(nombre, med_a):>9.0f}")

    # costo total en prueba con la politica equilibrada y sin temperatura
    alumno_mapa = [aplicar(mapa, p) for p in conj(idx_test, alumno)]
    costos = {"desplegado": costo_politica(conj(idx_test, desplegado), med_d),
              "alumno": costo_politica(alumno_mapa, med_a)}
    umbral = dict(correr.POLITICAS)["equilibrada"]
    print(f"\ncosto estimado en prueba, politica equilibrada (umbral {umbral}):")
    for nombre, (usd, esc) in costos.items():
        print(f"  {nombre:<12} {usd:.5f} USD, escalan {esc} de {len(idx_test)}")

    adopta, criterio = adoptar(filas, med_d, med_a, len(idx_test), costos)

    # jev_destilado.py lee "adoptado" antes de permitir que decida el alumno
    cuerpo = {
        "modelo": jev.MODELO, "modelo_maestro": MAESTRO,
        "digest_maestro": v_maestro["digest"], "huella_maestro": jev.huella(),
        "huella_alumno": jev.huella("corto"), "adoptado": adopta,
        "semilla": SEMILLA, "pasos": PASOS, "lr": PASO_LR,
        "paso_conservado": mejor_paso, "n_entrenamiento": len(idx_tr),
        "lotes_transferencia": LOTES_TRANSFERENCIA,
        "n_transferencia": len(transf_m),
        "tokens_maestro": round(med_m, 1), "tokens_desplegado": round(med_d, 1),
        "tokens_alumno": round(med_a, 1),
        "metricas": filas, "curva": curva,
        # se guardan para que el notebook los muestre sin volver a ejecutar
        "criterio": criterio,
        "costos": {k: {"usd": round(usd, 6), "escalan": esc}
                   for k, (usd, esc) in costos.items()},
        "W": mapa[0], "b": mapa[1],
    }
    sello = hashlib.sha256(
        json.dumps(cuerpo, sort_keys=True).encode("utf-8")).hexdigest()[:16]
    ARTEFACTO.write_text(json.dumps({"hash": sello, **cuerpo}, indent=1,
                                    ensure_ascii=False), encoding="utf-8")
    print(f"\n{ARTEFACTO} sellado  hash {sello}")
    print("Incluye la semilla y los pasos, por lo que repetirlo produce el mismo mapa")
    if adopta:
        print("\nPara que el alumno reemplace al modelo desplegado:")
        print("  JEV_MOTOR=destilado python3 calibrar.py")
        print("  python3 correr.py")


if __name__ == "__main__":
    main()
