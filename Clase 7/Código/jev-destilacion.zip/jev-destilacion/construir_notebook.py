"""genera explorar.ipynb

se recomienda versionar este script y no el .ipynb, que guarda salidas y
contadores de ejecucion; si el notebook se edito a mano, ejecutar este
script lo sobrescribe

    python3 construir_notebook.py
"""

import json
from pathlib import Path


def md(t): return {"cell_type": "markdown", "metadata": {}, "source": t.strip().splitlines(True)}
def code(t): return {"cell_type": "code", "execution_count": None, "metadata": {},
                     "outputs": [], "source": t.strip().splitlines(True)}


CELDAS = [
    md("""
# jev-destilacion · explorar por dentro

Este notebook no reemplaza a los scripts: los corre y despues **abre lo que
produjeron**. Sirve para ver el mecanismo, no solo el resultado.

Antes de empezar, en otra terminal:

```
ollama serve
```

Si dice que la direccion ya esta en uso, ya estaba corriendo.
"""),
    md("## 0. Que hay del otro lado"),
    code("""
import jev, datos

import destilar

v = jev.version()
print("Ollama:", v if v else "NO RESPONDE -> abrir Ollama y: ollama pull " + jev.MODELO)
vm = jev.version(destilar.MAESTRO) if v else None
print("maestro de la destilacion:", vm if vm else "FALTA -> ollama pull " + destilar.MAESTRO)
print("tickets:", len(datos.TICKETS), "| areas:", datos.AREAS)
"""),
    md("La comprobacion completa, la misma que se corre desde la terminal:"),
    code("!python3 probar.py"),
    md("""
## 1. El mecanismo

Lo que el modelo recibe, completo. Mira el final: el prompt se corta en un
corchete abierto, asi que el siguiente token solo puede ser el numero.
"""),
    code("""
ticket = "Me cobraron dos veces la suscripcion de setiembre."
print(jev.prompt(ticket))
"""),
    md("""
Y lo que devuelve. No una palabra: una lista de candidatos con su
probabilidad. Fijate en los que **no** son areas validas.
"""),
    code("""
import math

cruda = jev.pedir({"model": jev.MODELO, "prompt": jev.prompt(ticket),
                   "raw": True, "stream": False, "logprobs": True,
                   "top_logprobs": 20,
                   "options": {"num_predict": 1, "temperature": 0}})
cands = jev.candidatos(cruda)

print(f"{'token':>8}{'probabilidad':>15}")
validos, fuera = [0.0] * len(datos.AREAS), 0.0
for c in cands:
    p = math.exp(c["logprob"])
    k = jev.opcion(c["token"], len(datos.AREAS))
    valido = k is not None
    if valido:
        validos[k] += p          # " 0" y "0" suman a la misma opcion
    else:
        fuera += p
    print(f"{str(c['token'])!r:>8}{p:>15.4f}   {'' if valido else '<- fuera del contrato'}")

print(f"\\nde donde sale la renormalizacion, con los {len(cands)} candidatos:")
print(f"  masa en las opciones validas     {sum(validos):.4f}")
print(f"  masa en candidatos invalidos     {fuera:.4f}")
print(f"  masa que no entro a los {len(cands)}       {max(0.0, 1 - sum(validos) - fuera):.4f}")
g = validos.index(max(validos))
print(f"\\n{datos.AREAS[g]}: {validos[g]:.4f} / {sum(validos):.4f} = "
      f"{validos[g] / sum(validos):.4f}")
print("Se divide por la masa valida, no por 1 menos el candidato invalido mas grande.")
print("\\nla decision, ya renormalizada sobre las cuatro areas:")
for area, p in zip(datos.AREAS, jev.decidir(ticket)):
    print(f"  {area:<12} {p:.4f}  {'#' * round(p * 40)}")
"""),
    md("""
**Lo que acaba de pasar.** El modelo reparte probabilidad en tokens que no son
opciones validas. Al renormalizar sobre las cuatro areas, esa masa se
descarta y la confianza sube. Eso es lo que hace un contrato: restringe la
respuesta en vez de confiar en que el modelo se porte bien.
"""),
    md("""
## 2. El prompt es una variable, no un detalle de estilo

El mismo texto, con y sin las marcas de turno con las que el modelo fue
entrenado. Veinte tickets para que sea rapido.
"""),
    code("""
muestra = datos.TICKETS[:20]
print(f"{'formato':<10}{'accuracy':>10}{'confianza':>11}{'brecha':>9}")
for formato in ("plano", "chatml"):
    ok, confs = 0, []
    for texto, real in muestra:
        p = jev.decidir(texto, formato=formato)
        ok += p.index(max(p)) == real
        confs.append(max(p))
    acc, conf = ok / len(muestra), sum(confs) / len(confs)
    print(f"{formato:<10}{acc:>10.3f}{conf:>11.3f}{conf - acc:>+9.3f}")
print("\\nMismo texto. Lo unico que cambia es el envoltorio.")
"""),
    md("""
## 3. Los datos

El corte entre desarrollo y prueba se hace por hash del texto, no por orden
de aparicion. Si se cortara por orden, quedaria correlacionado con el orden
en que uno escribio los tickets, que nunca es aleatorio.
"""),
    code("""
from collections import Counter

dev, test = datos.split()
print("dev ", len(dev), Counter(datos.AREAS[datos.TICKETS[i][1]] for i in dev))
print("test", len(test), Counter(datos.AREAS[datos.TICKETS[i][1]] for i in test))

textos = [t for t, _ in datos.TICKETS]
print("\\nduplicados:", len(textos) - len(set(textos)))
print("ejemplos del prompt que aparezcan como ticket:",
      len({e for e, _ in datos.EJEMPLOS} & set(textos)))
print("\\nlos ambiguos a proposito, que son los que separan:")
for t, a in datos.TICKETS[-4:]:
    print(f"  [{datos.AREAS[a]:<11}] {t}")
"""),
    md("""
## 4. Calibracion

Ahora si, el script completo. Decide los 50 tickets y sella el artefacto.
"""),
    code("!python3 calibrar.py"),
    md("Y lo que quedo guardado adentro:"),
    code("""
import json
from pathlib import Path

art = json.loads(Path("artefacto.json").read_text())
for k in ("hash", "motor", "modelo", "digest", "huella", "temperatura", "n_dev", "n_test"):
    print(f"  {k:<14} {art[k]}")
print(f"  {'probabilidades':<14} {len(art['probabilidades'])} tickets grabados")
print("\\nEl hash cubre todo eso junto. Cambia cualquier cosa y cambia el hash.")
"""),
    md("""
### El diagrama de fiabilidad, en texto

Se agrupan las decisiones por confianza y se compara, en cada grupo, lo que el
modelo dijo contra lo que acerto. Si estuviera perfectamente calibrado, las
dos columnas serian iguales.
"""),
    code("""
import calibrar

T = art["temperatura"]
filas = []
for i in test:
    texto, real = datos.TICKETS[i]
    p = calibrar.aplicar_t(art["probabilidades"][datos.clave(texto)], T)
    filas.append((max(p), p.index(max(p)) == real))

print(f"{'confianza':<14}{'n':>4}{'dice':>8}{'acierta':>9}   brecha")
for lo in (0.0, 0.5, 0.7, 0.9):
    hi = {0.0: 0.5, 0.5: 0.7, 0.7: 0.9, 0.9: 1.01}[lo]
    g = [(c, ok) for c, ok in filas if lo <= c < hi]
    if not g:
        continue
    dice = sum(c for c, _ in g) / len(g)
    acierta = sum(ok for _, ok in g) / len(g)
    print(f"{lo:.1f} a {hi:.2f}   {len(g):>4}{dice:>8.3f}{acierta:>9.3f}   {dice-acierta:+.3f}")
print("\\nCon pocos tickets por grupo estos numeros se mueven mucho: mirar la")
print("direccion, no la tercera cifra.")
"""),
    md("""
## 5. Politica y escalado
"""),
    code("!python3 correr.py"),
    md("""
Y la curva de abstencion completa, calculada desde el log, con mas umbrales
que los tres del script:
"""),
    code("""
dec = [json.loads(l) for l in Path("decisiones.jsonl").read_text().splitlines()]
print(f"{'umbral':>7}{'resuelve':>10}{'acierta':>9}   nota")
for u in (0.40, 0.50, 0.60, 0.75, 0.90, 0.95):
    res = [d for d in dec if d["confianza"] >= u]
    if not res:
        print(f"{u:>7.2f}{0:>10}{'-':>9}   no resuelve nada")
        continue
    acc = sum(d["area"] == d["real"] for d in res) / len(res)
    nota = "" if len(res) >= 10 else f"<- solo {len(res)} casos, no se puede leer"
    print(f"{u:>7.2f}{len(res):>10}{acc:>9.3f}   {nota}")
"""),
    md("""
## 6. Por que el hash importa

El artefacto se sella con un hash de su contenido. Si cambia una sola
probabilidad en el lugar doce decimal, cambia el hash y el artefacto ya no
es el mismo.
"""),
    code("""
import copy
import hashlib

def sellar(cuerpo):
    return hashlib.sha256(
        json.dumps(cuerpo, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]

# Copia profunda: si no, el cambio de abajo tocaria tambien `art` y la celda
# daria otro resultado al correrla dos veces.
cuerpo = copy.deepcopy({k: v for k, v in art.items() if k != "hash"})
print("hash guardado  ", art["hash"])
print("recalculado    ", sellar(cuerpo), "<- tiene que coincidir")

primera = next(iter(cuerpo["probabilidades"]))
cuerpo["probabilidades"][primera][0] += 1e-12
print("con un cambio de 1e-12:", sellar(cuerpo), "<- ya es otro artefacto")
"""),
    md("""
## 7. Llega la semana 1: monitoreo con lo desplegado

El sistema ya esta desplegado: qwen2.5:1.5b con el prompt largo. En produccion
nadie etiqueta
los tickets: la accuracy deja de ser medible. `monitorear.py` vigila lo que
si se puede ver sin etiquetas (la configuracion, las entradas y las salidas)
contra los 50 tickets de referencia del artefacto desplegado.

La semana 1 trae los mismos temas de siempre, escritos distinto. Es el
control: no deberia haber deriva.
"""),
    code("!python3 monitorear.py semana_1"),
    md("""
## 8. Destilacion, con el trafico de la semana 1

El unico paso que entrena. Hay tres actores:

- el **maestro**, qwen2.5:3b con cuatro ejemplos: el que se imita, nunca se despliega;
- lo **desplegado**, qwen2.5:1.5b con cuatro ejemplos: lo que decide hoy;
- el **alumno**, qwen2.5:1.5b sin ejemplos: barato, con el mapa encima.

El mapa se entrena para que el alumno se parezca al maestro, pero el criterio
de adopcion lo compara contra lo desplegado: la pregunta es si puede
reemplazarlo sin perder accuracy, con una confianza mas creible, con menos
tokens y sin encarecer el sistema completo, contando lo que escala al LLM. Antes de correr esta celda hace falta `ollama pull qwen2.5:3b-instruct`.

Ademas de los 24 tickets etiquetados, el mapa se entrena con los 30 tickets
de la semana 1, **sin su etiqueta**: la destilacion solo necesita las
probabilidades del maestro, y el maestro las da para cualquier ticket. Cada
semana nueva que se agregue a `LOTES_TRANSFERENCIA` en `destilar.py` es mas
material para que el alumno se acerque al maestro. Nunca lo supera: el
maestro es el techo.
"""),
    code("!python3 destilar.py"),
    md("Los veinte parametros que se entrenaron:"),
    code("""
d = json.loads(Path("artefacto_destilado.json").read_text())
print("W, la matriz 4x4:")
for fila, area in zip(d["W"], datos.AREAS):
    print("   " + "  ".join(f"{x:+.3f}" for x in fila) + f"   -> {area}")
print("\\nb, el sesgo: " + "  ".join(f"{x:+.3f}" for x in d["b"]))
print(f"\\nsemilla {d['semilla']} · {d['pasos']} pasos · se conservo el "
      f"{d['paso_conservado']}")
print(f"entrenamiento: {d['n_entrenamiento']} etiquetados + "
      f"{d.get('n_transferencia', 0)} sin etiqueta ({', '.join(d.get('lotes_transferencia', []))})")
print(f"maestro {d.get('modelo_maestro', d['modelo'])} · alumno {d['modelo']}")
print(f"tokens: desplegado {d.get('tokens_desplegado', d['tokens_maestro'])} vs alumno {d['tokens_alumno']}")
print("\\nArranco en la identidad (1 en la diagonal, 0 afuera).")
print("Lo que se alejo de ahi es exactamente lo que aprendio.")
"""),
    md("""
Por que se adopto o no. Las cuatro filas comparan al maestro, a lo desplegado
y al alumno antes y despues del mapa; debajo, el costo del sistema con la
politica equilibrada y las cuatro condiciones del criterio.
"""),
    code("""
print(f"{'en prueba':<18}{'accuracy':>10}{'ECE':>8}{'brecha':>9}")
for nombre, m in d["metricas"].items():
    print(f"{nombre:<18}{m['accuracy']:>10.3f}{m['ece']:>8.3f}{m['brecha']:>+9.3f}")

if "costos" in d:
    print("\\ncosto del sistema en prueba, politica equilibrada:")
    for nombre, c in d["costos"].items():
        print(f"  {nombre:<12}{c['usd']:.5f} USD, escalan {c['escalan']}")
if "criterio" in d:
    print("\\ncriterio de adopcion:")
    for texto, ok, valor in d["criterio"]:
        print(f"  [{'si' if ok else 'no'}] {texto:<46} {valor}")
print(f"\\n-> {'SE ADOPTA' if d.get('adoptado') else 'NO SE ADOPTA'}")
"""),
    md("""
## 9. El alumno reemplaza a lo desplegado

Hasta aca, destilar.py decidia si el alumno merecia quedarse, pero nadie
hacia cumplir esa decision. Ahora el alumno es un motor mas
(`jev_destilado.py`), con la misma interfaz que los otros dos, y solo se deja
usar si el criterio lo adopto, si el modelo es el mismo y si el prompt corto
no cambio.

Se vuelve a sellar el artefacto con el alumno, pero sin temperatura: queda
fija en 1, porque el mapa ya ajusta sus probabilidades y se entreno con los
mismos tickets de desarrollo con que se ajustaria la temperatura. Si el mapa
no fue adoptado, la celda lo dice, `artefacto.json` queda como estaba y la
celda siguiente muestra la cascada de lo que sigue desplegado.
"""),
    code("!JEV_MOTOR=destilado python3 calibrar.py"),
    md("""
Y la cascada con el motor que quedo desplegado. Mira la linea de tokens y el
costo: el alumno paga menos por decision, pero si duda mas, escala mas.
"""),
    code("!python3 correr.py"),
    md("""
## 10. Llega la semana 2: monitoreo con el motor desplegado

Tickets en portugues por el lanzamiento en Brasil, un producto nuevo (pagos
con QR) y correos largos con saludo y firma. Se vigila con lo que haya quedado
desplegado en la seccion 9. La semana 2 no se uso para entrenar, asi que el
monitoreo mide sobre datos que el modelo nunca vio.
"""),
    code("!python3 monitorear.py semana_2"),
    md("Los tickets de la ultima corrida con mas palabras nunca vistas, y que hizo el sistema con ellos:"),
    code("""
log = [json.loads(l) for l in Path("monitoreo.jsonl").read_text().splitlines() if l.strip()]
ultima = log[-1]["corrida"]
lote = sorted((r for r in log if r["corrida"] == ultima),
              key=lambda r: -r["fuera_vocab"])
print(f"{'nuevas':>7}{'conf':>7}  {'area':<12}{'escala':<8}ticket")
for r in lote[:8]:
    print(f"{r['fuera_vocab']:>7.0%}{r['confianza']:>7.3f}  {r['area']:<12}"
          f"{'si' if r['escala'] else 'no':<8}{r['texto'][:60]}")
print("\\nSi los tickets mas raros escalan, el sistema esta dudando donde corresponde.")
print("Si deciden con confianza alta, la confianza dejo de ser confiable ahi.")
"""),
    md("""
## 11. El proyecto en una pantalla

Todo lo anterior, leido de los archivos que dejo cada paso, sin volver a
llamar al modelo: que esta desplegado y como le va, que paso con la
destilacion y que vio el monitoreo en cada semana.
"""),
    code("""
import json
from pathlib import Path

art = json.loads(Path("artefacto.json").read_text())
dec = [json.loads(l) for l in Path("decisiones.jsonl").read_text().splitlines() if l.strip()]
ruta_d = Path("artefacto_destilado.json")
dest = json.loads(ruta_d.read_text()) if ruta_d.exists() else None
ruta_m = Path("monitoreo.jsonl")
log = [json.loads(l) for l in ruta_m.read_text().splitlines() if l.strip()] if ruta_m.exists() else []

print("1. LO DESPLEGADO")
print(f"   motor {art['motor']} · {art['modelo']}")
print(f"   artefacto {art['hash']} · temperatura {art['temperatura']} · digest {art['digest']}")
cal = [k for k in art["metricas"] if k != "sin calibrar"][0]
m = art["metricas"][cal]
print(f"   en los 20 de prueba: accuracy {m['accuracy']:.3f}, ECE {m['ece']:.3f}")
res = [x for x in dec if x["confianza"] >= 0.75]
ok = sum(x["area"] == x["real"] for x in res)
acierta = f"{ok / len(res):.3f}" if res else "-"
print(f"   politica equilibrada: resuelve {len(res)} de {len(dec)}, "
      f"acierta {acierta}, escalan {len(dec) - len(res)}")

print("\\n2. LA DESTILACION")
if not dest:
    print("   todavia no se corrio destilar.py")
else:
    print(f"   maestro {dest.get('modelo_maestro', dest['modelo'])} · alumno {dest['modelo']}")
    print(f"   entrenada con {dest['n_entrenamiento']} etiquetados + "
          f"{dest.get('n_transferencia', 0)} sin etiqueta de {dest.get('lotes_transferencia', [])}")
    for nombre in ("maestro", "desplegado", "alumno + mapa"):
        if nombre in dest["metricas"]:
            print(f"   {nombre:<14} accuracy {dest['metricas'][nombre]['accuracy']:.3f}")
    fallan = [t for t, ok_, _ in dest.get("criterio", []) if not ok_]
    if dest.get("adoptado"):
        print("   ADOPTADO" + (" y desplegado" if art["motor"] == "jev_destilado"
                             else ", pero todavia no se desplego"))
    else:
        print("   NO ADOPTADO" + (": falla " + "; ".join(fallan) if fallan else ""))

print("\\n3. EL MONITOREO (ultima corrida de cada semana)")
if not log:
    print("   todavia no se corrio monitorear.py")
ultimas = {}
for r in log:
    ultimas[r["lote"]] = r["corrida"]
for lote, corrida in ultimas.items():
    rs = [r for r in log if r["lote"] == lote and r["corrida"] == corrida]
    n = len(rs)
    print(f"   {lote}: {corrida} · motor {rs[0]['motor']} · "
          f"confianza media {sum(r['confianza'] for r in rs) / n:.3f} · "
          f"escala {sum(r['escala'] for r in rs) / n:.0%} · "
          f"palabras nuevas {sum(r['fuera_vocab'] for r in rs) / n:.0%}")
print("   (el veredicto de deriva de cada semana esta en las secciones 7 y 10)")
"""),
    md("""
## Para seguir

Cinco experimentos cortos, en orden de lo que mas ensena:

1. Saca el `[` del final de `jev.prompt()`, reinicia el kernel y vuelve a
   correr la seccion 1. Cuanto cae la confianza y por que.
2. Borra dos de los cuatro `EJEMPLOS` en `datos.py` y corre `destilar.py`.
   El mapa, cuanto recupera?
3. Cambia `PASO_LR` a 0.5 en `destilar.py` y vuelve a correr la seccion 8.
   Mira si el script avisa que la perdida de entrenamiento sube. Si avisa, ese
   aviso es el punto. Si no avisa, la pregunta es por que: el piso, el
   centrado y el recorte de `_z()` y `entrenar()` estan para eso. Proba
   tambien con 2.0.
4. Saca `"semana_1"` de `LOTES_TRANSFERENCIA` en `destilar.py` y vuelve a
   destilar. Cuanto cambia el mapa, y cambia la decision de adoptar?
5. Cierra el ciclo del monitoreo: copia a `datos.TICKETS` diez tickets de
   `trafico.LOTES["semana_2"]` con su area, vuelve a correr `calibrar.py` y
   despues `monitorear.py semana_2`. La deriva de entrada, baja? Ojo: el corte
   entre desarrollo y prueba cambia, y por eso cambian todas las metricas.
"""),
    md("""
## Anexo opcional: el Jev abierto contra el metodo

Solo si levantaste MiniCPM5-2B-Jev en otra terminal (ver `jev_api.py`). Si no
esta corriendo, el script lo dice y sigue sin romperse.
"""),
    code("!python3 comparar_motores.py"),
]

# nbformat 4.5 exige un id por celda; se usa la posicion
for i, celda in enumerate(CELDAS):
    celda["id"] = f"celda-{i:02d}"

nb = {"cells": CELDAS,
      "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"},
                   "language_info": {"name": "python"}},
      "nbformat": 4, "nbformat_minor": 5}

destino = Path(__file__).parent / "explorar.ipynb"
destino.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"{destino.name}  ({len(CELDAS)} celdas)")
