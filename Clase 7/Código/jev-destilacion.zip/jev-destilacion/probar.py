"""verificacion inicial; debe ejecutarse antes que el resto

revisa que Ollama responda, que tenga el modelo y que devuelva logprobs; sin
logprobs no funciona ninguna parte del proyecto
"""

import json

import jev

print(f"1. Ollama en {jev.URL}")
v = jev.version()
if not v:
    raise SystemExit(
        f"   Ollama no responde o no tiene el modelo {jev.MODELO}\n"
        f"   solucion: abra Ollama y ejecute 'ollama pull {jev.MODELO}'"
    )
print(f"   responde: {v['modelo']}  digest {v['digest']}")

print("\n2. Final del prompt enviado al modelo")
print("   " + jev.prompt(jev.datos.TICKETS[0][0]).rsplit("\n", 2)[-1].replace("\n", "\n   "))

print("\n3. Probabilidades por token")
cruda = jev.pedir({
    "model": jev.MODELO, "prompt": jev.prompt("Me cobraron dos veces."),
    "raw": True, "stream": False, "logprobs": True, "top_logprobs": 20,
    "options": {"num_predict": 1, "temperature": 0},
})
lista = jev.candidatos(cruda)
if not lista:
    print("   Ollama no devuelve logprobs. Respuesta recibida:")
    print("   " + json.dumps(cruda, ensure_ascii=False)[:600])
    raise SystemExit(
        "\n   solucion: actualice Ollama a la version mas reciente\n"
        "   el metodo de Jev necesita las probabilidades de cada token"
    )

print(f"   {len(lista)} candidatos, los cinco primeros:")
for c in lista[:5]:
    print(f"     {str(c['token'])!r:>10}  p={2.718281828 ** c['logprob']:.4f}")

print("\n4. Decision como distribucion sobre las areas")
p = jev.decidir("Me cobraron dos veces la suscripcion de setiembre.")
for area, prob in zip(jev.datos.AREAS, p):
    print(f"     {area:<12} {prob:.4f}  {'#' * round(prob * 40)}")
print("\nTodo listo. Siguiente paso: python3 comparar.py")
