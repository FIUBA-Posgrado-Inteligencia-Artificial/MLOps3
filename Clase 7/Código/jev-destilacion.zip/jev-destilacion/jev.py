"""motor de decision por defecto: qwen en Ollama, leyendo probabilidades

el prompt numera las areas y termina en "["; se pide un solo token al modelo
y se leen las probabilidades de los digitos 0 a 3, sin generar texto

parametros de Ollama necesarios:

    raw=true        envia el prompt sin plantilla de chat, lo que permite
                    terminarlo en "["
    logprobs=true   devuelve las probabilidades de los candidatos
"""

import hashlib
import json
import math
import urllib.error
import urllib.request

import datos

URL = "http://127.0.0.1:11434"
MODELO = "qwen2.5:1.5b-instruct"


FORMATO = "chatml"


def prompt(texto: str, formato: str = "") -> str:
    """arma el prompt, que siempre termina en "["

    formatos:

        chatml (por defecto)  sistema, cuatro ejemplos y ticket
        corto                 sistema y ticket, sin ejemplos (el alumno)
        plano                 sin marcas de chat, para comparar.py

    si no termina en "[", el token mas probable es el corchete y las
    probabilidades de los digitos no aportan informacion
    """
    formato = formato or FORMATO
    if formato == "corto":
        # sin ejemplos: unos 139 tokens frente a 248 del formato chatml
        return (f"<|im_start|>system\n{datos.SISTEMA}<|im_end|>\n"
                f"<|im_start|>user\nTicket: {texto}<|im_end|>\n"
                "<|im_start|>assistant\n[")
    if formato == "plano":
        partes = [datos.SISTEMA, ""]
        for t, a in datos.EJEMPLOS:
            partes.append(f"Ticket: {t}\nArea: [{a}]")
        partes.append(f"Ticket: {texto}\nArea: [")
        return "\n".join(partes)

    partes = [f"<|im_start|>system\n{datos.SISTEMA}<|im_end|>"]
    for t, a in datos.EJEMPLOS:
        partes.append(f"<|im_start|>user\nTicket: {t}<|im_end|>")
        partes.append(f"<|im_start|>assistant\n[{a}]<|im_end|>")
    partes.append(f"<|im_start|>user\nTicket: {texto}<|im_end|>")
    partes.append("<|im_start|>assistant\n[")
    return "\n".join(partes)


def pedir(payload: dict) -> dict:
    pedido = urllib.request.Request(
        f"{URL}/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(pedido, timeout=120) as r:
        return json.loads(r.read())


def candidatos(obj) -> list[dict] | None:
    """busca en la respuesta la lista de candidatos (token y logprob)

    la busqueda es recursiva porque el formato cambio entre versiones de Ollama
    y entre el endpoint nativo y el compatible con OpenAI
    """
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) and "token" in x and "logprob" in x for x in obj):
            # la lista de tokens generados tiene la misma forma (uno por posicion);
            # si incluye top_logprobs, los candidatos estan dentro
            if "top_logprobs" in obj[0]:
                return candidatos(obj[0]["top_logprobs"])
            return obj
        for x in obj:
            if (hallado := candidatos(x)):
                return hallado
    elif isinstance(obj, dict):
        for clave in ("top_logprobs", "logprobs", "content", "choices"):
            if clave in obj and (hallado := candidatos(obj[clave])):
                return hallado
        for v in obj.values():
            if (hallado := candidatos(v)):
                return hallado
    return None


def opcion(token, n: int) -> int | None:
    """numero de opcion del token (de 0 a n menos 1), o None si no es valido

    isdigit() no basta: '₀' o '²' devuelven True, pero int() falla; qwen2.5:3b
    devolvio '₀' entre sus candidatos y detenia destilar.py
    """
    t = str(token).strip()
    if not t.isdigit():
        return None
    try:
        k = int(t)
    except ValueError:
        return None
    return k if k < n else None


def decidir(texto: str, modelo: str = MODELO, formato: str = "") -> list[float]:
    """devuelve las probabilidades de las cuatro areas, que suman 1"""
    n = len(datos.AREAS)
    respuesta = pedir({
        "model": modelo,
        "prompt": prompt(texto, formato),
        "raw": True,
        "stream": False,
        "logprobs": True,
        "top_logprobs": 20,
        "options": {"num_predict": 1, "temperature": 0},
    })

    lista = candidatos(respuesta)
    if not lista:
        raise RuntimeError(
            "Esta version de Ollama no devolvio logprobs. Ejecute "
            "'python3 probar.py' para ver la respuesta y actualice Ollama "
            "si es necesario. El metodo de Jev necesita las probabilidades"
        )

    # se suman solo los digitos validos y se renormaliza; el resto de los
    # candidatos ('Fact', '4', espacios) se descarta
    masa = [0.0] * n
    for c in lista:
        if (k := opcion(c["token"], n)) is not None:
            masa[k] += math.exp(c["logprob"])

    total = sum(masa)
    if total <= 0:
        raise RuntimeError(f"Ningun digito valido entre los candidatos: {lista[:3]}")
    return [m / total for m in masa]


def decidir_detalle(texto: str, modelo: str = MODELO,
                    formato: str = "") -> tuple[list[float], int]:
    """igual que decidir(), pero devuelve tambien los tokens de entrada

    el conteo proviene de prompt_eval_count de Ollama; destilar.py lo usa para
    comparar el costo del prompt largo con el del corto
    """
    n = len(datos.AREAS)
    respuesta = pedir({
        "model": modelo, "prompt": prompt(texto, formato),
        "raw": True, "stream": False, "logprobs": True, "top_logprobs": 20,
        "options": {"num_predict": 1, "temperature": 0},
    })
    lista = candidatos(respuesta)
    if not lista:
        raise RuntimeError("Esta version de Ollama no devolvio logprobs")
    masa = [0.0] * n
    for c in lista:
        if (k := opcion(c["token"], n)) is not None:
            masa[k] += math.exp(c["logprob"])
    total = sum(masa)
    if total <= 0:
        raise RuntimeError(f"Ningun digito valido entre los candidatos: {lista[:3]}")
    return [m / total for m in masa], int(respuesta.get("prompt_eval_count", 0))


def version(modelo: str = MODELO) -> dict | None:
    """nombre y digest del modelo en Ollama, o None si no responde

    se guarda el digest porque un mismo nombre puede corresponder a pesos
    distintos despues de un ollama pull
    """
    try:
        with urllib.request.urlopen(f"{URL}/api/tags", timeout=5) as r:
            for m in json.loads(r.read()).get("models", []):
                if m.get("name") == modelo:
                    return {"modelo": m["name"], "digest": (m.get("digest") or "")[:16]}
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    return None


def huella(formato: str = "") -> str:
    """hash corto del prompt sin el ticket; se guarda en el artefacto

    sin argumento corresponde al prompt por defecto; con formato="corto", al del
    alumno; si el prompt cambia, cambia la huella y el monitoreo lo detecta
    """
    return hashlib.sha1(prompt("", formato).encode("utf-8")).hexdigest()[:12]
