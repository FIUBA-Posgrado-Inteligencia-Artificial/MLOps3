"""decide los 50 tickets, ajusta la temperatura y guarda artefacto.json

evalua en los 20 tickets de prueba (accuracy, ECE y NLL), busca la
temperatura en los 30 de desarrollo y guarda el resultado junto con el
modelo, el digest y la huella del prompt, sellado con un hash

    python3 calibrar.py
    JEV_MOTOR=api python3 calibrar.py
    JEV_MOTOR=destilado python3 calibrar.py
"""

import hashlib
import json
import math
import os
import time
from pathlib import Path

import datos

ARTEFACTO = Path("artefacto.json")

def motor():
    """elige el motor segun JEV_MOTOR: jev (por defecto), api o destilado"""
    if os.getenv("JEV_MOTOR") == "api":
        import jev_api
        return jev_api
    if os.getenv("JEV_MOTOR") == "destilado":
        import jev_destilado
        return jev_destilado
    import jev
    return jev


# el motor se elige al importar, sin conectarse todavia
jev = motor()


def aplicar_t(p: list[float], t: float) -> list[float]:
    """aplica temperatura a una distribucion; t>1 la aplana y t<1 la concentra"""
    z = [math.log(max(x, 1e-12)) / t for x in p]
    m = max(z)
    e = [math.exp(x - m) for x in z]
    s = sum(e)
    return [x / s for x in e]


def nll(probs, reales, t=1.0) -> float:
    """perdida logaritmica promedio; es la que se minimiza al buscar la temperatura"""
    return -sum(math.log(max(aplicar_t(p, t)[y], 1e-12))
                for p, y in zip(probs, reales)) / len(probs)


def accuracy(probs, reales) -> float:
    return sum(p.index(max(p)) == y for p, y in zip(probs, reales)) / len(probs)


def ece(probs, reales, t=1.0, bins=5) -> float:
    """error de calibracion con 5 grupos; se reporta pero no se optimiza

    con pocos datos, optimizarlo termina ajustando los limites de los grupos
    mas que las probabilidades
    """
    cajas = [[] for _ in range(bins)]
    for p, y in zip(probs, reales):
        q = aplicar_t(p, t)
        conf = max(q)
        cajas[min(int(conf * bins), bins - 1)].append((conf, q.index(conf) == y))
    total = 0.0
    for caja in cajas:
        if caja:
            c = sum(x for x, _ in caja) / len(caja)
            a = sum(ok for _, ok in caja) / len(caja)
            total += len(caja) / len(probs) * abs(c - a)
    return total


def buscar_t(probs, reales) -> float:
    """prueba T entre 0.5 y 3.0 (pasos de 0.05) y elige la de menor NLL en desarrollo"""
    mejor, mejor_p = 1.0, nll(probs, reales)
    t = 0.5
    while t <= 3.0:
        if (p := nll(probs, reales, t)) < mejor_p:
            mejor, mejor_p = t, p
        t += 0.05
    return round(mejor, 2)


def main() -> None:
    v = jev.version()
    if not v:
        raise SystemExit(
            f"No responde {jev.MODELO} en {jev.URL}\n"
            "Con Ollama, ejecute python3 probar.py. Con el Jev abierto, inicie serve.py")
    print(f"modelo {v['modelo']}  digest {v['digest']}")

    idx_dev, idx_test = datos.split()
    print(f"{len(idx_dev)} tickets de desarrollo, {len(idx_test)} de prueba\n")

    grabadas, t0 = {}, time.perf_counter()
    for n, (texto, _) in enumerate(datos.TICKETS, 1):
        grabadas[datos.clave(texto)] = jev.decidir(texto)
        if n % 10 == 0:
            print(f"  {n}/{len(datos.TICKETS)} decididos")
    ms = (time.perf_counter() - t0) / len(datos.TICKETS) * 1000
    print(f"{len(grabadas)} decisiones, {ms:.0f} ms cada una\n")

    def conjunto(idx):
        return ([grabadas[datos.clave(datos.TICKETS[i][0])] for i in idx],
                [datos.TICKETS[i][1] for i in idx])

    p_dev, y_dev = conjunto(idx_dev)
    p_test, y_test = conjunto(idx_test)

    t = buscar_t(p_dev, y_dev)
    if jev.__name__ == "jev_destilado":
        # el alumno destilado usa T=1: el mapa ya corrige sus probabilidades y se
        # entreno con 24 de estos 30 tickets, por lo que ajustar T sobre ellos
        # seria ajustar sobre datos ya vistos (en tres corridas empeoro la prueba)
        print(f"temperatura: 1.0, fija para el alumno destilado "
              f"(en desarrollo se obtuvo {t})")
        print("El mapa ya ajusta las probabilidades y se entreno con estos mismos")
        print("tickets de desarrollo. Una temperatura adicional se ajustaria a datos ya vistos")
        t = 1.0
    else:
        print(f"temperatura ajustada en desarrollo: {t}")
    print(f"{'en prueba':<16}{'accuracy':>10}{'ECE':>9}{'NLL':>9}")
    filas = {}
    for nombre, tt in [("sin calibrar", 1.0), (f"T={t}", t)]:
        fila = {"accuracy": round(accuracy([aplicar_t(p, tt) for p in p_test], y_test), 4),
                "ece": round(ece(p_test, y_test, tt), 4),
                "nll": round(nll(p_test, y_test, tt), 4)}
        filas[nombre] = fila
        print(f"{nombre:<16}{fila['accuracy']:>10.3f}{fila['ece']:>9.4f}{fila['nll']:>9.4f}")

    print("\nLa accuracy no cambia: la temperatura mueve la confianza")
    if len(idx_test) < 50:
        print(f"Con {len(idx_test)} tickets de prueba el ECE tiene mucho ruido")

    cuerpo = {
        "motor": jev.__name__, "modelo": v["modelo"], "digest": v["digest"],
        "huella": jev.huella(),
        "temperatura": t, "metricas": filas,
        "n_dev": len(idx_dev), "n_test": len(idx_test),
        "probabilidades": grabadas,
    }
    sello = hashlib.sha256(
        json.dumps(cuerpo, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:16]
    ARTEFACTO.write_text(
        json.dumps({"hash": sello, **cuerpo}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    print(f"\nartefacto.json sellado  hash {sello}")
    print("El hash incluye el modelo, el prompt, la temperatura y las decisiones.")
    print("Si cualquiera de ellos cambia, el hash tambien cambia")
    print("\nSiguiente paso: python3 correr.py")


if __name__ == "__main__":
    main()
