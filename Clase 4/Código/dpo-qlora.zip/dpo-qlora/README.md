# Actualizando un LLM (DPO y QLoRA)

* las dos corridas ya están hechas
* no hace falta GPU: el análisis corre en
cualquier máquina en unos minutos

## 1. Instalar

Desde esta carpeta, en una terminal:

```bash
bash instalar.sh
```

Crea `.venv`, instala las dependencias, genera el banco de consultas y corre
las pruebas. Al final tiene que decir **46 passed**. Si alguna falla mándenme un correo

Necesitan Python 3. Si `python3 --version` no responde, instálenlo primero.
En Windows corran todo desde WSL o Git Bash, no desde PowerShell

## 2. Abrir el notebook

```bash
source .venv/bin/activate
pip install jupyterlab
jupyter lab demo_clase.ipynb
```

El `source` no es opcional, si abren Jupyter sin activar el entorno, el notebook no encuentra los módulos del proyecto y fallará

## 3. Verificar antes de seguir

La celda de preparación imprime esto:

```
repositorio: .../tp-dpo-continuo-students
python     : .../.venv/bin/python
corrida-A-sin-guardarrail: ok
corrida-B-con-guardarrail: ok
```

Las tres cosas que tienen que dar bien:

- la línea `python` tiene que terminar en `.venv/bin/python`
- las dos corridas tienen que decir `ok`, no `FALTA`

Si dice `FALTA`, el zip se descomprimió incompleto.

Después, correr las celdas en orden.

## Qué hay adentro

```
simulador/        consultas, rasgos observables, oráculo de preferencias
store/            el preference store y la barrera de aislamiento
drift/            los dos detectores
entrenamiento/    armado del lote y el job de DPO
gate/             estadística y las cuatro condiciones de promoción
orquestador/      el bucle
analisis/         lo que se corre después de la corrida
tests/            las pruebas

corrida-A-sin-guardarrail/    bitácora, base de preferencias, estado
corrida-B-con-guardarrail/
```

Los adaptadores no están: pesan 425 MB y solo hacen falta para generar texto
nuevo. Se pueden descargar en:
* corrida-A-sin-guardarrail: https://drive.google.com/file/d/1MC_xZoG9vBYRA2ymXpXSou_NB6CFTSrm/view?usp=sharing
* corrida-B-con-guardarrail: https://drive.google.com/file/d/1Z9MT0roy8-0aMKXAI55DiORjoAU-zTcB/view?usp=sharing

**`colab/dpo_dos_corridas.ipynb` es opcional.** Reproduce el experimento desde
cero, pero necesita GPU, unas tres horas, y editar la ruta de Drive que trae
