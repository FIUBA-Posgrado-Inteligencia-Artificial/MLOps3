"""Bucle con modelo real. Pensado para correr en Colab con una T4.

Es el mismo bucle que `orquestador/experimento.py`, con dos diferencias:

  - genera con un SLM de verdad, por lotes y dentro del mismo proceso (sin
    servicio HTTP: en Colab un servidor no aporta nada y complica);
  - entrena con `trl.DPOTrainer` sobre QLoRA en lugar de la maqueta.

El detector, el gate, la estadistica y el store son exactamente los mismos
modulos que usa el modo simulado. Eso es deliberado: lo que se ensena es el
andamiaje, y el andamiaje no cambia cuando cambia el motor.

Guarda el estado despues de cada ronda y puede retomar donde quedo, porque las
sesiones de Colab se cortan solas.

Uso:
    python -m orquestador.experimento_real --salida /content/drive/MyDrive/dpo
    python -m orquestador.experimento_real --salida ... --retomar
"""

import argparse
import json
import os
import shutil
import time

import yaml

from drift import monitor
from entrenamiento import datos as dts
from entrenamiento import dpo_job
from entrenamiento import modelo_real as mr
from gate import evaluacion as ev
from gate import gate as gt
from orquestador import seguimiento as seg
from simulador import consultas as bc
from simulador import oraculo as orc
from store import db

ESTADO = {"modelo": None, "tok": None, "adaptador_activo": "base"}


# --------------------------------------------------------------------------
# Generacion
# --------------------------------------------------------------------------

def activar(ruta_adaptador, etiqueta):
    """Carga un adaptador sobre el modelo base si no es el que ya esta activo."""
    if ESTADO["adaptador_activo"] == etiqueta:
        return
    ESTADO["modelo"] = mr.cargar_adaptador(ESTADO["modelo"], ruta_adaptador)
    ESTADO["adaptador_activo"] = etiqueta


def hacer_generador(cfg_dpo, tam_lote):
    """Devuelve la funcion que `gate.evaluacion` usa para generar.

    `politica` es un diccionario {version, ruta}: activar el adaptador que
    corresponda y generar por lotes.
    """
    def generador(politica, consultas, semilla):
        activar(politica.get("ruta"), politica.get("version", "base"))
        _, textos = mr.generar_lote(ESTADO["modelo"], ESTADO["tok"], consultas,
                                    cfg_dpo, semilla, temperatura=0.7,
                                    tam_lote=tam_lote)
        return textos
    return generador


def recolectar_ronda_real(con, corrida, ronda, politica, cfg_or, cfg_exp,
                          cfg_dpo, semilla, banco, tam_lote):
    """Genera pares con el modelo real y los hace anotar por el oraculo."""
    rng = orc.nuevo_rng(semilla, ronda, sufijo=1)
    n = cfg_exp["recoleccion"]["pares_por_ronda"]
    n_dup = cfg_exp["recoleccion"]["pares_duplicados"]
    fase = cfg_or["calendario"][ronda]["fase"]
    expone = ronda >= cfg_or["ronda_desde_la_que_se_expone_segmento"]

    consultas = [banco[(ronda * n + i) % len(banco)] for i in range(n)]
    activar(politica.get("ruta"), politica.get("version", "base"))
    k = cfg_exp["recoleccion"].get("candidatos_por_consulta", 4)
    prompts, abanicos = mr.generar_abanico(
        ESTADO["modelo"], ESTADO["tok"], consultas, cfg_dpo,
        semilla * 1000 + ronda,
        temperatura=cfg_exp["recoleccion"]["temperatura_generacion"],
        tam_lote=tam_lote, k=k)

    acuerdos, probabilidades, margenes = [], [], []
    for i, consulta in enumerate(consultas):
        par = {"prompt": prompts[i], "hechos_clave": consulta["hechos_clave"],
               "candidatos": [{"id": f"c{j}", "texto": t}
                              for j, t in enumerate(abanicos[i])]}
        perfil = orc.perfil_de_la_ronda(ronda, cfg_or, rng)
        anotacion = orc.anotar_abanico(par, perfil, cfg_or, rng)
        probabilidades.append(anotacion["p_a"])
        margenes.append(anotacion["margen_utilidad"])

        db.guardar_par(con, {
            "par_id": f"{corrida}-r{ronda:03d}-{i:05d}",
            "consulta_id": consulta["consulta_id"], "prompt": prompts[i],
            "chosen": anotacion["chosen"], "rejected": anotacion["rejected"],
            "policy_version": politica.get("version", "base"), "ronda": ronda,
            "corrida": corrida, "fase_oraculo": fase, "perfil_anotador": perfil,
            "segmento": perfil if expone else None,
            "margen_utilidad": anotacion["margen_utilidad"], "es_duplicado": 0})

        if i < n_dup:
            perfil2 = orc.perfil_de_la_ronda(ronda, cfg_or, rng)
            anot2 = orc.anotar_abanico(par, perfil2, cfg_or, rng)
            acuerdos.append(1.0 if anot2["id_elegido"] == anotacion["id_elegido"] else 0.0)
            db.guardar_par(con, {
                "par_id": f"{corrida}-r{ronda:03d}-{i:05d}-dup",
                "consulta_id": consulta["consulta_id"], "prompt": prompts[i],
                "chosen": anot2["chosen"], "rejected": anot2["rejected"],
                "policy_version": politica.get("version", "base"), "ronda": ronda,
                "corrida": corrida, "fase_oraculo": fase, "perfil_anotador": perfil2,
                "segmento": perfil2 if expone else None,
                "margen_utilidad": anot2["margen_utilidad"], "es_duplicado": 1})

    con.commit()
    # El margen medio de utilidad es el diagnostico barato de si la recoleccion
    # sirve para algo: si baja de ~1.0 el lote no tiene senal y el DPO no va a
    # poder separar nada, por mas que se le suba la tasa de aprendizaje.
    medio = sum(margenes) / len(margenes) if margenes else 0.0
    print(f"    margen de utilidad medio del lote: {medio:.2f}"
          f"{'   (BAJO: el lote casi no tiene senal)' if medio < 1.0 else ''}")
    return {"acuerdo_observado": sum(acuerdos) / len(acuerdos) if acuerdos else None,
            "margen_utilidad_medio": medio}


# --------------------------------------------------------------------------
# Estado (Colab se desconecta)
# --------------------------------------------------------------------------

def guardar_estado(salida, estado):
    with open(os.path.join(salida, "estado.json"), "w", encoding="utf-8") as f:
        json.dump(estado, f, ensure_ascii=False, indent=2)


def leer_estado(salida):
    ruta = os.path.join(salida, "estado.json")
    if not os.path.exists(ruta):
        return None
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


def anexar_bitacora(salida, fila):
    with open(os.path.join(salida, "bitacora.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(fila, ensure_ascii=False) + "\n")


# --------------------------------------------------------------------------
# Bucle
# --------------------------------------------------------------------------

def correr(salida, cfg_exp, cfg_or, cfg_dpo, banco, semilla, retomar=False):
    os.makedirs(salida, exist_ok=True)
    os.makedirs(os.path.join(salida, "adaptadores"), exist_ok=True)
    corrida = f"real-s{semilla}"
    tam_lote = cfg_exp["generacion"]["tam_lote"]

    con = db.conectar(os.path.join(salida, "preferencias.db"))
    db.inicializar(con)

    # Proteccion contra pisar una corrida anterior: la carpeta de trabajo
    # guarda que semilla la escribio. Arrancar de cero con otra semilla borra
    # la bitacora y los adaptadores, y eso no se recupera.
    marca = os.path.join(salida, "semilla.txt")
    if os.path.exists(marca):
        previa_semilla = open(marca, encoding="utf-8").read().strip()
        if previa_semilla != str(semilla) and not retomar:
            raise SystemExit(
                f"\nLa carpeta '{salida}' contiene la corrida de la semilla "
                f"{previa_semilla}. Arrancar de cero con la semilla {semilla} "
                f"borraria su bitacora y sus adaptadores.\n"
                f"Usa una carpeta por semilla, por ejemplo '{salida}-s{semilla}'.\n")

    estado = leer_estado(salida) if retomar else None
    if estado is None:
        db.limpiar_corrida(con, corrida)
        if os.path.exists(os.path.join(salida, "bitacora.jsonl")):
            os.remove(os.path.join(salida, "bitacora.jsonl"))
    with open(marca, "w", encoding="utf-8") as f:
        f.write(str(semilla))
    if estado is None:
        estado = {"ronda": 0, "version": "base", "ruta": None,
                  "version_previa": None, "ruta_previa": None,
                  "recien_promovido": False, "reintentos": 0,
                  "drift": {"serie": [], "referencia": None}}
        print("Arrancando de cero.")
    else:
        print(f"Retomando despues de la ronda {estado['ronda']}.")

    ESTADO["modelo"], ESTADO["tok"] = mr.cargar_modelo(cfg_dpo)
    ESTADO["adaptador_activo"] = "base"
    if estado["ruta"]:
        activar(estado["ruta"], estado["version"])

    recoleccion = bc.por_split(banco, "recoleccion")
    evaluacion = bc.por_split(banco, "evaluacion", cfg_exp["evaluacion"]["n_consultas"])
    canary = bc.por_split(banco, "canary", cfg_exp["evaluacion"]["n_canary"])
    indice_hechos = {c["consulta_id"]: c["hechos_clave"] for c in banco}
    generador = hacer_generador(cfg_dpo, tam_lote)

    # El monitor de drift se reconstruye desde la serie guardada.
    estado_drift = monitor.estado_inicial()
    for valor in estado["drift"]["serie"]:
        from drift import detectores as det
        det.actualizar_page_hinkley(estado_drift["ph"], valor,
                                    cfg_exp["drift"]["page_hinkley"]["delta"],
                                    cfg_exp["drift"]["page_hinkley"]["umbral"])
    estado_drift["serie"] = list(estado["drift"]["serie"])
    estado_drift["referencia_longitudes"] = estado["drift"]["referencia"]

    seg.iniciar_experimento("dpo-continuo/real")
    politica_base = {"version": "base", "ruta": None}
    medicion_previa = {"version": None, "contra_base": None, "corr": None}

    for ronda in range(estado["ronda"] + 1, cfg_exp["rondas"] + 1):
        arranque = time.time()
        p_didactico = cfg_or["calendario"][ronda]["p_didactico"]
        politica = {"version": estado["version"], "ruta": estado["ruta"]}
        previa = {"version": estado["version_previa"], "ruta": estado["ruta_previa"]}
        accion, causa, metricas = "sin_accion", None, {}

        print(f"\n=== ronda {ronda} · fase {cfg_or['calendario'][ronda]['fase']} ===")
        print("  generando pares...")
        rec = recolectar_ronda_real(con, corrida, ronda, politica, cfg_or,
                                    cfg_exp, cfg_dpo, semilla, recoleccion, tam_lote)

        señal = monitor.revisar(estado_drift, con, corrida, ronda, cfg_exp)
        print(f"  señal={señal['pref_longitud']:.3f}  alarma={int(señal['alarma'])}"
              f"  detector={señal['detector']}")

        # Rollback de la promocion anterior.
        if estado["recien_promovido"]:
            print("  revisando la promocion anterior...")
            post = ev.comparar(politica, previa, evaluacion, cfg_or, p_didactico,
                               semilla + ronda,
                               replicas=cfg_exp["evaluacion"]["replicas_bootstrap"],
                               alfa=cfg_exp["evaluacion"]["alfa"],
                               generador=generador)
            c_nueva = ev.correccion(politica, canary, semilla + ronda, generador=generador)
            c_previa = ev.correccion(previa, canary, semilla + ronda, generador=generador)
            post["caida_correccion"] = ev.regresion_de_correccion(
                c_nueva["aciertos"], c_previa["aciertos"])["caida"]
            revertir, motivo = gt.hay_que_revertir(post, cfg_exp["gate"])
            if revertir:
                politica = dict(previa)
                estado["version"], estado["ruta"] = previa["version"], previa["ruta"]
                accion, causa = "revertir", motivo
                print(f"  REVERTIR: {motivo}")
            estado["recien_promovido"] = False

        # Entrenamiento.
        #
        # ic_candidato queda fuera del if a proposito: es la entrada real del
        # gate y antes no se registraba en ningun lado. La bitacora guardaba el
        # IC de la medicion de la ronda, que es otro numero, y por eso las
        # decisiones no se podian recalcular despues.
        ic_candidato = None
        entrena = (ronda == 1) or señal["alarma"] or estado["reintentos"] > 0
        if accion != "revertir" and entrena:
            pares, hash_lote, rango = dts.armar_lote(con, corrida, ronda, cfg_exp,
                                                     semilla=semilla)
            for p in pares:
                p["hechos_clave"] = indice_hechos.get(p["consulta_id"], [])
            ev.verificar_fuga(pares, evaluacion + canary)

            ruta_salida = os.path.join(salida, "adaptadores", f"r{ronda:02d}")
            print(f"  entrenando DPO con {len(pares)} pares (lote {hash_lote})...")
            desde = None if cfg_exp["entrenamiento"]["reiniciar_desde_base"] else estado["ruta"]

            # El entrenador carga su propia copia del modelo; liberamos la nuestra
            # para no tener dos en memoria al mismo tiempo.
            del ESTADO["modelo"]
            _liberar_memoria()
            _, met_entrenamiento = dpo_job.entrenar(pares, cfg_dpo, ruta_salida,
                                                    semilla=semilla,
                                                    reiniciar_desde=desde)
            _liberar_memoria()
            ESTADO["modelo"], ESTADO["tok"] = mr.cargar_modelo(cfg_dpo)
            ESTADO["adaptador_activo"] = "base"

            candidata = {"version": f"adapter-r{ronda:02d}", "ruta": ruta_salida}

            print("  evaluando el candidato...")
            comparacion = ev.comparar(candidata, politica, evaluacion, cfg_or,
                                      p_didactico, semilla + ronda,
                                      replicas=cfg_exp["evaluacion"]["replicas_bootstrap"],
                                      alfa=cfg_exp["evaluacion"]["alfa"],
                                      generador=generador,
                                      unilateral=cfg_exp["gate"].get("unilateral", False))
            c_cand = ev.correccion(candidata, canary, semilla + ronda, generador=generador)
            c_prod = ev.correccion(politica, canary, semilla + ronda, generador=generador)
            reg = ev.regresion_de_correccion(c_cand["aciertos"], c_prod["aciertos"])

            activar(candidata["ruta"], candidata["version"])
            prompts_eval = [mr.aplicar_plantilla(ESTADO["tok"], c) for c in evaluacion]
            divergencia = mr.divergencia_real(
                ESTADO["modelo"], ESTADO["tok"], prompts_eval,
                comparacion["respuestas_a"],
                max_length=cfg_dpo["dpo"]["max_length"],
                maximo=cfg_exp["muestras_divergencia"])

            metricas = {
                **{k: v for k, v in comparacion.items()
                   if k not in ("indicadores", "respuestas_a")},
                "caida_correccion": reg["caida"], "p_mcnemar": reg["p_mcnemar"],
                "correccion_candidata": c_cand["tasa_acierto"],
                "divergencia": abs(divergencia),
                "hash_lote": hash_lote, "rango_rondas": f"{rango[0]}-{rango[1]}",
                **met_entrenamiento,
            }
            veredicto = gt.decidir(metricas, cfg_exp["gate"])
            ic_candidato = metricas["ic"]

            seg.registrar_corrida(
                nombre=f"{corrida}-r{ronda:02d}",
                parametros={"hash_lote": hash_lote, "ronda": ronda,
                            "rango_rondas": metricas["rango_rondas"],
                            "beta": cfg_dpo["dpo"]["beta"], "semilla": semilla,
                            "modelo_base": cfg_dpo["modelo_base"],
                            "politica_origen": estado["version"]},
                metricas={k: v for k, v in metricas.items()
                          if isinstance(v, (int, float))},
                etiquetas={"aprueba": veredicto["aprueba"],
                           "causas": "; ".join(veredicto["causas"])})

            if veredicto["aprueba"]:
                estado["version_previa"], estado["ruta_previa"] = estado["version"], estado["ruta"]
                estado["version"], estado["ruta"] = candidata["version"], candidata["ruta"]
                accion, estado["recien_promovido"], estado["reintentos"] = "promover", True, 0
                print(f"  PROMOVER {candidata['version']}  "
                      f"win-rate {metricas['win_rate']:.3f} "
                      f"IC [{metricas['ic'][0]:.3f}, {metricas['ic'][1]:.3f}]")
            else:
                accion = "retener"
                causa = " | ".join(veredicto["causas"])
                estado["reintentos"] = (cfg_exp["entrenamiento"]["reintentos_tras_retener"]
                                        if señal["alarma"] else max(0, estado["reintentos"] - 1))
                print(f"  RETENER: {causa}")

            db.registrar_decision(con, {
                "corrida": corrida, "ronda": ronda, "alarma": int(señal["alarma"]),
                "detector": señal["detector"], "accion": accion, "causa": causa,
                "version_previa": estado["version_previa"],
                "version_nueva": estado["version"], "hash_lote": hash_lote,
                "metricas": {k: v for k, v in metricas.items()
                             if isinstance(v, (int, float))}})

        # Medicion de la ronda contra la politica base congelada.
        #
        # Si la politica en produccion no cambio desde la ronda anterior, medirla
        # de nuevo es gastar cientos de generaciones para reestimar el mismo
        # numero. Se reutiliza y se deja marcado en la bitacora. Es la mitad del
        # costo de la corrida.
        politica_actual = {"version": estado["version"], "ruta": estado["ruta"]}
        cambio = estado["version"] != medicion_previa.get("version")
        if cambio or medicion_previa.get("contra_base") is None:
            contra_base = ev.comparar(politica_actual, politica_base, evaluacion,
                                      cfg_or, p_didactico, semilla + 100 + ronda,
                                      replicas=2000,
                                      alfa=cfg_exp["evaluacion"]["alfa"],
                                      generador=generador,
                                      unilateral=cfg_exp["gate"].get("unilateral", False))
            corr = ev.correccion(politica_actual, canary, semilla + 100 + ronda,
                                 generador=generador)
            medicion_previa = {"version": estado["version"],
                               "contra_base": contra_base, "corr": corr}
            reusada = False
        else:
            contra_base = medicion_previa["contra_base"]
            corr = medicion_previa["corr"]
            reusada = True
            print("  (medicion contra la base reutilizada: la politica no cambio)")

        fila = {
            "corrida": corrida, "control": "bucle-real", "semilla": semilla,
            "ronda": ronda, "fase": cfg_or["calendario"][ronda]["fase"],
            "p_didactico": p_didactico, "alarma": int(señal["alarma"]),
            "detector": señal["detector"], "pref_longitud": señal["pref_longitud"],
            "pref_pasos": señal["pref_pasos"], "psi": señal["psi"],
            "page_hinkley": señal["page_hinkley"], "ks": señal["ks"],
            "accion": accion, "causa": causa,
            "version": estado["version"],
            "win_rate_vs_congelada": contra_base["win_rate"],
            "ic_inf": contra_base["ic"][0], "ic_sup": contra_base["ic"][1],
            "correccion": corr["tasa_acierto"],
            "longitud_media": contra_base["longitud_media"],
            "acuerdo_anotadores": rec["acuerdo_observado"],
            "medicion_reusada": reusada,
            "ic_cand_inf": ic_candidato[0] if ic_candidato else None,
            "ic_cand_sup": ic_candidato[1] if ic_candidato else None,
            "minutos": round((time.time() - arranque) / 60, 1),
        }
        anexar_bitacora(salida, fila)

        estado["ronda"] = ronda
        estado["drift"] = {"serie": estado_drift["serie"],
                           "referencia": estado_drift["referencia_longitudes"]}
        guardar_estado(salida, estado)

        print(f"  ronda {ronda} lista en {fila['minutos']} min · "
              f"wr={fila['win_rate_vs_congelada']:.3f} corr={fila['correccion']:.3f}")

    con.close()
    print(f"\nTerminado. Bitacora en {os.path.join(salida, 'bitacora.jsonl')}")


def _liberar_memoria():
    import gc
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:                                      # noqa: BLE001
        pass


def empaquetar(salida, destino=None):
    """Arma el bundle que se baja a la Mac: bitacora, decisiones y adaptadores."""
    destino = destino or os.path.join(salida, "bundle")
    os.makedirs(destino, exist_ok=True)
    for archivo in ("bitacora.jsonl", "estado.json", "preferencias.db"):
        origen = os.path.join(salida, archivo)
        if os.path.exists(origen):
            shutil.copy(origen, destino)
    adaptadores = os.path.join(salida, "adaptadores")
    if os.path.isdir(adaptadores):
        shutil.make_archive(os.path.join(destino, "adaptadores"), "zip", adaptadores)
    comprimido = shutil.make_archive(destino, "zip", destino)
    print(f"bundle: {comprimido}")
    return comprimido


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--salida", required=True,
                    help="carpeta de trabajo, idealmente en Drive")
    ap.add_argument("--config", default="configs/experimento_real.yaml")
    ap.add_argument("--config-dpo", default="configs/dpo.yaml")
    ap.add_argument("--config-oraculo", default="configs/oraculo_real.yaml",
                    help="oraculo calibrado para texto de modelo real")
    ap.add_argument("--semilla", type=int, default=11)
    ap.add_argument("--retomar", action="store_true")
    ap.add_argument("--empaquetar", action="store_true",
                    help="solo arma el bundle y sale")
    ap.add_argument("--sin-guardarrail", action="store_true",
                    help="corrida A: apaga el guardarrail de idioma y afloja el "
                         "presupuesto de KL. Es la configuracion con la que el "
                         "sistema hackea la metrica.")
    args = ap.parse_args()

    if args.empaquetar:
        empaquetar(args.salida)
        return

    with open(args.config, encoding="utf-8") as f:
        cfg_exp = yaml.safe_load(f)
    with open(args.config_dpo, encoding="utf-8") as f:
        cfg_dpo = yaml.safe_load(f)
    cfg_or = orc.cargar_config(args.config_oraculo)
    print(f"[oraculo] {args.config_oraculo} · peso_correccion="
          f"{cfg_or['peso_correccion']}")

    # La UNICA diferencia entre las dos corridas del experimento real. Todo lo
    # demas —codigo, semilla, oraculo, hiperparametros— es identico, y por eso
    # la comparacion dice algo.
    from simulador import rasgos as rg
    if args.sin_guardarrail:
        rg.activar_guardarrail_idioma(False)
        cfg_exp["gate"]["presupuesto_kl"] = 0.60
        print("[config] CORRIDA A · sin guardarrail de idioma · KL 0.60")
    else:
        rg.activar_guardarrail_idioma(True)
        print(f"[config] CORRIDA B · con guardarrail de idioma · "
              f"KL {cfg_exp['gate']['presupuesto_kl']}")

    correr(args.salida, cfg_exp, cfg_or, cfg_dpo, bc.leer_banco(),
           args.semilla, args.retomar)
    empaquetar(args.salida)


if __name__ == "__main__":
    main()
