"""Orquestador: corre las doce rondas de punta a punta, sin intervencion manual.

Cada ronda:
    recolectar preferencias -> monitorear drift -> (si corresponde) entrenar
    -> evaluar contra la politica en produccion -> gate -> promover, retener o
    revertir -> registrar la decision.

Uso:
    python -m orquestador.experimento --control bucle --semilla 11
    python -m orquestador.experimento --todos
"""

import argparse
import json
import os

import yaml

from drift import monitor
from entrenamiento import datos as dts
from entrenamiento import job_simulado as jsim
from gate import evaluacion as ev
from gate import gate as gt
from orquestador import seguimiento as seg
from serving import cliente
from serving.plantillas import politica_inicial
from simulador import consultas as bc
from simulador import oraculo as orc
from simulador import recolector as rec
from store import db

MODO = os.environ.get("MODO", "simulado")


def cargar_experimento(ruta="configs/experimento.yaml"):
    with open(ruta, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _entrena_esta_ronda(control, ronda, alarma, reintentos_pendientes):
    if ronda == 1:
        return True                      # ajuste inicial, comun a todos los brazos
    if control == "congelado":
        return False
    if control in ("ciego", "oraculo"):
        return True
    # Bucle y negativo reaccionan a la alarma. El reintento existe porque una
    # alarma correcta con un candidato rechazado por el gate dejaria al sistema
    # esperando la proxima alarma: el detector se reinicio y la ventana todavia
    # arrastra pares de la fase anterior. Sin reintento, el sistema detecta el
    # cambio y aun asi no se adapta, que es el modo de falla mas caro del diseño.
    return alarma or reintentos_pendientes > 0


def _enriquecer(pares, indice_hechos):
    for p in pares:
        p["hechos_clave"] = indice_hechos.get(p["consulta_id"], [])
    return pares


def correr(control, semilla, cfg_exp, cfg_or, banco, ruta_db=None):
    corrida = f"{control}-s{semilla}"
    con = db.conectar(ruta_db or db.RUTA_POR_DEFECTO)
    db.inicializar(con)
    db.limpiar_corrida(con, corrida)

    recoleccion = bc.por_split(banco, "recoleccion")
    evaluacion = bc.por_split(banco, "evaluacion", cfg_exp["evaluacion"]["n_consultas"])
    canary = bc.por_split(banco, "canary", cfg_exp["evaluacion"]["n_canary"])
    indice_hechos = {c["consulta_id"]: c["hechos_clave"] for c in banco}

    seg.iniciar_experimento(f"dpo-continuo/{control}")

    politica = politica_inicial()
    politica_congelada = politica_inicial()   # referencia fija de todo el experimento
    politica_previa = dict(politica)
    version, version_previa = "base", None
    estado_drift = monitor.estado_inicial()
    bitacora = []
    recien_promovido = False
    reintentos = 0
    max_reintentos = cfg_exp["entrenamiento"].get("reintentos_tras_retener", 2)

    for ronda in range(1, cfg_exp["rondas"] + 1):
        p_didactico = cfg_or["calendario"][ronda]["p_didactico"]

        # 1. Recoleccion -------------------------------------------------
        stats = rec.recolectar_ronda(con, corrida, ronda, politica, cfg_or,
                                     cfg_exp, semilla, recoleccion, version)

        # 2. Deteccion de drift -----------------------------------------
        señal = monitor.revisar(estado_drift, con, corrida, ronda, cfg_exp)
        alarma = señal["alarma"]
        if control == "oraculo":
            # Cota superior: reacciona con la fase visible, sin esperar alarma.
            alarma = True

        accion, causa, metricas = "sin_accion", None, {}

        # 3. Rollback de la promocion anterior --------------------------
        if recien_promovido:
            post = ev.comparar(politica, politica_previa, evaluacion, cfg_or,
                               p_didactico, semilla + ronda,
                               replicas=cfg_exp["evaluacion"]["replicas_bootstrap"],
                               alfa=cfg_exp["evaluacion"]["alfa"])
            corr_nueva = ev.correccion(politica, canary, semilla + ronda)
            corr_previa = ev.correccion(politica_previa, canary, semilla + ronda)
            reg = ev.regresion_de_correccion(corr_nueva["aciertos"],
                                             corr_previa["aciertos"])
            post["caida_correccion"] = reg["caida"]
            revertir, motivo = gt.hay_que_revertir(post, cfg_exp["gate"])
            if revertir:
                politica, version = dict(politica_previa), version_previa or "base"
                accion, causa = "revertir", motivo
                db.registrar_decision(con, {
                    "corrida": corrida, "ronda": ronda, "alarma": int(alarma),
                    "detector": señal["detector"], "accion": accion, "causa": causa,
                    "version_previa": version_previa, "version_nueva": version,
                    "metricas": {"win_rate_post": post["win_rate"]}})
            recien_promovido = False

        # 4. Entrenamiento ----------------------------------------------
        forzar = ronda == cfg_exp.get("demo", {}).get("candidato_malo_en_ronda")
        if accion != "revertir" and (forzar or _entrena_esta_ronda(
                control, ronda, alarma, reintentos)):
            pares, hash_lote, rango = dts.armar_lote(
                con, corrida, ronda, cfg_exp, control=control, semilla=semilla)
            pares = _enriquecer(pares, indice_hechos)
            ev.verificar_fuga(pares, evaluacion + canary)

            base = politica_inicial() if cfg_exp["entrenamiento"]["reiniciar_desde_base"] \
                else politica
            candidata, met_entrenamiento = jsim.entrenar(
                base, pares, beta=cfg_exp["entrenamiento"]["beta"],
                eta=cfg_exp["entrenamiento"]["eta"])
            if ronda == cfg_exp.get("demo", {}).get("candidato_malo_en_ronda"):
                # Demostracion del rollback: se inyecta a proposito un candidato
                # peor. Con el gate aflojado pasa, y la revision de la ronda
                # siguiente tiene que revertirlo.
                candidata = {**candidata, "cobertura_objetivo": 0.40}

            nueva_version = f"adapter-r{ronda:02d}"
            ruta = jsim.guardar_adaptador(candidata, f"{corrida}-{nueva_version}",
                                          hash_lote)

            # 5. Evaluacion y gate --------------------------------------
            comparacion = ev.comparar(candidata, politica, evaluacion, cfg_or,
                                      p_didactico, semilla + ronda,
                                      replicas=cfg_exp["evaluacion"]["replicas_bootstrap"],
                                      alfa=cfg_exp["evaluacion"]["alfa"])
            corr_cand = ev.correccion(candidata, canary, semilla + ronda)
            corr_prod = ev.correccion(politica, canary, semilla + ronda)
            reg = ev.regresion_de_correccion(corr_cand["aciertos"], corr_prod["aciertos"])

            metricas = {
                **{k: v for k, v in comparacion.items()
                   if k not in ("indicadores", "respuestas_a")},
                "caida_correccion": reg["caida"],
                "p_mcnemar": reg["p_mcnemar"],
                "correccion_candidata": corr_cand["tasa_acierto"],
                "divergencia": ev.divergencia(candidata, politica_congelada),
                "hash_lote": hash_lote,
                "rango_rondas": f"{rango[0]}-{rango[1]}",
                **met_entrenamiento,
            }
            veredicto = gt.decidir(metricas, cfg_exp["gate"])

            seg.registrar_corrida(
                nombre=f"{corrida}-{nueva_version}",
                parametros={"hash_lote": hash_lote, "control": control,
                            "semilla": semilla, "ronda": ronda,
                            "rango_rondas": metricas["rango_rondas"],
                            "beta": cfg_exp["entrenamiento"]["beta"],
                            "ventana": cfg_exp["entrenamiento"]["ventana_rondas"],
                            "politica_origen": version},
                metricas={k: v for k, v in metricas.items()
                          if isinstance(v, (int, float))},
                etiquetas={"aprueba": veredicto["aprueba"],
                           "causas": "; ".join(veredicto["causas"])},
                artefactos=[ruta])

            if veredicto["aprueba"]:
                politica_previa, version_previa = dict(politica), version
                politica, version = candidata, nueva_version
                cliente.activar_adaptador(version, ruta, hash_lote)
                accion, causa, recien_promovido = "promover", None, True
                reintentos = 0
            else:
                accion = "retener"
                causa = " | ".join(veredicto["causas"])
                reintentos = max_reintentos if alarma else max(0, reintentos - 1)

            db.registrar_decision(con, {
                "corrida": corrida, "ronda": ronda, "alarma": int(alarma),
                "detector": señal["detector"], "accion": accion, "causa": causa,
                "version_previa": version_previa, "version_nueva": version,
                "hash_lote": hash_lote,
                "metricas": {k: v for k, v in metricas.items()
                             if isinstance(v, (int, float))}})

        # 6. Medicion de la ronda, siempre, con la poblacion vigente ------
        contra_congelada = ev.comparar(politica, politica_congelada, evaluacion,
                                       cfg_or, p_didactico, semilla + 100 + ronda,
                                       replicas=2000,
                                       alfa=cfg_exp["evaluacion"]["alfa"])
        corr_actual = ev.correccion(politica, canary, semilla + 100 + ronda)

        bitacora.append({
            "corrida": corrida, "control": control, "semilla": semilla,
            "ronda": ronda, "fase": cfg_or["calendario"][ronda]["fase"],
            "p_didactico": p_didactico,
            "alarma": int(alarma), "detector": señal["detector"],
            "pref_longitud": señal["pref_longitud"],
            "pref_pasos": señal["pref_pasos"],
            "psi": señal["psi"], "page_hinkley": señal["page_hinkley"],
            "accion": accion, "causa": causa, "version": version,
            "win_rate_vs_congelada": contra_congelada["win_rate"],
            "ic_inf": contra_congelada["ic"][0], "ic_sup": contra_congelada["ic"][1],
            "correccion": corr_actual["tasa_acierto"],
            "longitud_media": contra_congelada["longitud_media"],
            "acuerdo_anotadores": stats["acuerdo_observado"],
            "politica": dict(politica),
        })
        print(f"[{corrida}] ronda {ronda:2d} fase {bitacora[-1]['fase']} "
              f"alarma={int(alarma)} accion={accion:10s} "
              f"wr={contra_congelada['win_rate']:.3f} "
              f"corr={corr_actual['tasa_acierto']:.3f}")

    con.close()
    return bitacora


def escribir_bitacora(bitacoras, ruta="artefactos/bitacora.jsonl"):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        for fila in bitacoras:
            f.write(json.dumps(fila, ensure_ascii=False) + "\n")
    return ruta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--control", default="bucle")
    ap.add_argument("--semilla", type=int, default=11)
    ap.add_argument("--todos", action="store_true",
                    help="corre los cinco controles con las tres semillas")
    ap.add_argument("--config", default="configs/experimento.yaml")
    ap.add_argument("--sabotear-gate", action="store_true",
                    help="afloja el gate para forzar una promocion mala y ver "
                         "el rollback en accion (demostracion, no experimento)")
    args = ap.parse_args()

    cfg_exp = cargar_experimento(args.config)
    if args.sabotear_gate:
        cfg_exp["gate"] = {**cfg_exp["gate"], "win_rate_ic_inferior": 0.0,
                           "caida_maxima_correccion": 1.0, "presupuesto_kl": 99.0,
                           "tasa_maxima_degeneradas": 1.0}
        cfg_exp["entrenamiento"] = {**cfg_exp["entrenamiento"], "eta": 1.2}
        cfg_exp["demo"] = {"candidato_malo_en_ronda": 7}
    cfg_or = orc.cargar_config()
    banco = bc.leer_banco()

    todas = []
    if args.todos:
        for control in cfg_exp["controles"]:
            for semilla in cfg_exp["semillas"]:
                todas += correr(control, semilla, cfg_exp, cfg_or, banco)
    else:
        todas = correr(args.control, args.semilla, cfg_exp, cfg_or, banco)

    ruta = escribir_bitacora(todas)
    print(f"\nbitacora: {ruta}  ({len(todas)} filas)")


if __name__ == "__main__":
    main()
