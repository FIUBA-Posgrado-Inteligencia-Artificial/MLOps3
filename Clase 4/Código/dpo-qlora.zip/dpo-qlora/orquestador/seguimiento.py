"""Seguimiento de experimentos.

MLflow cuando esta disponible (es lo que se corrige), y un registro local en
JSONL como respaldo para que los tests y una maquina sin MLflow levantado no
queden bloqueados. El respaldo no reemplaza al registry en la entrega.
"""

import json
import os
from datetime import datetime, timezone

USAR_MLFLOW = os.environ.get("USAR_MLFLOW", "1") == "1"
RUTA_RESPALDO = os.environ.get("REGISTRO_LOCAL", "artefactos/registro.jsonl")

_mlflow = None


def _servidor_responde(uri, segundos=2.0):
    """Sondeo corto antes de usar MLflow.

    Sin esto, una corrida contra un servidor caido no falla: se queda
    reintentando con backoff dentro de mlflow y parece colgada. Es el peor
    momento para descubrirlo, sobre todo si la corrida es una demostracion en
    vivo. Mejor detectarlo en dos segundos y pasar al respaldo local.
    """
    if uri.startswith("file:") or not uri.startswith("http"):
        return True
    try:
        import urllib.request
        urllib.request.urlopen(uri.rstrip("/") + "/health", timeout=segundos)
        return True
    except Exception:                                      # noqa: BLE001
        return False


if USAR_MLFLOW:
    _uri = os.environ.get("MLFLOW_TRACKING_URI", "http://localhost:5000")
    try:
        import mlflow as _modulo_mlflow
        if _servidor_responde(_uri):
            _modulo_mlflow.set_tracking_uri(_uri)
            _mlflow = _modulo_mlflow
        else:
            print(f"[seguimiento] MLflow no responde en {_uri}: "
                  f"se registra en {RUTA_RESPALDO}")
    except Exception:                                      # noqa: BLE001
        _mlflow = None


def _escribir_respaldo(evento):
    os.makedirs(os.path.dirname(RUTA_RESPALDO) or ".", exist_ok=True)
    evento["ts"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with open(RUTA_RESPALDO, "a", encoding="utf-8") as f:
        f.write(json.dumps(evento, ensure_ascii=False) + "\n")


def iniciar_experimento(nombre):
    if _mlflow is not None:
        _mlflow.set_experiment(nombre)


def registrar_corrida(nombre, parametros, metricas, etiquetas=None, artefactos=None):
    """Una corrida por entrenamiento. Sin hash de lote no se promociona."""
    if "hash_lote" not in parametros:
        raise ValueError("toda corrida tiene que registrar su hash_lote")

    if _mlflow is not None:
        with _mlflow.start_run(run_name=nombre):
            _mlflow.log_params({k: str(v) for k, v in parametros.items()})
            _mlflow.log_metrics({k: float(v) for k, v in metricas.items()
                                 if isinstance(v, (int, float))})
            for k, v in (etiquetas or {}).items():
                _mlflow.set_tag(k, str(v))
            for ruta in (artefactos or []):
                if os.path.exists(ruta):
                    _mlflow.log_artifact(ruta)
            return _mlflow.active_run().info.run_id if _mlflow.active_run() else nombre

    _escribir_respaldo({"corrida": nombre, "parametros": parametros,
                        "metricas": metricas, "etiquetas": etiquetas or {}})
    return nombre
