"""Acceso al preference store.

Regla central del TP, y esta implementada en el codigo, no solo en el enunciado:
el sistema en linea (detector, entrenador, gate) lee por
`leer_pares_para_el_sistema`, que no devuelve la fase ni el margen de utilidad.
El analisis post-hoc lee por `leer_pares_para_analisis`.
"""

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone

RUTA_POR_DEFECTO = os.environ.get("STORE_SQLITE", "data/preferencias.db")

CAMPOS_PROHIBIDOS_EN_LINEA = ("fase_oraculo", "margen_utilidad", "perfil_anotador")


def _ahora():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def conectar(ruta=RUTA_POR_DEFECTO):
    os.makedirs(os.path.dirname(ruta) or ".", exist_ok=True)
    con = sqlite3.connect(ruta)
    con.row_factory = sqlite3.Row
    return con


def inicializar(con, ruta_esquema="store/esquema.sql"):
    with open(ruta_esquema, encoding="utf-8") as f:
        con.executescript(f.read())
    con.commit()


def limpiar_corrida(con, corrida):
    con.execute("DELETE FROM pares WHERE corrida = ?", (corrida,))
    con.execute("DELETE FROM decisiones WHERE corrida = ?", (corrida,))
    con.commit()


def guardar_par(con, registro):
    con.execute(
        """INSERT INTO pares (par_id, consulta_id, prompt, chosen, rejected,
                              policy_version, ronda, corrida, fase_oraculo,
                              perfil_anotador, segmento, margen_utilidad,
                              es_duplicado, ts)
           VALUES (:par_id, :consulta_id, :prompt, :chosen, :rejected,
                   :policy_version, :ronda, :corrida, :fase_oraculo,
                   :perfil_anotador, :segmento, :margen_utilidad,
                   :es_duplicado, :ts)""",
        {"par_id": registro.get("par_id") or str(uuid.uuid4()),
         "ts": registro.get("ts") or _ahora(),
         **{k: registro.get(k) for k in
            ("consulta_id", "prompt", "chosen", "rejected", "policy_version",
             "ronda", "corrida", "fase_oraculo", "perfil_anotador", "segmento",
             "margen_utilidad", "es_duplicado")}},
    )


def leer_pares_para_el_sistema(con, corrida, desde_ronda=1, hasta_ronda=999):
    filas = con.execute(
        """SELECT par_id, consulta_id, prompt, chosen, rejected, policy_version,
                  ronda, segmento, ts
             FROM pares
            WHERE corrida = ? AND ronda BETWEEN ? AND ? AND es_duplicado = 0
            ORDER BY ronda, par_id""",
        (corrida, desde_ronda, hasta_ronda),
    ).fetchall()
    return [dict(f) for f in filas]


def leer_pares_para_analisis(con, corrida):
    filas = con.execute(
        "SELECT * FROM pares WHERE corrida = ? ORDER BY ronda, par_id",
        (corrida,),
    ).fetchall()
    return [dict(f) for f in filas]


def registrar_decision(con, registro):
    con.execute(
        """INSERT INTO decisiones (decision_id, corrida, ronda, alarma, detector,
                                   accion, causa, version_previa, version_nueva,
                                   hash_lote, metricas_json, ts)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (str(uuid.uuid4()), registro["corrida"], registro["ronda"],
         int(registro.get("alarma", 0)), registro.get("detector"),
         registro["accion"], registro.get("causa"),
         registro.get("version_previa"), registro.get("version_nueva"),
         registro.get("hash_lote"),
         json.dumps(registro.get("metricas", {}), ensure_ascii=False), _ahora()),
    )
    con.commit()


def leer_decisiones(con, corrida):
    filas = con.execute(
        "SELECT * FROM decisiones WHERE corrida = ? ORDER BY ronda, ts",
        (corrida,),
    ).fetchall()
    return [dict(f) for f in filas]
