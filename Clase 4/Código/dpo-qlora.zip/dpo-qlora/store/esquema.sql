-- Preference store. Un par por fila, inmutable una vez escrito.

CREATE TABLE IF NOT EXISTS pares (
    par_id           TEXT PRIMARY KEY,
    consulta_id      TEXT NOT NULL,
    prompt           TEXT NOT NULL,
    chosen           TEXT NOT NULL,
    rejected         TEXT NOT NULL,
    policy_version   TEXT NOT NULL,
    ronda            INTEGER NOT NULL,
    corrida          TEXT NOT NULL,
    -- Campos de analisis post-hoc. El sistema NO puede leerlos:
    -- el acceso pasa por leer_pares_para_el_sistema(), que los excluye.
    fase_oraculo     TEXT,
    perfil_anotador  TEXT,
    segmento         TEXT,
    margen_utilidad  REAL,
    es_duplicado     INTEGER NOT NULL DEFAULT 0,
    ts               TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_pares_ronda   ON pares (corrida, ronda);
CREATE INDEX IF NOT EXISTS idx_pares_consulta ON pares (consulta_id);

-- Bitacora de decisiones del sistema: una fila por decision del gate.
CREATE TABLE IF NOT EXISTS decisiones (
    decision_id    TEXT PRIMARY KEY,
    corrida        TEXT NOT NULL,
    ronda          INTEGER NOT NULL,
    alarma         INTEGER NOT NULL,
    detector       TEXT,
    accion         TEXT NOT NULL,          -- promover | retener | revertir | sin_accion
    causa          TEXT,
    version_previa TEXT,
    version_nueva  TEXT,
    hash_lote      TEXT,
    metricas_json  TEXT,
    ts             TEXT NOT NULL
);
