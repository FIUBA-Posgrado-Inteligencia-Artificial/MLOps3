"""Contrato de datos del preference store.

    python -m store.validacion corrida-A-sin-guardarrail/preferencias.db

Existe por el hallazgo de la corrida B: el oraculo eligio respuestas enteras en
chino, el par paso la curacion por margen, y entro al entrenamiento de DPO como
lo que habia que imitar. El guardarrail de idioma las media correctamente
—fraccion fuera de idioma 1.000— pero vive en el gate, o sea en la SALIDA, y
para cuando mide, el dano ya entro por los datos.

Esto es la misma metrica movida a la ENTRADA. No es una metrica nueva ni un
detector mas: es la de siempre, aplicada donde se construye el lote en lugar de
donde se evalua el resultado.

No reemplaza al guardarrail del gate. Las dos capas miran lo mismo en momentos
distintos, y esa es la idea: la de la entrada evita entrenar con basura, la de
la salida detecta al modelo que se degrado por su cuenta.
"""
import argparse
import sqlite3
import sys

from simulador.rasgos import UMBRAL_FUERA_DE_IDIOMA, fraccion_fuera_de_idioma

# Cuantos caracteres fuera del alfabeto latino alcanzan para descartar un par.
# Es un conteo absoluto y no una fraccion a proposito: cinco ideogramas en un
# parrafo largo son una fraccion despreciable y siguen siendo un defecto en
# algo con lo que se va a entrenar. analisis/contaminacion.py importa esta
# misma constante, para que las dos herramientas informen el mismo numero.
UMBRAL_CARACTERES_AJENOS = 5


def caracteres_ajenos(texto):
    return sum(1 for c in texto if ord(c) > 0x2E80)


def problemas_del_par(par):
    """Reglas que el par incumple. Lista vacia = el par sirve para entrenar."""
    fallas = []
    elegida = (par.get("chosen") or "").strip()
    descartada = (par.get("rejected") or "").strip()
    prompt = (par.get("prompt") or "").strip()

    if not prompt:
        fallas.append("sin prompt: el par no se puede auditar despues")
    if not elegida:
        fallas.append("elegida vacia")
    if not descartada:
        fallas.append("descartada vacia")
    if elegida and elegida == descartada:
        fallas.append("elegida y descartada identicas: no hay nada que aprender")

    if elegida:
        fuera = fraccion_fuera_de_idioma(elegida)
        if fuera > UMBRAL_FUERA_DE_IDIOMA:
            fallas.append(f"la elegida se fue del idioma ({fuera:.3f})")

        # Regla aparte, y vale la pena entender por que.
        #
        # fraccion_fuera_de_idioma promedia caracteres ajenos y marcadores
        # lexicos sobre todo el texto, asi que un parrafo mayormente en espanol
        # con un bloque en otro alfabeto queda por debajo del umbral. Sobre la
        # corrida B atrapa 5 de los 12 pares contaminados.
        #
        # Esta mira la clase de caracter directamente y no se diluye. Atrapa los
        # 12. La leccion es que una metrica promediada esconde justo el caso que
        # mas dano hace.
        ajenos = caracteres_ajenos(elegida)
        if ajenos > UMBRAL_CARACTERES_AJENOS:
            fallas.append(f"alfabeto ajeno en la elegida ({ajenos} caracteres)")
    return fallas


def filtrar(pares, avisar=True):
    """Devuelve (pares_validos, descartados). Los descartados llevan 'fallas'."""
    validos, descartados = [], []
    for p in pares:
        fallas = problemas_del_par(p)
        if fallas:
            descartados.append({**p, "fallas": fallas})
        else:
            validos.append(p)
    if avisar and descartados:
        print(f"    contrato de datos: {len(pares)} -> {len(validos)} pares "
              f"({len(descartados)} incumplen)")
    return validos, descartados


def revisar_base(ruta):
    con = sqlite3.connect(ruta)
    con.row_factory = sqlite3.Row
    filas = [dict(f) for f in con.execute("select * from pares order by ronda, par_id")]
    con.close()

    _, malos = filtrar(filas, avisar=False)
    print("=" * 78)
    print(ruta)
    print("=" * 78)
    if not filas:
        print("  la base esta vacia")
        return 0

    por_ronda = {}
    conteo = {}
    for m in malos:
        por_ronda[m["ronda"]] = por_ronda.get(m["ronda"], 0) + 1
        for f in m["fallas"]:
            clave = f.split(" (")[0]
            conteo[clave] = conteo.get(clave, 0) + 1

    print(f"  {len(malos)} de {len(filas)} pares incumplen el contrato "
          f"({100 * len(malos) / len(filas):.1f}%)")
    if por_ronda:
        print("  por ronda: " + " · ".join(f"r{r}: {n}" for r, n in sorted(por_ronda.items())))
    for regla, n in sorted(conteo.items(), key=lambda kv: -kv[1]):
        print(f"    {n:4d}  {regla}")
    if malos:
        print()
        print("  Todos estos entraron al entrenamiento. El contrato los habria")
        print("  dejado afuera antes de armar el lote, no despues de evaluarlo.")
    return len(malos)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bases", nargs="+", help="rutas a preferencias.db")
    args = ap.parse_args()
    total = 0
    for b in args.bases:
        total += revisar_base(b)
        print()
    sys.exit(0)


if __name__ == "__main__":
    main()
