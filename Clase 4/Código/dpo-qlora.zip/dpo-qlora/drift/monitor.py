"""Monitor de drift: combina los dos detectores y decide si hay alarma.

- toma en cuenta los umbrales que hay en el yaml
- maneja dos detectores: Page-Hinkley (secuencial) y PSI (distribucion)

...

- compara si las respuestas elegidas van cambiando:
    - palabras en promedio

- dispara alarma si:
    - las elegidas se acortan de golpe	
    - los cajones largos se vacían
    - las elegidas se alargan de golpe (igual  al revés)
    - aparecen respuestas de 10 palabras que antes no existían
"""

from drift import detectores as det
from store import db


def estado_inicial():
    return {"ph": det.estado_page_hinkley(),
            "serie": [],
            "referencia_longitudes": None}


def revisar(estado, con, corrida, ronda, cfg_exp):
    pares = db.leer_pares_para_el_sistema(con, corrida, ronda, ronda)
    señales = det.señales_de_la_ronda(pares)
    estado["serie"].append(señales["pref_longitud"])

    cfg_ph = cfg_exp["drift"]["page_hinkley"]
    alarma_ph, valor_ph = det.actualizar_page_hinkley(
        estado["ph"], señales["pref_longitud"], cfg_ph["delta"], cfg_ph["umbral"])

    cfg_psi = cfg_exp["drift"]["psi"]
    if estado["referencia_longitudes"] is None:
        resultado_psi = {"alarma": False, "psi": 0.0, "ks": 0.0, "p_ks": 1.0}
    else:
        resultado_psi = det.alarma_psi(estado["referencia_longitudes"],
                                       señales["longitudes_elegidas"],
                                       bins=cfg_psi["bins"], umbral=cfg_psi["umbral"])

    alarma = bool(alarma_ph or resultado_psi["alarma"])
    disparado = "page_hinkley" if alarma_ph else ("psi" if resultado_psi["alarma"] else None)

    if alarma:
        # Tras una alarma el detector se reinicia y toma la ronda actual como
        # nueva referencia: si no, alarma en todas las rondas siguientes.
        estado["ph"] = det.reiniciar_page_hinkley()
        estado["referencia_longitudes"] = señales["longitudes_elegidas"]
    elif estado["referencia_longitudes"] is None:
        estado["referencia_longitudes"] = señales["longitudes_elegidas"]

    return {
        "alarma": alarma,
        "detector": disparado,
        "page_hinkley": valor_ph,
        "psi": resultado_psi["psi"],
        "ks": resultado_psi["ks"],
        "pref_longitud": señales["pref_longitud"],
        "pref_pasos": señales["pref_pasos"],
        "n_pares": señales["n"],
    }
