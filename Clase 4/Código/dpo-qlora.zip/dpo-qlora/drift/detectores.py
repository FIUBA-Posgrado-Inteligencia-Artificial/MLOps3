"""Deteccion de drift sobre la señal de preferencia.

# aca no hay covariate shift. La
distribucion de consultas de entrada es la misma en las doce rondas. Lo que se
mueve es la funcion de utilidad del anotador, es decir, la etiqueta. Casi toda
la literatura de drift que se encuentra en Google asume lo primero.

Dos familias, como pide el enunciado:
  - secuencial parametrica: Page-Hinkley sobre una señal escalar por ronda
  - no parametrica de distribucion: PSI y Kolmogorov-Smirnov sobre la
    distribucion de un rasgo observable de las respuestas elegidas

Ninguna de las dos toca `fase_oraculo` ni `margen_utilidad`: trabajan sobre lo
que devuelve store.db.leer_pares_para_el_sistema.
"""

import numpy as np

from gate import estadistica as est
from simulador.rasgos import contar_tokens, tiene_pasos_numerados


# --------------------------------------------------------------------------
# Señales observables
# --------------------------------------------------------------------------

def señales_de_la_ronda(pares):
    """Escalares y muestras derivados solo de lo que el sistema puede ver."""
    if not pares:
        return {"pref_longitud": 0.5, "pref_pasos": 0.5,
                "longitudes_elegidas": [], "n": 0}
    gana_el_largo, gana_con_pasos, longitudes = [], [], []
    for p in pares:
        lc, lr = contar_tokens(p["chosen"]), contar_tokens(p["rejected"])
        if lc != lr:
            gana_el_largo.append(1.0 if lc > lr else 0.0)
        pc, pr = tiene_pasos_numerados(p["chosen"]), tiene_pasos_numerados(p["rejected"])
        if pc != pr:
            gana_con_pasos.append(1.0 if pc > pr else 0.0)
        longitudes.append(float(lc))
    return {
        "pref_longitud": float(np.mean(gana_el_largo)) if gana_el_largo else 0.5,
        "pref_pasos": float(np.mean(gana_con_pasos)) if gana_con_pasos else 0.5,
        "longitudes_elegidas": longitudes,
        "n": len(pares),
    }


# --------------------------------------------------------------------------
# Page-Hinkley
# --------------------------------------------------------------------------

def estado_page_hinkley():
    return {"n": 0, "media": 0.0, "suma_max": 0.0, "suma_min": 0.0,
            "m_max": 0.0, "m_min": 0.0}


def actualizar_page_hinkley(estado, x, delta, umbral):
    """Version bilateral: alarma ante aumentos y ante caidas de la media."""
    estado["n"] += 1
    estado["media"] += (x - estado["media"]) / estado["n"]

    estado["suma_max"] += x - estado["media"] - delta
    estado["m_max"] = min(estado["m_max"], estado["suma_max"])
    estado["suma_min"] += estado["media"] - x - delta
    estado["m_min"] = min(estado["m_min"], estado["suma_min"])

    ph_sube = estado["suma_max"] - estado["m_max"]
    ph_baja = estado["suma_min"] - estado["m_min"]
    alarma = estado["n"] >= 3 and max(ph_sube, ph_baja) > umbral
    return alarma, max(ph_sube, ph_baja)


def reiniciar_page_hinkley():
    return estado_page_hinkley()


# --------------------------------------------------------------------------
# Distribucion
# --------------------------------------------------------------------------

def alarma_psi(longitudes_referencia, longitudes_actuales, bins=10, umbral=0.20):
    valor = est.psi(longitudes_referencia, longitudes_actuales, bins=bins)
    prueba = est.ks(longitudes_referencia, longitudes_actuales)
    return {"alarma": valor > umbral, "psi": valor,
            "ks": prueba["estadistico"], "p_ks": prueba["p"]}


# --------------------------------------------------------------------------
# Caracterizacion: retardo contra falsas alarmas
# --------------------------------------------------------------------------

def primera_alarma(serie, delta, umbral):
    estado = estado_page_hinkley()
    for i, x in enumerate(serie):
        alarma, _ = actualizar_page_hinkley(estado, x, delta, umbral)
        if alarma:
            return i
    return None


def curva_retardo_falsas_alarmas(serie, umbrales, ronda_del_cambio, delta=0.005):
    """Para cada umbral: retardo de deteccion y falsas alarmas previas al cambio.

    `ronda_del_cambio` es indice base 0 dentro de `serie`, y se usa SOLO para
    caracterizar al detector fuera de linea. El sistema en produccion nunca lo
    recibe.
    """
    filas = []
    for u in umbrales:
        estado = estado_page_hinkley()
        falsas, retardo = 0, None
        for i, x in enumerate(serie):
            alarma, _ = actualizar_page_hinkley(estado, x, delta, u)
            if not alarma:
                continue
            if i < ronda_del_cambio:
                falsas += 1
                estado = reiniciar_page_hinkley()
            elif retardo is None:
                retardo = i - ronda_del_cambio
        filas.append({"umbral": u, "retardo": retardo, "falsas_alarmas": falsas})
    return filas
