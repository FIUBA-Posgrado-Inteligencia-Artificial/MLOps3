"""Si la estadistica esta mal, el gate promueve cualquier cosa."""

import numpy as np

from gate import estadistica as est


def test_el_ic_cubre_el_valor_verdadero_la_mayoria_de_las_veces():
    rng = np.random.default_rng(0)
    cubre = 0
    for i in range(200):
        muestra = rng.binomial(1, 0.60, size=300)
        r = est.bootstrap_pareado(muestra, replicas=800, semilla=i)
        cubre += int(r["ic"][0] <= 0.60 <= r["ic"][1])
    assert cubre / 200 > 0.90


def test_el_ic_de_una_moneda_justa_contiene_a_un_medio():
    rng = np.random.default_rng(1)
    r = est.bootstrap_pareado(rng.binomial(1, 0.5, size=400), replicas=2000)
    assert r["ic"][0] < 0.5 < r["ic"][1]


def test_mcnemar_detecta_una_regresion_clara():
    assert est.mcnemar(a_bien_b_mal=2, a_mal_b_bien=25)["p"] < 0.01
    assert est.mcnemar(a_bien_b_mal=12, a_mal_b_bien=13)["p"] > 0.20


def test_holm_es_mas_conservador_que_no_corregir():
    ps = [0.001, 0.02, 0.03, 0.30, 0.49]
    res = est.holm_bonferroni(ps, alfa=0.05)
    assert res[0]["rechaza"]
    assert not res[3]["rechaza"]
    assert all(r["p_ajustado"] >= r["p"] for r in res)
    # Monotonia: p ajustados no decrecientes al ordenar por p.
    ajustados = [r["p_ajustado"] for r in sorted(res, key=lambda r: r["p"])]
    assert ajustados == sorted(ajustados)


def test_la_potencia_crece_con_n_y_con_el_efecto():
    assert est.potencia_pareada(0.55, 100) < est.potencia_pareada(0.55, 800)
    assert est.potencia_pareada(0.55, 300) < est.potencia_pareada(0.65, 300)


def test_n_para_potencia_es_coherente():
    n = est.n_para_potencia(0.60, potencia_objetivo=0.80)
    assert n is not None
    assert est.potencia_pareada(0.60, n) >= 0.80
    assert est.potencia_pareada(0.60, max(30, n - 25)) < 0.85


def test_psi_es_cero_sin_cambio_y_crece_con_el_desplazamiento():
    rng = np.random.default_rng(2)
    a = rng.normal(100, 20, 3000)
    b = rng.normal(100, 20, 3000)
    c = rng.normal(60, 20, 3000)
    assert est.psi(a, b) < 0.10
    assert est.psi(a, c) > 0.25
