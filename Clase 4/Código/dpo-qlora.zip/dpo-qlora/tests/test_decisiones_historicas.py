"""Las decisiones de las corridas reales, como prueba de regresion.

Es el unico test que no usa datos sinteticos: lee lo que el gate decidio de
verdad en las dos corridas de Colab y verifica que, con la configuracion
actual, esas decisiones siguen siendo coherentes.

Para que sirve: si alguien mueve un umbral en configs/ o toca una linea de
gate/gate.py, las decisiones ya tomadas dejan de reproducirse y la prueba
falla. El gate deja de ser un script que alguien corre y pasa a ser una
politica anclada a datos historicos.

Se saltea si no estan las carpetas de corrida, que es lo que pasa en Colab:
ahi el repositorio llega sin resultados.

Nota sobre que se verifica y que no. El intervalo de confianza que uso el gate
fue el del candidato y no quedo guardado en la bitacora (la bitacora registra
la medicion de la ronda, que es otra). Asi que la condicion del win-rate no se
puede recalcular. Las otras tres si, porque sus entradas estan completas en
decisiones.metricas_json. La prueba verifica la implicacion que si se puede
comprobar: si alguna de esas tres condiciones se viola, la accion NO pudo haber
sido promover.
"""
import json
import os
import sqlite3

import pytest
import yaml

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# La corrida A corrio con --sin-guardarrail, que ademas de apagar el guardarrail
# de idioma afloja el presupuesto de KL a 0.60. Ver orquestador/experimento_real.
CORRIDAS = {
    "corrida-A-sin-guardarrail": 0.60,
    "corrida-B-con-guardarrail": None,          # el valor del YAML
}


def _cfg_gate():
    with open(os.path.join(RAIZ, "configs/experimento_real.yaml"), encoding="utf-8") as f:
        return yaml.safe_load(f)["gate"]


def _decisiones(carpeta):
    base = os.path.join(RAIZ, carpeta, "preferencias.db")
    con = sqlite3.connect(base)
    filas = con.execute(
        "select ronda, accion, metricas_json from decisiones order by ronda").fetchall()
    con.close()
    return [(r, a, json.loads(m)) for r, a, m in filas]


def _hay_datos(carpeta):
    return os.path.exists(os.path.join(RAIZ, carpeta, "preferencias.db"))


@pytest.mark.parametrize("carpeta", sorted(CORRIDAS))
def test_las_decisiones_registradas_siguen_siendo_coherentes(carpeta):
    if not _hay_datos(carpeta):
        pytest.skip(f"{carpeta} no esta en esta copia del repositorio")

    cfg = _cfg_gate()
    presupuesto = CORRIDAS[carpeta] or cfg["presupuesto_kl"]

    for ronda, accion, m in _decisiones(carpeta):
        violadas = []
        if m["divergencia"] > presupuesto:
            violadas.append(
                f"KL {m['divergencia']:.3f} > {presupuesto:.3f}")
        if m["caida_correccion"] > cfg["caida_maxima_correccion"]:
            violadas.append(
                f"caida de correccion {m['caida_correccion']:.3f} > "
                f"{cfg['caida_maxima_correccion']:.3f}")
        if m["tasa_degeneradas"] >= cfg["tasa_maxima_degeneradas"]:
            violadas.append(
                f"degeneradas {m['tasa_degeneradas']:.3f} >= "
                f"{cfg['tasa_maxima_degeneradas']:.3f}")

        if violadas and accion == "promover":
            pytest.fail(
                f"{carpeta} ronda {ronda}: quedo registrada como PROMOVER pero "
                f"con la configuracion actual el gate la habria rechazado por "
                f"{'; '.join(violadas)}. O cambio un umbral en configs/, o "
                f"cambio gate/gate.py.")


@pytest.mark.parametrize("carpeta", sorted(CORRIDAS))
def test_la_corrida_retuvo_donde_dice_la_bitacora(carpeta):
    """La retencion de la corrida A tiene que seguir explicandose por la KL."""
    if not _hay_datos(carpeta):
        pytest.skip(f"{carpeta} no esta en esta copia del repositorio")

    cfg = _cfg_gate()
    presupuesto = CORRIDAS[carpeta] or cfg["presupuesto_kl"]

    for ronda, accion, m in _decisiones(carpeta):
        if accion != "retener":
            continue
        assert (m["divergencia"] > presupuesto
                or m["caida_correccion"] > cfg["caida_maxima_correccion"]
                or m["tasa_degeneradas"] >= cfg["tasa_maxima_degeneradas"]), (
            f"{carpeta} ronda {ronda}: quedo registrada como RETENER pero "
            f"ninguna de las tres condiciones recalculables la explica. "
            f"La causa registrada fue del win-rate, que no se puede recalcular, "
            f"o cambio un umbral.")
