"""Pruebas del abanico de candidatos.

Lo que se verifica no es que el abanico "mejore" nada, sino las tres
propiedades de las que depende que el experimento siga siendo honesto:
el abanico no depende de la fase, produce margenes mas grandes que muestrear
dos veces el mismo prompt, y la curacion no tira los pares que ensenan el
cambio de formato.
"""

import random

from entrenamiento.datos import _se_distinguen
from entrenamiento.modelo_real import PERSONAS, SISTEMA_BASE
from simulador import oraculo as orc

CFG = {
    "sigma_ruido": 0.10,
    "tau": 0.77,
    "peso_correccion": 0.50,
    "normalizacion": {
        "longitud": {"mu": 95.0, "sigma": 30.0},
        "pasos": {"mu": 0.50, "sigma": 0.50},
        "cortesia": {"mu": 0.60, "sigma": 0.80},
        "cobertura": {"mu": 0.15, "sigma": 0.15},
    },
    "perfiles": {
        "didactico": {"longitud": 0.90, "pasos": 0.10, "cortesia": 0.50},
        "operativo": {"longitud": -0.90, "pasos": 1.00, "cortesia": -0.40},
    },
}

PROSA = (
    "Para recuperar la conexion conviene entender primero que el router "
    "mantiene dos redes separadas. La banda 2.4 llega mas lejos dentro de la "
    "casa aunque su velocidad maxima sea menor, y por eso suele ser la "
    "opcion razonable cuando el equipo esta en otra habitacion. La de 5 GHz "
    "rinde mucho mas cerca del router pero atraviesa peor las paredes. "
    "Con eso en mente, la primera medida util es reiniciar el equipo y "
    "observar en cual de las dos redes queda conectado el telefono, porque "
    "buena parte de las caidas de velocidad se explican simplemente por "
    "haber quedado enganchado a la banda equivocada durante el dia.")
PASOS = "1. Apaga el router.\n2. Espera treinta segundos.\n3. Vuelve a encenderlo."
BREVE = "Reinicia el router y espera un minuto. Si sigue igual, revisa el cable."


def _par(textos):
    return {"prompt": "p", "hechos_clave": ["banda 2.4", "reiniciar"],
            "candidatos": [{"id": f"c{i}", "texto": t} for i, t in enumerate(textos)]}


def test_las_personas_no_dependen_de_la_fase():
    # Si el conjunto de personas cambiara con la fase, el sistema estaria
    # leyendo la etiqueta que tiene que aprender a detectar.
    nombres = [n for n, _ in PERSONAS]
    assert len(set(nombres)) == len(nombres)
    texto = " ".join(i for _, i in PERSONAS).lower()
    for palabra in ("fase", "ronda", "didactico", "operativo", "perfil"):
        assert palabra not in texto
    assert "fase" not in SISTEMA_BASE.lower()


def test_el_abanico_da_mas_margen_que_dos_muestras_iguales():
    rng = random.Random(0)
    con_abanico = orc.anotar_abanico(_par([PROSA, PASOS, BREVE]), "operativo", CFG, rng)
    sin_abanico = orc.anotar_abanico(_par([PASOS, PASOS]), "operativo", CFG, rng)
    assert con_abanico["margen_utilidad"] > 3 * sin_abanico["margen_utilidad"]


def test_cada_perfil_elige_una_punta_distinta():
    rng = random.Random(1)
    textos = [PROSA, PASOS]
    didactico = orc.anotar_abanico(_par(textos), "didactico", CFG, rng)
    operativo = orc.anotar_abanico(_par(textos), "operativo", CFG, rng)
    assert didactico["chosen"] == PROSA
    assert operativo["chosen"] == PASOS


def test_la_curacion_conserva_los_pares_que_cambian_de_formato():
    # Mismo largo aproximado, formato opuesto: es el par que ensena la fase B.
    par = {"chosen": PASOS, "rejected": BREVE}
    assert _se_distinguen(par, minimo_tokens=15)


def test_la_curacion_descarta_los_pares_indistinguibles():
    par = {"chosen": BREVE, "rejected": BREVE.replace("minuto", "rato")}
    assert not _se_distinguen(par, minimo_tokens=15)


def test_el_contexto_mete_todos_los_hechos_y_no_depende_de_la_persona():
    from entrenamiento.modelo_real import _contexto
    consulta = {"texto": "no me anda el wifi",
                "hechos_clave": ["reiniciar", "firmware", "banda 2.4"]}
    ctx = _contexto(consulta)
    for hecho in consulta["hechos_clave"]:
        assert hecho in ctx
    # El contexto depende de la consulta, nunca de la persona ni de la fase:
    # los dos candidatos de un par lo reciben identico.
    assert "fase" not in ctx.lower()
    assert _contexto({"texto": "x", "hechos_clave": []}) == ""


def test_el_guardarrail_de_idioma_atrapa_el_colapso():
    from simulador.rasgos import es_degenerada, fraccion_fuera_de_idioma
    colapso = ("1. Reiniciar:\n   - Fazer uma nova reinicio do router\n"
               "2. Firmware update:\n   - Verifique a versao\n"
               "3. Bandeira: 2.4GHz e o mais comum")
    assert fraccion_fuera_de_idioma(colapso) > 0.08
    assert es_degenerada(colapso)


def test_el_guardarrail_no_marca_español_correcto():
    from simulador.rasgos import es_degenerada
    for bueno in (
        "1. Reinicia el router.\n2. Revisa el firmware.\n3. Conecta a la banda 2.4.",
        PROSA, PASOS, BREVE,
    ):
        assert not es_degenerada(bueno), bueno[:60]


def test_el_guardarrail_se_puede_apagar_y_volver_a_prender():
    # Es el interruptor que separa la corrida A de la corrida B. Si se quedara
    # apagado, la corrida B no probaria nada.
    from simulador import rasgos as rg
    colapso = ("1. Reiniciar:\n   - Fazer uma nova reinicio do router\n"
               "2. Firmware update:\n   - Verifique a versao\n"
               "3. Bandeira: 2.4GHz e o mais comum")
    try:
        rg.activar_guardarrail_idioma(False)
        assert not rg.guardarrail_idioma_activo()
        assert not rg.es_degenerada(colapso)
        rg.activar_guardarrail_idioma(True)
        assert rg.es_degenerada(colapso)
    finally:
        rg.activar_guardarrail_idioma(True)
