"""Las dos reglas que hacen que el experimento signifique algo:

  1. el sistema en linea no puede ver la fase ni el margen de utilidad
  2. las consultas de evaluacion no pueden entrar al entrenamiento

Estan verificadas en el codigo, no solo pedidas en el enunciado.
"""

import os
import tempfile

import pytest

from gate import evaluacion as ev
from simulador import consultas as bc
from store import db


@pytest.fixture()
def con():
    ruta = os.path.join(tempfile.mkdtemp(), "test.db")
    c = db.conectar(ruta)
    db.inicializar(c)
    yield c
    c.close()


def _par(i, ronda=1, consulta_id="q_00000"):
    return {"consulta_id": consulta_id, "prompt": "p", "chosen": "a", "rejected": "b",
            "policy_version": "base", "ronda": ronda, "corrida": "t",
            "fase_oraculo": "A", "perfil_anotador": "didactico", "segmento": None,
            "margen_utilidad": 1.23, "es_duplicado": 0, "par_id": f"p{i}"}


def test_la_lectura_en_linea_no_expone_la_fase(con):
    db.guardar_par(con, _par(1))
    con.commit()
    visto = db.leer_pares_para_el_sistema(con, "t")[0]
    for campo in db.CAMPOS_PROHIBIDOS_EN_LINEA:
        assert campo not in visto


def test_el_analisis_si_ve_la_fase(con):
    db.guardar_par(con, _par(1))
    con.commit()
    visto = db.leer_pares_para_analisis(con, "t")[0]
    assert visto["fase_oraculo"] == "A"
    assert visto["margen_utilidad"] == pytest.approx(1.23)


def test_los_duplicados_no_entran_al_entrenamiento(con):
    db.guardar_par(con, _par(1))
    duplicado = _par(2)
    duplicado["es_duplicado"] = 1
    db.guardar_par(con, duplicado)
    con.commit()
    assert len(db.leer_pares_para_el_sistema(con, "t")) == 1
    assert len(db.leer_pares_para_analisis(con, "t")) == 2


def test_la_fuga_del_conjunto_de_evaluacion_corta_el_pipeline():
    banco = bc.leer_banco()
    evaluacion = bc.por_split(banco, "evaluacion", 10)
    limpio = [{"consulta_id": c["consulta_id"]}
              for c in bc.por_split(banco, "recoleccion", 10)]
    assert ev.verificar_fuga(limpio, evaluacion)
    contaminado = limpio + [{"consulta_id": evaluacion[0]["consulta_id"]}]
    with pytest.raises(RuntimeError):
        ev.verificar_fuga(contaminado, evaluacion)


def test_los_splits_son_estables_entre_corridas():
    a = {c["consulta_id"]: c["split"] for c in bc.construir_banco()}
    b = {c["consulta_id"]: c["split"] for c in bc.construir_banco()}
    assert a == b
    assert set(a.values()) == {"canary", "evaluacion", "recoleccion"}
