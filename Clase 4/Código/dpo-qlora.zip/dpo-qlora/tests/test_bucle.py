"""Pruebas del bucle: detector, gate y una corrida corta de punta a punta."""

import os
import tempfile

import pytest

from drift import detectores as det
from gate import gate as gt
from orquestador import experimento as exp
from simulador import consultas as bc
from simulador import oraculo as orc


def test_page_hinkley_no_alarma_sobre_una_serie_estable():
    serie = [0.80, 0.81, 0.79, 0.80, 0.82, 0.78, 0.80, 0.81]
    assert det.primera_alarma(serie, delta=0.005, umbral=0.08) is None


def test_page_hinkley_detecta_un_cambio_abrupto():
    serie = [0.80] * 4 + [0.20] * 4
    alarma = det.primera_alarma(serie, delta=0.005, umbral=0.08)
    assert alarma is not None and 4 <= alarma <= 5


def test_la_curva_de_retardo_es_monotona_en_el_umbral():
    serie = [0.80] * 4 + [0.25] * 8
    filas = det.curva_retardo_falsas_alarmas(serie, [0.02, 0.10, 0.40, 1.50],
                                             ronda_del_cambio=4)
    retardos = [f["retardo"] for f in filas if f["retardo"] is not None]
    assert retardos == sorted(retardos)          # mas umbral, mas retardo


def test_el_gate_bloquea_cuando_no_hay_evidencia():
    cfg = {"win_rate_ic_inferior": 0.50, "caida_maxima_correccion": 0.02,
           "presupuesto_kl": 0.35, "tasa_maxima_degeneradas": 0.01}
    sin_evidencia = {"ic": (0.48, 0.58), "caida_correccion": 0.0,
                     "divergencia": 0.1, "tasa_degeneradas": 0.0}
    assert not gt.decidir(sin_evidencia, cfg)["aprueba"]

    con_evidencia = {**sin_evidencia, "ic": (0.55, 0.65)}
    assert gt.decidir(con_evidencia, cfg)["aprueba"]


def test_el_gate_bloquea_el_reward_hacking():
    cfg = {"win_rate_ic_inferior": 0.50, "caida_maxima_correccion": 0.02,
           "presupuesto_kl": 0.35, "tasa_maxima_degeneradas": 0.01}
    hackeado = {"ic": (0.70, 0.80), "caida_correccion": 0.09,
                "divergencia": 0.1, "tasa_degeneradas": 0.0, "p_mcnemar": 0.001}
    veredicto = gt.decidir(hackeado, cfg)
    assert not veredicto["aprueba"]
    assert any("correccion" in c for c in veredicto["causas"])


def test_el_rollback_se_dispara_cuando_la_version_promovida_pierde():
    cfg = {"win_rate_ic_inferior": 0.50, "caida_maxima_correccion": 0.02,
           "presupuesto_kl": 0.35, "tasa_maxima_degeneradas": 0.01}
    peor = {"ic": (0.30, 0.44), "caida_correccion": 0.0}
    revertir, motivo = gt.hay_que_revertir(peor, cfg)
    assert revertir and "pierde" in motivo

    degradada = {"ic": (0.52, 0.62), "caida_correccion": 0.08}
    revertir, motivo = gt.hay_que_revertir(degradada, cfg)
    assert revertir and "correccion" in motivo

    sana = {"ic": (0.52, 0.62), "caida_correccion": 0.0}
    assert not gt.hay_que_revertir(sana, cfg)[0]


@pytest.mark.slow
def test_corrida_corta_de_punta_a_punta():
    """Version reducida del experimento: seis rondas, poca muestra."""
    cfg_exp = exp.cargar_experimento()
    cfg_exp = {**cfg_exp, "rondas": 6}
    cfg_exp["recoleccion"] = {**cfg_exp["recoleccion"], "pares_por_ronda": 60,
                              "pares_duplicados": 30}
    cfg_exp["evaluacion"] = {**cfg_exp["evaluacion"], "n_consultas": 80,
                             "n_canary": 40, "replicas_bootstrap": 500}
    cfg_or = orc.cargar_config()
    banco = bc.leer_banco()
    ruta = os.path.join(tempfile.mkdtemp(), "bucle.db")

    bitacora = exp.correr("bucle", semilla=11, cfg_exp=cfg_exp, cfg_or=cfg_or,
                          banco=banco, ruta_db=ruta)

    assert len(bitacora) == 6
    assert all(0.0 <= f["win_rate_vs_congelada"] <= 1.0 for f in bitacora)
    # Tras el cambio abrupto de la ronda 5 el detector tiene que decir algo.
    assert any(f["alarma"] for f in bitacora if f["ronda"] >= 5)
    # Y el sistema tiene que haber tomado alguna decision registrada.
    assert {f["accion"] for f in bitacora} & {"promover", "retener", "revertir"}


@pytest.mark.slow
def test_dos_corridas_identicas_dan_el_mismo_resultado():
    """Reproducibilidad: misma semilla y misma configuracion, mismo resultado.

    Es lo que se corrige, no lo que se asume. Falla, por ejemplo, si los
    identificadores de los pares fueran aleatorios: el orden de lectura del
    lote cambiaria y con el, el entrenamiento.
    """
    cfg_exp = exp.cargar_experimento()
    cfg_exp = {**cfg_exp, "rondas": 4}
    cfg_exp["recoleccion"] = {**cfg_exp["recoleccion"], "pares_por_ronda": 50,
                              "pares_duplicados": 20}
    cfg_exp["evaluacion"] = {**cfg_exp["evaluacion"], "n_consultas": 60,
                             "n_canary": 30, "replicas_bootstrap": 300}
    cfg_or = orc.cargar_config()
    banco = bc.leer_banco()

    def corrida():
        ruta = os.path.join(tempfile.mkdtemp(), "r.db")
        return [(f["ronda"], f["accion"], round(f["win_rate_vs_congelada"], 6))
                for f in exp.correr("bucle", 11, cfg_exp, cfg_or, banco, ruta)]

    assert corrida() == corrida()
