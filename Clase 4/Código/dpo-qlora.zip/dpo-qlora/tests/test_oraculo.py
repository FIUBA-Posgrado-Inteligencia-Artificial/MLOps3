"""El oraculo es la ground truth: si esta mal, todo el experimento miente."""

import pytest

from serving.plantillas import generar_par, politica_inicial
from simulador import consultas as bc
from simulador import oraculo as orc


@pytest.fixture(scope="module")
def cfg():
    return orc.cargar_config()


@pytest.fixture(scope="module")
def banco():
    return bc.por_split(bc.leer_banco(), "recoleccion")


def test_el_peso_de_la_correccion_no_depende_de_la_fase(cfg):
    # Invariante duro del diseño: las fases solo mueven el estilo.
    for pesos in cfg["perfiles"].values():
        assert set(pesos) == {"longitud", "pasos", "cortesia"}


def test_config_invalida_si_un_perfil_toca_la_correccion(cfg):
    roto = {**cfg, "perfiles": {"x": {"longitud": 1.0, "cobertura": 0.5}}}
    with pytest.raises(ValueError):
        orc._verificar_invariantes(roto)


def test_los_perfiles_prefieren_cosas_distintas(cfg, banco):
    # Misma cobertura de hechos en las dos: lo unico que cambia es el estilo.
    largo = ("Gracias por escribir. Verifica lo relacionado con reiniciar antes "
             "de seguir. Verifica lo relacionado con firmware antes de seguir. "
             + " ".join(f"La red local puede fallar por el motivo numero {i}."
                        for i in range(12)))
    corto = ("1. Verifica lo relacionado con reiniciar antes de seguir.\n"
             "2. Verifica lo relacionado con firmware antes de seguir.")
    hechos = ["reiniciar", "firmware"]
    u_did_largo = orc.utilidad(largo, hechos, "didactico", cfg)
    u_did_corto = orc.utilidad(corto, hechos, "didactico", cfg)
    u_ope_largo = orc.utilidad(largo, hechos, "operativo", cfg)
    u_ope_corto = orc.utilidad(corto, hechos, "operativo", cfg)
    assert u_did_largo > u_did_corto
    assert u_ope_corto > u_ope_largo


def test_una_respuesta_degenerada_nunca_gana(cfg):
    buena = ("1. Verifica lo relacionado con reiniciar antes de seguir.\n"
             "2. Verifica lo relacionado con firmware antes de seguir.")
    vacia = "ok"
    for perfil in ("didactico", "operativo"):
        assert orc.utilidad(buena, ["reiniciar"], perfil, cfg) > \
               orc.utilidad(vacia, ["reiniciar"], perfil, cfg)


def test_el_acuerdo_entre_anotadores_cae_en_el_rango_pedido(cfg, banco):
    from simulador.calibrar_oraculo import acuerdo_con_tau
    acuerdo = acuerdo_con_tau(cfg["tau"], cfg, banco, n=300, semilla=3)
    assert 0.65 <= acuerdo <= 0.85, f"acuerdo fuera de rango: {acuerdo:.3f}"


def test_el_calendario_reproduce_las_tres_fases(cfg):
    fases = [cfg["calendario"][r]["fase"] for r in range(1, 13)]
    assert fases[:4] == ["A"] * 4
    assert fases[4:8] == ["B"] * 4
    assert fases[8:] == ["C"] * 4
    # El cambio A->B es abrupto y el B->C gradual.
    assert cfg["calendario"][4]["p_didactico"] == 1.0
    assert cfg["calendario"][5]["p_didactico"] == 0.0
    graduales = [cfg["calendario"][r]["p_didactico"] for r in (9, 10, 11)]
    assert graduales == sorted(graduales) and graduales[0] < graduales[-1]


def test_la_anotacion_es_reproducible(cfg, banco):
    consulta = banco[0]
    par = {"prompt": "", "hechos_clave": consulta["hechos_clave"],
           "candidatos": generar_par(consulta, politica_inicial(), 42)}
    a = orc.anotar(par, "didactico", cfg, orc.nuevo_rng(5))
    b = orc.anotar(par, "didactico", cfg, orc.nuevo_rng(5))
    assert a["id_elegido"] == b["id_elegido"]
