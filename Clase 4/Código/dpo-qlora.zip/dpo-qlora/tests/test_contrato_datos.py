"""El contrato de datos del preference store.

Cada prueba corresponde a una forma concreta de par inservible. La ultima es la
que importa: es el caso real de la ronda 5 de la corrida B.
"""
from store import validacion as val

BUENO = {"prompt": "el wifi no anda", "chosen": "1. Reinicia el router.\n2. Abre 192.168.1.1.",
         "rejected": "Probá reiniciar y contame."}


def test_un_par_normal_pasa():
    assert val.problemas_del_par(BUENO) == []


def test_se_rechaza_sin_prompt():
    assert val.problemas_del_par({**BUENO, "prompt": "  "})


def test_se_rechaza_la_elegida_vacia():
    assert val.problemas_del_par({**BUENO, "chosen": ""})


def test_se_rechazan_las_dos_iguales():
    fallas = val.problemas_del_par({**BUENO, "rejected": BUENO["chosen"]})
    assert any("identicas" in f for f in fallas)


def test_se_rechaza_el_colapso_de_idioma():
    """El caso real: la ronda 5 de la corrida B eligio esto y entro a entrenar."""
    chino = "El故障可能有几种原因，下面将逐一分析：\n\n1. 电缆问题：可能是你的路由器的电源线损坏。"
    fallas = val.problemas_del_par({**BUENO, "chosen": chino})
    assert any("alfabeto ajeno" in f for f in fallas), fallas


def test_filtrar_separa_y_no_pierde_pares():
    malo = {**BUENO, "chosen": "电缆问题：可能是你的路由器的电源线损坏"}
    validos, descartados = val.filtrar([BUENO, malo], avisar=False)
    assert len(validos) == 1 and len(descartados) == 1
    assert descartados[0]["fallas"]
