"""Figuras del informe. Ninguna curva de una sola semilla: todas con banda.

Uso:
    python -m analisis.figuras artefactos/bitacora.jsonl
"""

import collections
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
import numpy as np                       # noqa: E402

from drift import detectores as det      # noqa: E402

SALIDA = "artefactos/figuras"
CAMBIOS = [4.5, 8.5]                     # A->B abrupto, B->C gradual


def cambios_de_fase(filas):
    """Ubica los cambios de fase en los datos, para que la figura sirva igual
    con las doce rondas del modo simulado y con las ocho del modo real."""
    por_ronda = {}
    for f in filas:
        por_ronda.setdefault(f["ronda"], f["fase"])
    rondas = sorted(por_ronda)
    return [r - 0.5 for r in rondas[1:] if por_ronda[r] != por_ronda[r - 1]]


def leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def _por_control(filas, campo):
    agrupado = collections.defaultdict(lambda: collections.defaultdict(list))
    for f in filas:
        agrupado[f["control"]][f["ronda"]].append(f[campo])
    return agrupado


def curva_con_banda(filas, campo, titulo, etiqueta_y, nombre):
    agrupado = _por_control(filas, campo)
    plt.figure(figsize=(8, 4.5))
    for control, por_ronda in sorted(agrupado.items()):
        rondas = sorted(por_ronda)
        valores = [np.array(por_ronda[r], dtype=float) for r in rondas]
        medias = [v.mean() for v in valores]
        minimos = [v.min() for v in valores]
        maximos = [v.max() for v in valores]
        plt.plot(rondas, medias, marker="o", label=control)
        plt.fill_between(rondas, minimos, maximos, alpha=0.15)
    for x in (cambios_de_fase(filas) or CAMBIOS):
        plt.axvline(x, color="gray", linestyle="--", linewidth=1)
    plt.title(titulo)
    plt.xlabel("ronda")
    plt.ylabel(etiqueta_y)
    plt.legend(fontsize=8)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    ruta = os.path.join(SALIDA, nombre)
    plt.savefig(ruta, dpi=150)
    plt.close()
    return ruta


def curva_retardo(filas, umbrales=None, nombre="retardo_vs_falsas_alarmas.png"):
    umbrales = umbrales or [0.02, 0.04, 0.06, 0.08, 0.12, 0.18, 0.25]
    serie_por_semilla = collections.defaultdict(list)
    for f in sorted(filas, key=lambda f: f["ronda"]):
        if f["control"].startswith("bucle"):
            serie_por_semilla[f["semilla"]].append(f["pref_longitud"])

    plt.figure(figsize=(7, 4.5))
    resumen = collections.defaultdict(list)
    for semilla, serie in serie_por_semilla.items():
        for fila in det.curva_retardo_falsas_alarmas(serie, umbrales, ronda_del_cambio=4):
            resumen[fila["umbral"]].append(fila)

    xs, ys, textos = [], [], []
    for umbral, filas_u in sorted(resumen.items()):
        retardos = [f["retardo"] for f in filas_u if f["retardo"] is not None]
        falsas = [f["falsas_alarmas"] for f in filas_u]
        if not retardos:
            continue
        xs.append(np.mean(falsas))
        ys.append(np.mean(retardos))
        textos.append(f"{umbral}")
    plt.plot(xs, ys, marker="o")
    for x, y, t in zip(xs, ys, textos):
        plt.annotate(t, (x, y), textcoords="offset points", xytext=(6, 4), fontsize=8)
    plt.title("Page-Hinkley: retardo de deteccion contra falsas alarmas")
    plt.xlabel("falsas alarmas antes del cambio (promedio entre semillas)")
    plt.ylabel("retardo en rondas")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    ruta = os.path.join(SALIDA, nombre)
    plt.savefig(ruta, dpi=150)
    plt.close()
    return ruta


def tabla_controles(filas):
    """Resumen por control: win-rate final y retardo de adaptacion."""
    salida = []
    for control in sorted({f["control"] for f in filas}):
        del_control = [f for f in filas if f["control"] == control]
        # La ultima ronda se toma del propio brazo: el bucle real corre menos
        # rondas que el simulado.
        ultima = max(f["ronda"] for f in del_control)
        finales = [f["win_rate_vs_congelada"] for f in del_control if f["ronda"] == ultima]
        corr = [f["correccion"] for f in del_control if f["ronda"] == ultima]
        retardos = []
        for semilla in sorted({f["semilla"] for f in del_control}):
            serie = sorted([f for f in del_control if f["semilla"] == semilla],
                           key=lambda f: f["ronda"])
            r = next((f["ronda"] - 4 for f in serie
                      if f["ronda"] > 4 and f["win_rate_vs_congelada"] > 0.60), None)
            if r is not None:
                retardos.append(r)
        salida.append({
            "control": control,
            "win_rate_final": round(float(np.mean(finales)), 3) if finales else None,
            "correccion_final": round(float(np.mean(corr)), 3) if corr else None,
            "retardo_medio": round(float(np.mean(retardos)), 2) if retardos else None,
            "ultima_ronda": ultima,
            "promociones": sum(1 for f in del_control if f["accion"] == "promover"),
            "retenciones": sum(1 for f in del_control if f["accion"] == "retener"),
            "reversiones": sum(1 for f in del_control if f["accion"] == "revertir"),
        })
    return salida


def main(ruta="artefactos/bitacora.jsonl"):
    os.makedirs(SALIDA, exist_ok=True)
    filas = leer(ruta)
    rutas = [
        curva_con_banda(filas, "win_rate_vs_congelada",
                        "Win-rate contra la politica congelada",
                        "win-rate", "win_rate.png"),
        curva_con_banda(filas, "correccion",
                        "Correccion en el canary (antimetrica del reward hacking)",
                        "tasa de acierto", "correccion.png"),
        curva_con_banda(filas, "longitud_media",
                        "Longitud media de las respuestas",
                        "tokens", "longitud.png"),
        curva_con_banda(filas, "pref_longitud",
                        "Señal del detector: preferencia por la respuesta mas larga",
                        "fraccion", "señal_drift.png"),
        curva_retardo(filas),
    ]
    tabla = tabla_controles(filas)
    with open(os.path.join(SALIDA, "tabla_controles.json"), "w", encoding="utf-8") as f:
        json.dump(tabla, f, ensure_ascii=False, indent=2)

    print("figuras:")
    for r in rutas:
        print(" ", r)
    print("\nresumen por control:")
    for fila in tabla:
        print(" ", fila)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "artefactos/bitacora.jsonl")
