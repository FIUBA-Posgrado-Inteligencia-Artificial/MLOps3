"""Lee el TEXTO que produjo el modelo, ronda por ronda, sin GPU.

La bitacora guarda numeros; la base de preferencias guarda las respuestas
enteras. Este modulo abre esa base y muestra como cambio la escritura del
modelo a lo largo de la corrida: es la evidencia que ninguna metrica transmite.

Cada ronda se genero con la politica vigente en ese momento, asi que recorrer
las rondas en orden es recorrer la evolucion de la politica. Un adaptador que
colapso se ve en la ronda siguiente a la que lo promovio.

    python -m analisis.textos corrida-A-sin-guardarrail/preferencias.db
    python -m analisis.textos ... --ronda 4 --n 3
    python -m analisis.textos ... --resumen
"""

import argparse
import sqlite3

from simulador import rasgos as rg

ANCHO = 78


def abrir(ruta):
    con = sqlite3.connect(ruta)
    con.row_factory = sqlite3.Row
    return con


def rondas_disponibles(con):
    filas = con.execute(
        "SELECT corrida, ronda, COUNT(*) n FROM pares "
        "WHERE es_duplicado = 0 GROUP BY corrida, ronda ORDER BY corrida, ronda"
    ).fetchall()
    return [dict(f) for f in filas]


def pares_de(con, ronda, n, corrida=None):
    sql = ("SELECT * FROM pares WHERE ronda = ? AND es_duplicado = 0 "
           + ("AND corrida = ? " if corrida else "")
           + "ORDER BY par_id LIMIT ?")
    args = (ronda, corrida, n) if corrida else (ronda, n)
    return [dict(f) for f in con.execute(sql, args).fetchall()]


def _ficha(texto):
    r = rg.medir_rasgos(texto, [])
    return (f"[{int(r['longitud']):>3} tokens · "
            f"pasos: {'si' if r['pasos'] else 'no'} · "
            f"fuera de idioma {r['fuera_de_idioma']:.3f}"
            + ("  << COLAPSO" if r["fuera_de_idioma"] > rg.UMBRAL_FUERA_DE_IDIOMA else "")
            + "]")


def mostrar(con, ronda, n, corrida=None):
    pares = pares_de(con, ronda, n, corrida)
    if not pares:
        print(f"  (sin pares en la ronda {ronda})")
        return
    print("\n" + "=" * ANCHO)
    print(f"RONDA {ronda}  ·  fase {pares[0]['fase_oraculo']}  ·  "
          f"politica {pares[0]['policy_version']}")
    print("=" * ANCHO)
    for i, p in enumerate(pares, 1):
        print(f"\n--- par {i} · anotador {p['perfil_anotador']} "
              f"· margen de utilidad {p['margen_utilidad']:.2f} " + "-" * 12)
        for etiqueta, texto in (("ELEGIDA   ", p["chosen"]), ("DESCARTADA", p["rejected"])):
            print(f"\n  [{etiqueta}] {_ficha(texto)}")
            for linea in rg.recortar_a_oracion_completa(texto).splitlines():
                print("    " + linea[:ANCHO - 6])


def resumen(con, corrida=None):
    """Una linea por ronda: como se movio la escritura del modelo.

    Es la vista que conviene proyectar: no hace falta leer las respuestas para
    ver que el formato cambio y, en su caso, que el idioma se fue.
    """
    print(f"\n{'ronda':>6} {'fase':>5} {'pares':>6} {'tokens':>8} "
          f"{'con pasos':>10} {'fuera idioma':>13} {'colapsadas':>11}")
    print("-" * ANCHO)
    for info in rondas_disponibles(con):
        if corrida and info["corrida"] != corrida:
            continue
        pares = pares_de(con, info["ronda"], 10 ** 6, info["corrida"])
        medidas = [rg.medir_rasgos(p["chosen"], []) for p in pares]
        n = len(medidas)
        largo = sum(m["longitud"] for m in medidas) / n
        pasos = sum(m["pasos"] for m in medidas) / n
        fuera = sum(m["fuera_de_idioma"] for m in medidas) / n
        colapso = sum(1 for m in medidas
                      if m["fuera_de_idioma"] > rg.UMBRAL_FUERA_DE_IDIOMA) / n
        print(f"{info['ronda']:>6} {pares[0]['fase_oraculo']:>5} {n:>6} "
              f"{largo:>8.1f} {pasos:>9.0%} {fuera:>13.3f} {colapso:>10.0%}")
    print("\nSolo se miden las respuestas ELEGIDAS: son las que el modelo aprende a imitar.")
    print("'colapsadas' es la fraccion que el guardarrail de idioma marcaria.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", help="ruta a preferencias.db")
    ap.add_argument("--ronda", type=int, default=None,
                    help="una ronda; sin esto, muestra un par de cada ronda")
    ap.add_argument("--n", type=int, default=1, help="pares por ronda")
    ap.add_argument("--corrida", default=None)
    ap.add_argument("--resumen", action="store_true",
                    help="solo la tabla de como se movio la escritura")
    args = ap.parse_args()

    con = abrir(args.base)
    disponibles = rondas_disponibles(con)
    if not disponibles:
        raise SystemExit("la base no tiene pares")
    print(f"corridas en la base: {sorted({d['corrida'] for d in disponibles})}")

    resumen(con, args.corrida)
    if args.resumen:
        return
    if args.ronda:
        mostrar(con, args.ronda, args.n, args.corrida)
    else:
        for info in disponibles:
            if args.corrida and info["corrida"] != args.corrida:
                continue
            mostrar(con, info["ronda"], args.n, info["corrida"])


if __name__ == "__main__":
    main()
