"""Muestra el texto que produjo cada adaptador, sin cargar el modelo.

Las respuestas de cada ronda ya estan en la base: las genero la politica que
estaba sirviendo en esa ronda. Leerlas de ahi no cuesta nada y no necesita GPU
ni descargar los pesos.

    python -m analisis.ver_salidas --db corrida-B-con-guardarrail/preferencias.db
    python -m analisis.ver_salidas --db corrida-A-sin-guardarrail/preferencias.db --ronda 5 --n 3
    python -m analisis.ver_salidas --db corrida-A-sin-guardarrail/preferencias.db --peor-idioma

SALVEDAD, y conviene decirla en clase: estos textos se generaron con las
instrucciones de estilo del abanico, no con el prompt neutro. Ademas, `chosen`
es el que eligio el oraculo de esa ronda, asi que mezcla lo que escribe el
adaptador con lo que el anotador prefirio. La tabla de promedios usa los dos
lados del par para compensar en parte.

Para ver un adaptador con el prompt neutro hay que generar de nuevo:
analisis.comparar_texto lo hace, a cambio de descargar el modelo una vez.
"""

import argparse
import sqlite3

from simulador import rasgos as rg

ANCHO = 78


def _resumen(texto):
    r = rg.medir_rasgos(texto, [])
    return (f"[{int(r['longitud']):>3} palabras · "
            f"pasos: {'si' if r['pasos'] else 'no'} · "
            f"cortesia: {int(r['cortesia'])} · "
            f"fuera de idioma: {r['fuera_de_idioma']:.3f}"
            f"{' · DEGENERADA' if r['degenerada'] else ''}]")


def _politicas_por_ronda(con):
    """Que adaptador genero los pares de cada ronda, leido de la base."""
    filas = con.execute(
        "SELECT ronda, policy_version FROM pares "
        "WHERE es_duplicado = 0 GROUP BY ronda, policy_version ORDER BY ronda"
    ).fetchall()
    return {f["ronda"]: f["policy_version"] for f in filas}


def _promedios(textos):
    medidas = [rg.medir_rasgos(t, []) for t in textos]
    n = len(medidas)
    return {k: sum(m[k] for m in medidas) / n for k in
            ("longitud", "pasos", "cortesia", "fuera_de_idioma", "degenerada")}


def mostrar(ruta_db, ronda=None, n=2, peor_idioma=False):
    con = sqlite3.connect(ruta_db)
    con.row_factory = sqlite3.Row
    politicas = _politicas_por_ronda(con)
    rondas = [ronda] if ronda else sorted(politicas)

    print("\n" + "=" * ANCHO)
    print(ruta_db)
    print("=" * ANCHO)
    print("\n ronda  genero        largo  %pasos  cortesia  fuera_idioma  %degen")
    for r in sorted(politicas):
        filas = con.execute(
            "SELECT chosen, rejected FROM pares WHERE ronda = ? AND es_duplicado = 0",
            (r,)).fetchall()
        # Los dos lados del par: es lo mas cerca que se puede estar de "que
        # escribe el adaptador" sin volver a generar.
        p = _promedios([f["chosen"] for f in filas] + [f["rejected"] for f in filas])
        print(f"   {r}    {politicas[r]:<12} {p['longitud']:6.1f}  "
              f"{p['pasos'] * 100:5.0f}%  {p['cortesia']:7.2f}   "
              f"{p['fuera_de_idioma']:9.3f}   {p['degenerada'] * 100:4.0f}%")

    for r in rondas:
        filas = con.execute(
            "SELECT chosen, rejected FROM pares WHERE ronda = ? AND es_duplicado = 0",
            (r,)).fetchall()
        textos = [f["chosen"] for f in filas]
        if peor_idioma:
            textos.sort(key=rg.fraccion_fuera_de_idioma, reverse=True)
        print("\n" + "=" * ANCHO)
        print(f"RONDA {r} · genero {politicas[r]}"
              f"{'  (ordenado por contaminacion de idioma)' if peor_idioma else ''}")
        print("=" * ANCHO)
        for texto in textos[:n]:
            print()
            print(rg.recortar_a_oracion_completa(texto))
            print(_resumen(texto))
    print()
    con.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/preferencias.db")
    ap.add_argument("--ronda", type=int, default=None,
                    help="una sola ronda; sin esto muestra todas")
    ap.add_argument("--n", type=int, default=2, help="ejemplos por ronda")
    ap.add_argument("--peor-idioma", action="store_true",
                    help="ordena por fraccion fuera de idioma, de mayor a menor")
    args = ap.parse_args()
    mostrar(args.db, ronda=args.ronda, n=args.n, peor_idioma=args.peor_idioma)


if __name__ == "__main__":
    main()
