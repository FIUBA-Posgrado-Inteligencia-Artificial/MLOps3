"""Cuanto costo la corrida, y cuanto ahorro no entrenar.

    python -m analisis.costos corrida-A-sin-guardarrail corrida-B-con-guardarrail
    python -m analisis.costos corrida-*/ --precio 0.35

La bitacora ya registra los minutos de cada ronda. Traducirlos a dinero es la
primera pregunta de cualquiera que pague la factura, y es la unica metrica del
proyecto que no es tecnica.

El precio por defecto es el de una T4 bajo demanda en la nube. Con Colab
gratuito el costo monetario es cero y lo que se mide es el tiempo, que tambien
es un recurso: una sesion de Colab se corta sola.
"""
import argparse
import json
import os

PRECIO_T4_HORA = 0.35          # dolares, T4 bajo demanda, orden de magnitud


def leer(carpeta):
    ruta = os.path.join(carpeta, "bitacora.jsonl")
    if not os.path.exists(ruta):
        return None
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def informe(carpeta, precio):
    filas = leer(carpeta)
    if not filas:
        print(f"{carpeta}: no hay bitacora")
        return None

    print("=" * 78)
    print(carpeta)
    print("=" * 78)
    print(" ronda  accion       minutos      costo   entreno")
    print("-" * 78)

    total = entrenadas = ahorradas = 0.0
    n_entreno = n_sin = 0
    for f in filas:
        minutos = f.get("minutos", 0.0)
        # Una ronda sin alarma no entrena: solo genera y evalua.
        entreno = f.get("accion") in ("promover", "retener") and not f.get("medicion_reusada", False)
        entreno = entreno or f.get("alarma") == 1 and f.get("accion") != "sin_accion"
        total += minutos
        if entreno:
            entrenadas += minutos
            n_entreno += 1
        else:
            ahorradas += minutos
            n_sin += 1
        print(f"   {f['ronda']}    {f.get('accion','-'):11s} {minutos:7.1f}    "
              f"{minutos / 60 * precio:7.3f}    {'si' if entreno else 'no'}")

    print("-" * 78)
    print(f"  total                {total:7.1f} min   {total / 60 * precio:7.3f} USD")
    if n_entreno:
        print(f"  rondas que entrenaron  {n_entreno}  ·  {entrenadas / n_entreno:.1f} min de media")
    if n_sin:
        media_sin = ahorradas / n_sin
        media_con = entrenadas / n_entreno if n_entreno else 0
        print(f"  rondas que no          {n_sin}  ·  {media_sin:.1f} min de media")
        if media_con:
            print(f"  la ronda sin alarma cuesta {media_sin / media_con:.0%} de lo que cuesta una con alarma")
    return {"minutos": total, "usd": total / 60 * precio}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rutas", nargs="+")
    ap.add_argument("--precio", type=float, default=PRECIO_T4_HORA,
                    help=f"dolares por hora de GPU (defecto {PRECIO_T4_HORA})")
    args = ap.parse_args()

    acumulado = 0.0
    minutos = 0.0
    for ruta in args.rutas:
        r = informe(ruta.rstrip("/"), args.precio)
        if r:
            acumulado += r["usd"]
            minutos += r["minutos"]
        print()

    if len(args.rutas) > 1:
        print("=" * 78)
        print(f"  EL EXPERIMENTO COMPLETO: {minutos:.0f} minutos de GPU  ·  "
              f"{acumulado:.2f} USD a {args.precio} por hora")
        print(f"  Y el replay de todo eso en tu maquina: dos bitacoras de 2 KB, "
              f"un segundo, costo cero.")


if __name__ == "__main__":
    main()
