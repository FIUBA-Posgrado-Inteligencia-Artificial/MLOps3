"""Carga una corrida ya hecha en MLflow, a partir de su bitacora.

Existe por una razon honesta: las corridas reales se hicieron en Colab, donde
no habia un servidor de MLflow levantado, asi que `orquestador/seguimiento.py`
cayo al respaldo local en JSONL. En los logs se ve:

    [dpo_job] seguimiento: sin integracion (registro propio)

La bitacora tiene exactamente la misma informacion, asi que se puede cargar
despues. Esto NO es lo mismo que haber registrado en linea —no hay artefactos
subidos, ni tiempos de sistema— pero deja el tablero que el ejercicio promete:
una corrida por ronda, con sus parametros, sus metricas y el veredicto del
gate, navegable en la interfaz.

    docker compose up -d mlflow          # o: mlflow server --port 5000
    python -m analisis.a_mlflow corrida-A-sin-guardarrail/bitacora.jsonl \\
        --experimento "dpo-continuo/corrida-A"

Y despues, en el navegador: http://localhost:5000
"""

import argparse
import json
import os
import sqlite3

PARAMETROS = ("corrida", "control", "semilla", "ronda", "fase", "version",
              "detector", "p_didactico")
METRICAS = ("pref_longitud", "pref_pasos", "psi", "page_hinkley",
            "win_rate_vs_congelada", "ic_inf", "ic_sup", "correccion",
            "longitud_media", "acuerdo_anotadores", "minutos", "alarma")


def leer_bitacora(ruta):
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def leer_hashes(ruta_db):
    """El hash del lote vive en la tabla de decisiones, no en la bitacora.

    Sin el hash, un adaptador no es promocionable: es lo que permite
    reconstruir, meses despues, con que pares exactos se entreno cada version.
    Por eso se lo busca aunque cueste abrir otra fuente.
    """
    if not ruta_db or not os.path.exists(ruta_db):
        return {}
    con = sqlite3.connect(ruta_db)
    con.row_factory = sqlite3.Row
    try:
        filas = con.execute(
            "SELECT corrida, ronda, hash_lote, metricas_json FROM decisiones"
        ).fetchall()
    except sqlite3.Error:
        return {}
    finally:
        con.close()
    return {(f["corrida"], f["ronda"]): dict(f) for f in filas}


def cargar(filas, experimento, hashes, uri):
    import mlflow

    mlflow.set_tracking_uri(uri)
    mlflow.set_experiment(experimento)
    cargadas = 0

    for f in sorted(filas, key=lambda x: (x["corrida"], x["ronda"])):
        clave = (f["corrida"], f["ronda"])
        extra = hashes.get(clave, {})
        nombre = f"{f['corrida']}-r{f['ronda']:02d}"

        with mlflow.start_run(run_name=nombre):
            params = {k: f[k] for k in PARAMETROS if f.get(k) is not None}
            if extra.get("hash_lote"):
                params["hash_lote"] = extra["hash_lote"]
            mlflow.log_params(params)

            metricas = {k: float(f[k]) for k in METRICAS
                        if isinstance(f.get(k), (int, float))}
            if extra.get("metricas_json"):
                try:
                    for k, v in json.loads(extra["metricas_json"]).items():
                        if isinstance(v, (int, float)):
                            metricas.setdefault(k, float(v))
                except (ValueError, TypeError):
                    pass
            mlflow.log_metrics(metricas)

            # Las etiquetas son lo que despues se filtra en la interfaz: buscar
            # "accion = revertir" y encontrar la ronda exacta es el caso de uso.
            mlflow.set_tags({
                "accion": f.get("accion") or "sin_accion",
                "aprueba": str(f.get("accion") == "promover"),
                "causa": (f.get("causa") or "")[:480],
                "fase": f.get("fase") or "",
                "alarma": str(bool(f.get("alarma"))),
            })
            cargadas += 1

    return cargadas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bitacora")
    ap.add_argument("--base", default=None,
                    help="preferencias.db de la misma corrida, para el hash del lote")
    ap.add_argument("--experimento", default="dpo-continuo/real")
    ap.add_argument("--uri", default=os.environ.get("MLFLOW_TRACKING_URI",
                                                    "http://localhost:5000"))
    args = ap.parse_args()

    base = args.base
    if base is None:
        candidato = os.path.join(os.path.dirname(args.bitacora), "preferencias.db")
        base = candidato if os.path.exists(candidato) else None

    filas = leer_bitacora(args.bitacora)
    hashes = leer_hashes(base)
    print(f"bitacora: {len(filas)} rondas · hashes de lote: {len(hashes)}")

    n = cargar(filas, args.experimento, hashes, args.uri)
    print(f"cargadas {n} corridas en el experimento '{args.experimento}'")
    print(f"abri {args.uri} y filtra por tags.accion")


if __name__ == "__main__":
    main()
