"""Dice que corrida es un archivo, mirando lo que tiene adentro.

Existe porque los nombres de archivo se pierden, se duplican y se confunden, y
las fechas de Drive mienten. El contenido no: cada corrida deja huellas que no
se pueden falsificar sin querer.

    python -m analisis.identificar corrida-A-sin-guardarrail
    python -m analisis.identificar ~/Downloads/bitacora.jsonl
    python -m analisis.identificar ~/Downloads/*.jsonl

Acepta una bitacora .jsonl, una base .db, una carpeta o un bundle .zip.
"""

import argparse
import glob
import json
import os
import sqlite3
import tempfile
import zipfile

SIN = "CORRIDA A · SIN guardarrail de idioma"
CON = "CORRIDA B · CON guardarrail de idioma"


def _leer_jsonl(ruta):
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def desde_bitacora(ruta):
    """Cuatro huellas independientes. Con que dos coincidan alcanza."""
    filas = _leer_jsonl(ruta)
    acciones = [f.get("accion") for f in filas]
    causas = " ".join(str(f.get("causa") or "") for f in filas)
    minutos = sum(f.get("minutos", 0) or 0 for f in filas)
    senal1 = next((f["pref_longitud"] for f in filas if f["ronda"] == 1), None)

    pistas, votos_a, votos_b = [], 0, 0

    if "revertir" in acciones:
        pistas.append("tiene una REVERSION")
        votos_b += 1
    else:
        pistas.append("no tiene reversiones")
        votos_a += 1

    if "> 0.600" in causas:
        pistas.append("el gate rechazo con presupuesto de KL 0.600")
        votos_a += 2
    elif "> 0.350" in causas:
        pistas.append("el gate rechazo con presupuesto de KL 0.350")
        votos_b += 2

    if senal1 is not None:
        pistas.append(f"senal de la ronda 1: {senal1:.3f}")
        if senal1 > 0.85:
            votos_b += 1
        elif senal1 < 0.80:
            votos_a += 1

    pistas.append(f"{len(filas)} rondas · {minutos:.0f} min de GPU")
    veredicto = SIN if votos_a > votos_b else (CON if votos_b > votos_a else "NO CONCLUYENTE")
    resumen = " · ".join(f"{a}={acciones.count(a)}" for a in sorted(set(acciones)))
    pistas.append(f"acciones: {resumen}")
    return veredicto, pistas


def desde_base(ruta):
    """La huella aca es el idioma del texto en las ultimas rondas."""
    from simulador import rasgos as rg
    con = sqlite3.connect(ruta)
    con.row_factory = sqlite3.Row
    ultima = con.execute("SELECT MAX(ronda) r FROM pares").fetchone()["r"]
    if ultima is None:
        return "NO CONCLUYENTE", ["la base no tiene pares"]
    filas = con.execute(
        "SELECT chosen FROM pares WHERE ronda >= ? AND es_duplicado = 0 LIMIT 400",
        (max(1, ultima - 1),)).fetchall()
    fuera = [rg.fraccion_fuera_de_idioma(f["chosen"]) for f in filas]
    colapso = sum(1 for v in fuera if v > rg.UMBRAL_FUERA_DE_IDIOMA) / max(1, len(fuera))
    pistas = [f"{len(filas)} respuestas de las ultimas 2 rondas",
              f"fraccion fuera de idioma media: {sum(fuera) / max(1, len(fuera)):.3f}",
              f"respuestas colapsadas: {colapso:.0%}"]
    if colapso > 0.25:
        return SIN, pistas + ["el texto se fue del espanol: solo pasa sin guardarrail"]
    return CON, pistas + ["el texto se mantuvo en espanol"]


def identificar(ruta):
    if os.path.isdir(ruta):
        for nombre in ("bitacora.jsonl", "preferencias.db"):
            candidato = os.path.join(ruta, nombre)
            if os.path.exists(candidato):
                return identificar(candidato)
        return "NO CONCLUYENTE", ["la carpeta no tiene bitacora.jsonl ni preferencias.db"]

    if ruta.endswith(".zip"):
        with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(ruta) as z:
            nombres = z.namelist()
            for nombre in ("bitacora.jsonl", "preferencias.db"):
                if nombre in nombres:
                    z.extract(nombre, tmp)
                    return identificar(os.path.join(tmp, nombre))
        return "NO CONCLUYENTE", ["el zip no trae bitacora ni base"]

    if ruta.endswith(".jsonl"):
        return desde_bitacora(ruta)
    if ruta.endswith(".db"):
        return desde_base(ruta)
    return "NO CONCLUYENTE", ["no reconozco la extension"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rutas", nargs="+")
    args = ap.parse_args()

    expandidas = []
    for r in args.rutas:
        expandidas.extend(sorted(glob.glob(os.path.expanduser(r))) or [r])

    for ruta in expandidas:
        print("\n" + "=" * 74)
        print(os.path.abspath(ruta))
        print("=" * 74)
        try:
            veredicto, pistas = identificar(ruta)
        except Exception as e:
            print(f"  no se pudo leer: {e}")
            continue
        print(f"  >>> {veredicto}")
        for p in pistas:
            print(f"      · {p}")
    print()


if __name__ == "__main__":
    main()
