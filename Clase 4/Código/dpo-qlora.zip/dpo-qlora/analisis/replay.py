"""Reproduce una corrida ronda por ronda a partir de su bitacora.

Para la clase: el bucle con modelo real corre horas en una GPU, pero la
bitacora que deja se reproduce en segundos en cualquier maquina. Lo que se ve
en pantalla es el mismo recorrido, con los numeros que salieron del modelo de
verdad.

Es reproduccion de un registro, no un recalculo. Conviene decirlo en voz alta.

Uso:
    python -m analisis.replay artefactos/bitacora.jsonl
    python -m analisis.replay bundle/bitacora.jsonl --pausa 1.2
    python -m analisis.replay bundle/bitacora.jsonl --control bucle-real
"""

import argparse
import json
import sys
import time


def leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def encabezado(filas):
    corridas = sorted({f["corrida"] for f in filas})
    rondas = max(f["ronda"] for f in filas)
    minutos = sum(f.get("minutos", 0) or 0 for f in filas)
    linea = f"corrida: {', '.join(corridas)} · {rondas} rondas"
    if minutos:
        linea += f" · {minutos:.0f} min de computo en GPU"
    return linea


def reproducir(filas, pausa=0.0, detalle=True):
    print(encabezado(filas))
    print("-" * 78)
    for f in sorted(filas, key=lambda f: (f["corrida"], f["ronda"])):
        marca = "ALARMA" if f["alarma"] else "      "
        print(f"ronda {f['ronda']:2d}  fase {f['fase']}  {marca}  "
              f"{f['accion']:10s}  wr={f['win_rate_vs_congelada']:.3f}  "
              f"corr={f['correccion']:.3f}  señal={f['pref_longitud']:.3f}")
        if detalle and f.get("causa"):
            print(f"          └─ {f['causa']}")
        if pausa:
            time.sleep(pausa)
    print("-" * 78)
    resumen(filas)


def resumen(filas):
    acciones = {}
    for f in filas:
        acciones[f["accion"]] = acciones.get(f["accion"], 0) + 1
    primera = min(filas, key=lambda f: f["ronda"])
    ultima = max(filas, key=lambda f: f["ronda"])
    print(f"win-rate: {primera['win_rate_vs_congelada']:.3f} -> "
          f"{ultima['win_rate_vs_congelada']:.3f}   "
          f"correccion: {primera['correccion']:.3f} -> {ultima['correccion']:.3f}")
    print("acciones: " + " · ".join(f"{k}={v}" for k, v in sorted(acciones.items())))

    cambios = []
    orden = sorted(filas, key=lambda f: f["ronda"])
    for anterior, actual in zip(orden, orden[1:]):
        if actual["fase"] != anterior["fase"]:
            cambios.append(actual["ronda"])
    for ronda_cambio in cambios:
        alarma = next((f["ronda"] for f in orden
                       if f["ronda"] >= ronda_cambio and f["alarma"]), None)
        if alarma is None:
            print(f"cambio de fase en la ronda {ronda_cambio}: sin alarma posterior")
        else:
            print(f"cambio de fase en la ronda {ronda_cambio}: "
                  f"alarma en la {alarma} (retardo {alarma - ronda_cambio})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bitacora", nargs="?", default="artefactos/bitacora.jsonl")
    ap.add_argument("--pausa", type=float, default=0.0,
                    help="segundos entre rondas, para narrar en vivo")
    ap.add_argument("--control", default=None,
                    help="reproduce un solo brazo")
    args = ap.parse_args()

    filas = leer(args.bitacora)
    if args.control:
        filas = [f for f in filas if f["control"] == args.control]
    if not filas:
        print("no hay filas para reproducir", file=sys.stderr)
        raise SystemExit(1)
    reproducir(filas, pausa=args.pausa)


if __name__ == "__main__":
    main()
