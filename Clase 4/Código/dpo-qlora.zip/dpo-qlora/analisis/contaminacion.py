"""Cuenta los pares donde la respuesta ELEGIDA se fue del alfabeto latino.

    python -m analisis.contaminacion corrida-A-sin-guardarrail corrida-B-con-guardarrail
    python -m analisis.contaminacion corrida-B-con-guardarrail --ejemplo 5

Existe por un hallazgo concreto y vale la pena leer por que.

En la ronda 5 de la corrida B el oraculo eligio una respuesta entera en chino,
con margen de utilidad 5.50, el mas alto de su lote. La cadena es esta:

  1. contar_tokens es len(texto.split()), y el chino no lleva espacios: un
     parrafo entero cuenta como ~11 tokens.
  2. En fase B el oraculo premia respuestas cortas (longitud -0.90) y con pasos
     numerados (pasos 1.30). El texto conserva los digitos "1." "2." "3.", asi
     que puntua como corto Y con pasos: el maximo posible.
  3. Queda como chosen.
  4. _se_distinguen, en entrenamiento/datos.py, mide la diferencia de longitud
     con el MISMO .split(). El par parece de contraste ejemplar y pasa.
  5. Entra al entrenamiento de DPO como lo que hay que imitar.
  6. es_degenerada SI lo detecta (fraccion fuera de idioma 1.000), pero se usa
     como una caracteristica mas en medir_rasgos, nunca como filtro. Termina en
     tasa_maxima_degeneradas del gate, da 2-3% contra un umbral de 0.15, y el
     gate aprueba.

El guardarrail lo vio, le puso un 1.000 y no cambio nada, porque mide en la
salida y la contaminacion entro por los datos. Y las dos defensas que debian
atajarlo, el oraculo y la curacion por margen, fallan por el mismo .split().
"""
import argparse
import os
import re
import sqlite3

from store.validacion import UMBRAL_CARACTERES_AJENOS as UMBRAL_CARACTERES
from store.validacion import caracteres_ajenos

PATRON_PASOS = re.compile(r"(?m)^\s*\d+[\.\)]")


def tiene_pasos(texto):
    return len(PATRON_PASOS.findall(texto)) >= 2


def entra_al_entrenamiento(chosen, rejected, minimo_tokens=15):
    """Replica _se_distinguen de entrenamiento/datos.py, con su mismo .split()."""
    largo = abs(len(chosen.split()) - len(rejected.split())) >= minimo_tokens
    formato = tiene_pasos(chosen) != tiene_pasos(rejected)
    return largo or formato


def revisar(ruta, ejemplos=0):
    base = os.path.join(ruta, "preferencias.db")
    if not os.path.exists(base):
        print(f"{ruta}: no hay preferencias.db")
        return

    con = sqlite3.connect(base)
    print("=" * 78)
    print(ruta)
    print("=" * 78)
    print(" ronda  fase  pares  elegidas ajenas  entran a entrenar  margen medio")
    print("-" * 78)

    total_pares = total_conta = total_entran = 0
    muestras = []

    for ronda in range(1, 100):
        filas = con.execute(
            "select fase_oraculo, chosen, rejected, margen_utilidad, par_id "
            "from pares where ronda = ? order by par_id", (ronda,)).fetchall()
        if not filas:
            if ronda > 12:
                break
            continue

        fase = filas[0][0]
        conta = [f for f in filas if caracteres_ajenos(f[1]) > UMBRAL_CARACTERES]
        entran = [f for f in conta if entra_al_entrenamiento(f[1], f[2])]
        margen = sum(f[3] for f in conta) / len(conta) if conta else None
        muestras.extend(sorted(conta, key=lambda f: -f[3])[:2])

        total_pares += len(filas)
        total_conta += len(conta)
        total_entran += len(entran)

        texto_margen = f"{margen:12.2f}" if margen is not None else f"{'-':>12}"
        print(f"  {ronda:3d}    {fase}   {len(filas):5d}  {len(conta):15d}"
              f"  {len(entran):17d}  {texto_margen}")

    print("-" * 78)
    pct = 100 * total_conta / total_pares if total_pares else 0
    print(f"  {total_conta} de {total_pares} elegidas ({pct:.1f}%) se fueron del alfabeto latino")
    print(f"  {total_entran} de esas {total_conta} pasaron la curacion y entraron al entrenamiento")
    if total_conta:
        print("  El guardarrail de idioma las marca y no las filtra: mide en la salida,")
        print("  no en la construccion de pares.")

    for fila in sorted(muestras, key=lambda f: -f[3])[:ejemplos]:
        _, chosen, rejected, margen, par_id = fila
        print()
        print(f"  --- {par_id} · margen {margen:.2f} ·"
              f" chosen {len(chosen.split())} 'tokens' / rejected {len(rejected.split())}")
        print(f"      ELEGIDA   : {chosen[:150].strip()}")
        print(f"      DESCARTADA: {rejected[:150].strip()}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rutas", nargs="+")
    ap.add_argument("--ejemplo", type=int, default=0,
                    help="cuantos pares contaminados mostrar, de mayor margen a menor")
    args = ap.parse_args()
    for ruta in args.rutas:
        revisar(ruta.rstrip("/"), args.ejemplo)
        print()


if __name__ == "__main__":
    main()
