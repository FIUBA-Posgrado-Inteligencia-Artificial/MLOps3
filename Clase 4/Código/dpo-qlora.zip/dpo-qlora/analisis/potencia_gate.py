"""Que tiene que lograr el adaptador para que el gate lo apruebe.

Responde, antes de gastar una hora de GPU, la pregunta que importa: dado el
oraculo, el tamaño del conjunto de evaluacion y el umbral del gate, ¿que
desplazamiento de estilo hace falta para que el candidato pase?

No simula el modelo. Simula el ESCENARIO: supone que el adaptador consigue
cambiar el formato en una fraccion f de las respuestas y acortarlas en d
tokens, y calcula la probabilidad de que el gate apruebe. Es analisis de
potencia, y es lo que tendria que estar hecho antes de correr, no despues.

    python -m analisis.potencia_gate --config-oraculo configs/oraculo_real_corto.yaml
"""

import argparse

import numpy as np

from gate import estadistica as est
from simulador import oraculo as orc

# Fracciones de respuestas en las que el adaptador logra imponer el formato
# preferido, y cuanto acorta (o alarga) la respuesta en tokens.
FRACCIONES = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0)


def win_rate_teorico(cfg, perfil, fraccion, delta_tokens):
    """Win-rate esperado del candidato contra la produccion, segun el oraculo.

    El candidato difiere de la produccion en dos cosas: en una fraccion de las
    consultas adopta el formato que ESTE perfil prefiere (poner pasos numerados
    si el perfil los quiere, sacarlos si no), y en todas mueve la longitud en
    `delta_tokens`. Todo lo demas queda igual, asi que la diferencia de utilidad
    es la suma de esos dos terminos.
    """
    pesos = cfg["perfiles"][perfil]
    norm = cfg["normalizacion"]
    du_formato = abs(pesos["pasos"]) * (1.0 / norm["pasos"]["sigma"])
    du_largo = pesos["longitud"] * (delta_tokens / norm["longitud"]["sigma"])
    # El ruido del anotador entra dos veces (una por lado) y es gaussiano.
    sigma_par = cfg["sigma_ruido"] * np.sqrt(2.0)
    rng = np.random.default_rng(0)
    n = 20000
    cambia = rng.random(n) < fraccion
    du = np.where(cambia, du_formato, 0.0) + du_largo + rng.normal(0, sigma_par, n)
    p = 1.0 / (1.0 + np.exp(-np.clip(du / cfg["tau"], -40, 40)))
    return float(p.mean())


def probabilidad_de_aprobar(p_verdadera, n, alfa=0.05, umbral=0.50,
                            replicas=2000, boot=2000, semilla=0):
    """Con que frecuencia el IC inferior de una cola queda por encima del umbral."""
    rng = np.random.default_rng(semilla)
    exitos = rng.binomial(n, p_verdadera, size=replicas)
    aprueban = 0
    for k in exitos:
        x = np.concatenate([np.ones(k), np.zeros(n - k)])
        r = est.bootstrap_pareado(x, replicas=boot, alfa=alfa, semilla=0,
                                  unilateral=True)
        if r["ic"][0] > umbral:
            aprueban += 1
    return aprueban / replicas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config-oraculo", default="configs/oraculo_real_corto.yaml")
    ap.add_argument("--n", type=int, default=200, help="consultas de evaluacion")
    ap.add_argument("--alfa", type=float, default=0.05)
    ap.add_argument("--umbral", type=float, default=0.50)
    ap.add_argument("--delta-tokens", type=float, default=0.0)
    args = ap.parse_args()

    cfg = orc.cargar_config(args.config_oraculo)

    print(f"\noraculo: {args.config_oraculo}")
    print(f"evaluacion: n={args.n}, alfa={args.alfa}, umbral IC inferior "
          f"> {args.umbral}, una cola")
    print(f"desplazamiento de longitud supuesto: {args.delta_tokens:+.0f} tokens\n")

    mde = est.efecto_minimo_detectable(args.n, alfa=args.alfa)
    print(f"efecto minimo detectable con n={args.n}: win-rate {mde}\n")

    for perfil in cfg["perfiles"]:
        print(f"--- anotador {perfil} "
              f"(peso de pasos numerados: {cfg['perfiles'][perfil]['pasos']:+.2f}) ---")
        print(f"  {'formato al gusto':>18}  {'win-rate':>9}  {'P(aprueba)':>11}")
        for f in FRACCIONES:
            wr = win_rate_teorico(cfg, perfil, f, args.delta_tokens)
            pa = probabilidad_de_aprobar(wr, args.n, args.alfa, args.umbral)
            print(f"  {f:>17.0%}  {wr:>9.3f}  {pa:>11.0%}")
        print()

    print("Lectura: la columna de la izquierda es lo que el adaptador tiene que")
    print("conseguir en el texto. Si el gate no aprueba ni con el 100%, el")
    print("problema no es el entrenamiento: es que el escenario no tiene un")
    print("efecto lo bastante grande para el n disponible.\n")


if __name__ == "__main__":
    main()
