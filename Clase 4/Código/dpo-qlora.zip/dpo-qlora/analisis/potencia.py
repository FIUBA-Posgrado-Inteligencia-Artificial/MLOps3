"""Analisis de potencia. Se corre ANTES de fijar el tamaño del conjunto de
evaluacion y su salida va al pre-registro.

Decir "no dio significativo" con un diseño sin potencia no es un resultado.

Uso:
    python -m analisis.potencia
"""

from gate import estadistica as est

EFECTOS = [0.55, 0.57, 0.60, 0.65]
TAMAÑOS = [100, 150, 200, 300, 500, 800]


def tabla():
    filas = []
    for p in EFECTOS:
        n = est.n_para_potencia(p, potencia_objetivo=0.80, alfa=0.05)
        filas.append({"win_rate_verdadero": p, "n_para_potencia_80": n})
    return filas


def potencia_por_tamaño(p=0.55):
    return [{"n": n, "potencia": round(est.potencia_pareada(p, n), 3),
             "efecto_minimo_detectable": est.efecto_minimo_detectable(n)}
            for n in TAMAÑOS]


if __name__ == "__main__":
    print("n necesario para potencia 0.80, alfa 0.05, diseño pareado\n")
    for fila in tabla():
        print(f"  win-rate {fila['win_rate_verdadero']:.2f} -> "
              f"n = {fila['n_para_potencia_80']}")

    print("\npotencia y efecto minimo detectable por tamaño de muestra "
          "(para un win-rate verdadero de 0.55)\n")
    for fila in potencia_por_tamaño():
        print(f"  n = {fila['n']:4d}  potencia = {fila['potencia']:.3f}  "
              f"efecto minimo detectable = {fila['efecto_minimo_detectable']}")

    print("\nSi el n necesario supera el presupuesto de computo, el pre-registro "
          "declara el efecto minimo detectable con el n que si se puede pagar.")
