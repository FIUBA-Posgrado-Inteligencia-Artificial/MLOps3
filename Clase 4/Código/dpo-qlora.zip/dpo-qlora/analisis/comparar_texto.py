"""Muestra el texto: base contra adaptador, sobre las mismas consultas.

Todo el resto del experimento mide. Esto muestra. Es lo unico del repositorio
que responde a la pregunta que cualquiera hace en clase apenas se habla de
preferencias: "¿y como quedan las respuestas?".

Se corre despues del bucle, con el adaptador que el gate promovio (o con
cualquiera de los candidatos, para ver tambien los que fueron rechazados):

    python -m analisis.comparar_texto \
        --adaptador /content/drive/.../corrida-s11/adaptadores/r05 \
        --n 4

Genera con la instruccion NEUTRA en los dos casos: lo que se compara es lo que
cada politica hace por su cuenta, no lo que hace cuando se le pide el estilo.
"""

import argparse

import yaml

from entrenamiento import modelo_real as mr
from simulador import consultas as bc
from simulador import rasgos as rg

ANCHO = 78


def _recuadro(titulo):
    print("\n" + "=" * ANCHO)
    print(titulo)
    print("=" * ANCHO)


def _resumen(texto, hechos):
    r = rg.medir_rasgos(texto, hechos)
    return (f"[{int(r['longitud']):>3} tokens · "
            f"pasos numerados: {'si' if r['pasos'] else 'no'} · "
            f"cortesia: {int(r['cortesia'])} · "
            f"cobertura: {r['cobertura']:.2f}]")


def comparar(ruta_adaptador, cfg_dpo, n=4, semilla=0, tam_lote=8,
             split="evaluacion"):
    banco = bc.leer_banco()
    consultas = bc.por_split(banco, split, n)

    modelo, tok = mr.cargar_modelo(cfg_dpo)

    print("\ngenerando con el modelo base...")
    _, antes = mr.generar_lote(modelo, tok, consultas, cfg_dpo, semilla,
                               temperatura=0.7, tam_lote=tam_lote)

    print("cargando el adaptador y volviendo a generar...")
    modelo = mr.cargar_adaptador(modelo, ruta_adaptador)
    _, despues = mr.generar_lote(modelo, tok, consultas, cfg_dpo, semilla,
                                 temperatura=0.7, tam_lote=tam_lote)

    for i, consulta in enumerate(consultas):
        _recuadro(f"CONSULTA {i + 1}: {consulta['texto']}")
        for etiqueta, texto in (("ANTES (modelo base)", antes[i]),
                                ("DESPUES (con el adaptador)", despues[i])):
            print(f"\n--- {etiqueta} " + "-" * max(0, ANCHO - 5 - len(etiqueta)))
            print(rg.recortar_a_oracion_completa(texto))
            print(_resumen(texto, consulta["hechos_clave"]))

    # Agregado: lo que se ve en cuatro ejemplos puede ser casualidad; el
    # promedio sobre las n consultas dice si el desplazamiento es sistematico.
    _recuadro("PROMEDIOS SOBRE LAS CONSULTAS MOSTRADAS")
    for etiqueta, textos in (("base      ", antes), ("adaptador ", despues)):
        medidas = [rg.medir_rasgos(t, c["hechos_clave"])
                   for t, c in zip(textos, consultas)]
        largo = sum(m["longitud"] for m in medidas) / len(medidas)
        pasos = sum(m["pasos"] for m in medidas) / len(medidas)
        cort = sum(m["cortesia"] for m in medidas) / len(medidas)
        # Cobertura media Y tasa de acierto. La tasa sola engaña: con tres
        # hechos por consulta solo puede valer 0, 0.33, 0.67 o 1, y el umbral
        # de 0.5 la convierte en un acantilado. Una cobertura media de 0.45
        # contra una de 0.48 son casi lo mismo y dan tasas de acierto muy
        # distintas.
        cob = sum(m["cobertura"] for m in medidas) / len(medidas)
        acierto = sum(1 for m in medidas if m["cobertura"] >= 0.5) / len(medidas)
        idioma = sum(m["fuera_de_idioma"] for m in medidas) / len(medidas)
        print(f"  {etiqueta} longitud media {largo:6.1f} · "
              f"con pasos numerados {pasos:.0%} · cortesia media {cort:.2f}")
        print(f"  {' ' * len(etiqueta)} cobertura media {cob:.2f} · "
              f"tasa de acierto (>=0.5) {acierto:.0%} · "
              f"fuera de idioma {idioma:.3f}")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adaptador", required=True,
                    help="carpeta del adaptador, p. ej. .../adaptadores/r05")
    ap.add_argument("--config-dpo", default="configs/dpo.yaml")
    ap.add_argument("--n", type=int, default=4)
    ap.add_argument("--semilla", type=int, default=0)
    ap.add_argument("--split", default="evaluacion",
                    help="evaluacion | canary — usa canary para diagnosticar la correccion")
    args = ap.parse_args()

    with open(args.config_dpo, encoding="utf-8") as f:
        cfg_dpo = yaml.safe_load(f)
    comparar(args.adaptador, cfg_dpo, n=args.n, semilla=args.semilla,
             split=args.split)


if __name__ == "__main__":
    main()
