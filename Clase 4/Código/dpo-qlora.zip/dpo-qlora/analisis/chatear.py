"""Inferencia interactiva: hablarle al modelo, con y sin adaptador.

Es lo mas parecido a "usar" el resultado del ejercicio. Carga el modelo base,
le pone encima el adaptador que elijas y responde a lo que escribas.

Anda sin GPU. En una Mac con chip Apple usa MPS en fp32: un modelo de 0.5B
responde en unos segundos, suficiente para mostrarlo en vivo.

    # solo el modelo base
    python -m analisis.chatear

    # con el adaptador que el gate promovio
    python -m analisis.chatear --adaptador corrida-A-sin-guardarrail/adaptadores/r04

    # las dos respuestas, lado a lado, a la misma pregunta
    python -m analisis.chatear --adaptador .../adaptadores/r04 --comparar

Dentro de la sesion:
    /salir            termina
    /adaptador RUTA   cambia de adaptador en caliente (o 'base' para sacarlo)
    /comparar         alterna el modo lado a lado
"""

import argparse
import textwrap

import yaml

from entrenamiento import modelo_real as mr
from simulador import rasgos as rg

ANCHO = 76


def _consulta(texto, hechos=None):
    """El formato que espera aplicar_plantilla. Sin hechos no hay contexto."""
    return {"texto": texto, "hechos_clave": hechos or []}


def responder(modelo, tok, cfg, pregunta, hechos, semilla, temperatura):
    _, textos = mr.generar_lote(modelo, tok, [_consulta(pregunta, hechos)], cfg,
                                semilla, temperatura=temperatura, tam_lote=1)
    return textos[0]


def _mostrar(etiqueta, texto, hechos):
    r = rg.medir_rasgos(texto, hechos)
    print(f"\n  [{etiqueta}]  {int(r['longitud'])} tokens · "
          f"pasos numerados: {'si' if r['pasos'] else 'no'} · "
          f"cortesia: {int(r['cortesia'])}"
          + (f" · cobertura: {r['cobertura']:.2f}" if hechos else "")
          + (f" · FUERA DE IDIOMA {r['fuera_de_idioma']:.3f}"
             if r["fuera_de_idioma"] > rg.UMBRAL_FUERA_DE_IDIOMA else ""))
    print("  " + "-" * ANCHO)
    for linea in rg.recortar_a_oracion_completa(texto).splitlines():
        for trozo in textwrap.wrap(linea, ANCHO) or [""]:
            print("  " + trozo)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adaptador", default=None,
                    help="carpeta del adaptador; sin esto usa el modelo base")
    ap.add_argument("--comparar", action="store_true",
                    help="responde con base y con adaptador a cada pregunta")
    ap.add_argument("--config-dpo", default="configs/dpo.yaml")
    ap.add_argument("--temperatura", type=float, default=0.7)
    ap.add_argument("--hechos", default=None,
                    help="hechos separados por coma, como los que el sistema "
                         "inyecta en el prompt: 'reiniciar,firmware,banda 2.4'")
    ap.add_argument("--pregunta", default=None,
                    help="una sola pregunta y sale, sin modo interactivo")
    args = ap.parse_args()

    with open(args.config_dpo, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    hechos = [h.strip() for h in args.hechos.split(",")] if args.hechos else []

    print("cargando el modelo (la primera vez descarga los pesos)...")
    modelo, tok = mr.cargar_modelo(cfg)
    base = modelo                      # referencia al objeto sin adaptador
    activo = None
    comparar = args.comparar

    def activar(ruta):
        nonlocal modelo, activo
        modelo = mr.cargar_adaptador(modelo, ruta)
        activo = ruta
        print(f"adaptador: {ruta or 'ninguno (modelo base)'}")

    if args.adaptador:
        activar(args.adaptador)
    print(f"dispositivo: {next(base.parameters()).device} · "
          f"temperatura {args.temperatura}")

    semilla = 0

    def turno(pregunta):
        nonlocal semilla
        semilla += 1
        if comparar and activo:
            activar(None)
            texto_base = responder(modelo, tok, cfg, pregunta, hechos,
                                   semilla, args.temperatura)
            activar(args.adaptador)
            texto_ad = responder(modelo, tok, cfg, pregunta, hechos,
                                 semilla, args.temperatura)
            _mostrar("MODELO BASE", texto_base, hechos)
            _mostrar("CON ADAPTADOR", texto_ad, hechos)
        else:
            texto = responder(modelo, tok, cfg, pregunta, hechos,
                              semilla, args.temperatura)
            _mostrar(activo and "CON ADAPTADOR" or "MODELO BASE", texto, hechos)

    if args.pregunta:
        turno(args.pregunta)
        return

    print("\nEscribi tu consulta. /salir para terminar, "
          "/adaptador RUTA para cambiar, /comparar para alternar.\n")
    while True:
        try:
            linea = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not linea:
            continue
        if linea == "/salir":
            break
        if linea == "/comparar":
            comparar = not comparar
            print(f"modo comparar: {'si' if comparar else 'no'}")
            continue
        if linea.startswith("/adaptador"):
            partes = linea.split(maxsplit=1)
            ruta = None if len(partes) == 1 or partes[1] == "base" else partes[1]
            args.adaptador = ruta
            activar(ruta)
            continue
        turno(linea)
        print()


if __name__ == "__main__":
    main()
