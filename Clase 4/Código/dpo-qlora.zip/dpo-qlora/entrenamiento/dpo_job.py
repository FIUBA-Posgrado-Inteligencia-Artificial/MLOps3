"""Job real de DPO con QLoRA. Este es el que corre para el informe.

Nota de memoria, que es la mitad del contenido de la clase 5: DPO necesita la
politica y la referencia al mismo tiempo. Con PEFT no se cargan dos modelos: se
deja `ref_model=None` y TRL calcula las log-probabilidades de la referencia
desactivando el adaptador sobre el mismo modelo base. Cargar dos copias es el
error clasico que termina en out of memory.

Uso:
    python -m entrenamiento.dpo_job --lote data/lotes/ronda_05.jsonl \\
        --salida artefactos/dpo-adapter-v5 --config configs/dpo.yaml
"""

import argparse
import json
import os
import time

import yaml


def cargar_config(ruta):
    with open(ruta, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _reportes_disponibles():
    """Que integraciones de seguimiento se pueden pedir sin romper el arranque.

    Transformers instancia el callback de MLflow apenas ve `report_to=["mlflow"]`,
    y si la libreria no esta instalada aborta el entrenamiento. En un entorno
    administrado (Colab) no siempre esta, y no vale la pena bajarla solo para eso:
    el bucle registra por su cuenta en `orquestador/seguimiento.py`, que ya tiene
    respaldo local.
    """
    try:
        import mlflow                                      # noqa: F401
        return ["mlflow"]
    except Exception:                                      # noqa: BLE001
        return []


def _filtrar_argumentos(objetivo, deseados):
    """Deja solo los argumentos que la version instalada de TRL acepta.

    `DPOConfig` es una dataclass que hereda de `TrainingArguments`, asi que sus
    campos se leen con `dataclasses.fields`. `DPOTrainer` es una clase comun y
    se inspecciona su firma. Si la firma acepta **kwargs, no se filtra nada.
    """
    import dataclasses
    import inspect

    if dataclasses.is_dataclass(objetivo):
        validos = {f.name for f in dataclasses.fields(objetivo)}
    else:
        parametros = inspect.signature(objetivo.__init__).parameters
        if any(p.kind == p.VAR_KEYWORD for p in parametros.values()):
            return dict(deseados), []
        validos = set(parametros) - {"self"}

    aceptados = {k: v for k, v in deseados.items() if k in validos}
    ignorados = sorted(set(deseados) - set(aceptados))
    return aceptados, ignorados


def preparar_dataset(pares):
    """TRL espera las columnas prompt / chosen / rejected."""
    from datasets import Dataset
    return Dataset.from_list([
        {"prompt": p["prompt"], "chosen": p["chosen"], "rejected": p["rejected"]}
        for p in pares
    ])


def entrenar(pares, cfg, salida, semilla=None, reiniciar_desde=None):
    import torch
    from peft import LoraConfig, PeftModel, prepare_model_for_kbit_training
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from trl import DPOConfig, DPOTrainer

    # La precision se detecta, no se fija: una T4 no soporta bfloat16.
    from entrenamiento.modelo_real import precision_soportada
    dtype = precision_soportada()
    usa_bf16 = dtype == "bfloat16"
    usa_fp16 = dtype == "float16"
    print(f"[dpo_job] precision de computo: {dtype}")
    reportes = _reportes_disponibles()
    print(f"[dpo_job] seguimiento: {reportes or 'sin integracion (registro propio)'}")

    cuant = cfg["cuantizacion"]
    bnb = BitsAndBytesConfig(
        load_in_4bit=cuant["cargar_en_4bits"],
        bnb_4bit_quant_type=cuant["tipo_cuantizacion"],
        bnb_4bit_use_double_quant=cuant["doble_cuantizacion"],
        bnb_4bit_compute_dtype=getattr(torch, dtype),
    )

    tok = AutoTokenizer.from_pretrained(cfg["modelo_base"])
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    modelo = AutoModelForCausalLM.from_pretrained(
        cfg["modelo_base"], quantization_config=bnb, device_map="auto")
    modelo = prepare_model_for_kbit_training(
        modelo, use_gradient_checkpointing=cfg["dpo"]["gradient_checkpointing"])

    if reiniciar_desde:
        # Continuar desde el adaptador en produccion en lugar de partir de cero.
        # Cual de las dos es mejor bajo drift es una de las decisiones que el
        # grupo tiene que justificar.
        modelo = PeftModel.from_pretrained(modelo, reiniciar_desde, is_trainable=True)
        peft_config = None
    else:
        peft_config = LoraConfig(
            r=cfg["lora"]["r"], lora_alpha=cfg["lora"]["alpha"],
            lora_dropout=cfg["lora"]["dropout"],
            target_modules=cfg["lora"]["modulos"],
            task_type="CAUSAL_LM", bias="none")

    d = cfg["dpo"]
    deseados = {
        "output_dir": salida,
        "beta": d["beta"],
        "loss_type": d["loss_type"],
        "learning_rate": d["learning_rate"],
        "num_train_epochs": d["num_train_epochs"],
        "per_device_train_batch_size": d["per_device_train_batch_size"],
        "gradient_accumulation_steps": d["gradient_accumulation_steps"],
        "max_length": d["max_length"],
        "max_prompt_length": d["max_prompt_length"],
        "warmup_ratio": d["warmup_ratio"],
        "lr_scheduler_type": d["lr_scheduler_type"],
        "gradient_checkpointing": d["gradient_checkpointing"],
        "bf16": usa_bf16,
        "fp16": usa_fp16,
        "logging_steps": d["logging_steps"],
        "seed": semilla if semilla is not None else d["seed"],
        "report_to": _reportes_disponibles(),
        "save_strategy": "no",
    }
    aceptados, ignorados = _filtrar_argumentos(DPOConfig, deseados)
    if ignorados:
        # La API de TRL cambia entre versiones: argumentos que existian se van y
        # otros aparecen. En lugar de anclar una version (imposible en un entorno
        # administrado como Colab), se descartan los que la version instalada no
        # conoce y se avisa cuales. Si entre los descartados hay alguno que
        # importa de verdad, aparece en este aviso y se decide que hacer.
        print(f"[dpo_job] DPOConfig ignora: {', '.join(ignorados)}")
    args = DPOConfig(**aceptados)

    # Cuantos pasos de optimizador va a dar realmente este entrenamiento. Es el
    # numero que faltaba mirar: con LoRA, por debajo de ~15 pasos el adaptador
    # apenas se mueve, por mas que la tasa de aprendizaje sea alta y el lote
    # tenga senal. Un lote chico con acumulacion grande da poquisimos pasos.
    lote_efectivo = (d["per_device_train_batch_size"]
                     * d["gradient_accumulation_steps"])
    pasos = max(1, (len(pares) // lote_efectivo)) * d["num_train_epochs"]
    print(f"[dpo_job] {len(pares)} pares · lote efectivo {lote_efectivo} · "
          f"{d['num_train_epochs']} epoca(s) -> ~{pasos} pasos de optimizador"
          + ("   (POCOS: el adaptador casi no se va a mover)" if pasos < 15 else ""))

    argumentos_entrenador = {
        "model": modelo,
        "ref_model": None,             # ver la nota de memoria del encabezado
        "args": args,
        "train_dataset": preparar_dataset(pares),
        "peft_config": peft_config,
        # El tokenizador cambio de nombre de parametro entre versiones.
        "processing_class": tok,
        "tokenizer": tok,
    }
    aceptados_ent, ignorados_ent = _filtrar_argumentos(DPOTrainer, argumentos_entrenador)
    if "processing_class" in aceptados_ent:
        aceptados_ent.pop("tokenizer", None)
    if ignorados_ent:
        print(f"[dpo_job] DPOTrainer ignora: {', '.join(ignorados_ent)}")
    entrenador = DPOTrainer(**aceptados_ent)

    inicio = time.time()
    resultado = entrenador.train()
    entrenador.model.save_pretrained(salida)
    tok.save_pretrained(salida)

    historial = [r for r in entrenador.state.log_history if "rewards/margins" in r]
    ultimo = historial[-1] if historial else {}
    return salida, {
        "segundos": round(time.time() - inicio, 1),
        "train_loss": float(resultado.training_loss),
        "rewards/chosen": ultimo.get("rewards/chosen"),
        "rewards/rejected": ultimo.get("rewards/rejected"),
        "rewards/margins": ultimo.get("rewards/margins"),
        "rewards/accuracies": ultimo.get("rewards/accuracies"),
        "logps/chosen": ultimo.get("logps/chosen"),
        "logps/rejected": ultimo.get("logps/rejected"),
        "n_pares": len(pares),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lote", required=True, help="jsonl con prompt/chosen/rejected")
    ap.add_argument("--salida", required=True)
    ap.add_argument("--config", default="configs/dpo.yaml")
    ap.add_argument("--semilla", type=int, default=None)
    ap.add_argument("--desde", default=None, help="adaptador del que continuar")
    args = ap.parse_args()

    with open(args.lote, encoding="utf-8") as f:
        pares = [json.loads(l) for l in f if l.strip()]

    os.makedirs(args.salida, exist_ok=True)
    ruta, metricas = entrenar(pares, cargar_config(args.config), args.salida,
                              args.semilla, args.desde)
    print(json.dumps({"adaptador": ruta, **metricas}, indent=2))


if __name__ == "__main__":
    main()
