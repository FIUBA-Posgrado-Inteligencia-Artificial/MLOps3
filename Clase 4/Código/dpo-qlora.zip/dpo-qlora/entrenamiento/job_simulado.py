"""Job de entrenamiento del modo simulado.

Hace, en cuatro dimensiones de estilo, lo mismo que DPO hace en el espacio de
parametros de un modelo: ajusta un modelo de Bradley-Terry sobre las
diferencias de rasgos entre la respuesta elegida y la descartada, y mueve la
politica en la direccion del gradiente con un paso acotado por beta.

Es una maqueta con un proposito concreto: permitir depurar el bucle completo en
segundos. El entrenamiento que va al informe es entrenamiento/dpo_job.py.
"""

import json
import math
import os

import numpy as np

from simulador.rasgos import medir_rasgos

RASGOS = ("longitud", "pasos", "cortesia", "cobertura")


def _vector(texto):
    r = medir_rasgos(texto, [])
    return np.array([math.log1p(r["longitud"]), r["pasos"], r["cortesia"], 0.0])


def _vector_con_cobertura(texto, hechos):
    r = medir_rasgos(texto, hechos)
    return np.array([math.log1p(r["longitud"]), r["pasos"], r["cortesia"],
                     r["cobertura"]])


def ajustar_pesos(pares, l2=0.05, pasos=400, lr=0.25):
    """Maxima verosimilitud de Bradley-Terry: maximizar sum log sigmoid(w . dx).

    Es la misma forma funcional que la perdida de DPO, con rasgos observables en
    lugar de log-probabilidades del modelo.
    """
    diferencias = []
    for p in pares:
        hechos = p.get("hechos_clave", [])
        dx = _vector_con_cobertura(p["chosen"], hechos) - \
            _vector_con_cobertura(p["rejected"], hechos)
        diferencias.append(dx)
    if not diferencias:
        return np.zeros(len(RASGOS)), 0.5
    X = np.vstack(diferencias)
    escala = np.maximum(X.std(axis=0), 1e-6)
    Xn = X / escala

    w = np.zeros(Xn.shape[1])
    for _ in range(pasos):
        z = np.clip(Xn @ w, -30, 30)
        s = 1.0 / (1.0 + np.exp(z))          # 1 - sigmoid(z)
        grad = (Xn * s[:, None]).mean(axis=0) - l2 * w
        w += lr * grad
    precision = float(np.mean((Xn @ w) > 0))
    return w / escala, precision


def entrenar(politica_inicial, pares, beta=0.10, eta=0.35):
    w, precision = ajustar_pesos(pares)
    norma = np.linalg.norm(w) + 1e-9
    w_unit = w / norma
    # beta chico = menos restriccion contra la referencia = paso mas grande.
    paso = eta * (0.10 / max(beta, 1e-3))
    # El paso se escala por la fuerza de la evidencia. Sin esto, un lote con
    # etiquetas al azar produciria un salto del mismo tamaño en una direccion
    # arbitraria, y el control negativo dejaria de ser un control.
    paso *= float(np.tanh(3.0 * norma))

    nueva = dict(politica_inicial)
    nueva["longitud_objetivo"] = float(np.clip(
        politica_inicial["longitud_objetivo"] * math.exp(paso * w_unit[0]), 25, 400))
    nueva["p_pasos"] = float(np.clip(
        politica_inicial["p_pasos"] + paso * w_unit[1], 0.0, 1.0))
    nueva["p_cortesia"] = float(np.clip(
        politica_inicial["p_cortesia"] + paso * w_unit[2], 0.0, 1.0))
    nueva["cobertura_objetivo"] = float(np.clip(
        politica_inicial["cobertura_objetivo"] + paso * w_unit[3], 0.30, 0.98))

    metricas = {
        "bt_precision_entrenamiento": precision,
        "bt_pesos": {r: float(v) for r, v in zip(RASGOS, w)},
        "bt_norma": float(norma),
        "paso": paso,
        "n_pares": len(pares),
    }
    return nueva, metricas


def guardar_adaptador(politica, version, hash_lote, directorio="artefactos"):
    os.makedirs(directorio, exist_ok=True)
    ruta = os.path.join(directorio, f"{version}.json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump({"version": version, "hash_lote": hash_lote,
                   "politica": politica}, f, ensure_ascii=False, indent=2)
    return ruta
