"""Utilidades del modelo real: carga, generacion por lotes y divergencia.

- la nota de memoria vale para todo el archivo: con PEFT no se cargan dos
modelos
- la politica es el modelo base con el adaptador activo 
- y la referencia es el mismo modelo con el adaptador desactivado.
"""

import os


def precision_soportada():
    """
    Elige el tipo de computo segun lo que la GPU soporta

    Una T4 (gpu de colab) no soporta bfloat16: pedirlo termina en
    error o en una caida de rendimiento grande
    """
    import torch
    
    if torch.cuda.is_available() and torch.cuda.get_device_capability()[0] >= 8:
        return "bfloat16"
    if torch.cuda.is_available():
        return "float16"
    return "float32"


def cargar_modelo(cfg, con_gpu=True):
    """
    Carga el modelo base
    """
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(cfg["modelo_base"])
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left" # necesario para generar por lotes

    if con_gpu and torch.cuda.is_available():
        from transformers import BitsAndBytesConfig
        c = cfg["cuantizacion"]
        dtype = precision_soportada()
        print(f"[modelo_real] precision de computo: {dtype}")
        bnb = BitsAndBytesConfig(
            load_in_4bit=c["cargar_en_4bits"],
            bnb_4bit_quant_type=c["tipo_cuantizacion"],
            bnb_4bit_use_double_quant=c["doble_cuantizacion"],
            bnb_4bit_compute_dtype=getattr(torch, dtype),
        )
        modelo = AutoModelForCausalLM.from_pretrained(
            cfg["modelo_base"], quantization_config=bnb, device_map="auto")
    else:
        # bitsandbytes no funciona en Apple Silicon
        dispositivo = "mps" if torch.backends.mps.is_available() else "cpu"
        modelo = AutoModelForCausalLM.from_pretrained(
            cfg["modelo_base"], torch_dtype=torch.float32).to(dispositivo)

    modelo.eval()
    return modelo, tok


SISTEMA_BASE = (
    "Eres soporte tecnico de un router hogareño. Responde en español, siempre "
    "con indicaciones concretas que el usuario pueda seguir. Nunca te niegues "
    "a responder ni derives a otro canal.")


def _contexto(consulta):
    """Los hechos relevantes, puestos en el prompt como si vinieran de un RAG.

    Sin esto el modelo de 0.5B no tiene de donde sacar "banda 2.4" ni
    "firmware", peor todavia, el modelo se va a "lo siento, no
    puedo ayudarte" que no nos sirve para nada

    Poner los hechos en el prompt convierte la correccion en una tarea de
    usar el contexto, que es lo que un modelo pequeño sabe hacer, y es
    ademas como funciona cualquier asistente de soporte de verdad


    Notas de la base de conocimiento para este caso. Usalas todas en tu respuesta:
    - reiniciar
    - firmware
    - banda 2.4
    """
    hechos = consulta.get("hechos_clave") or []
    if not hechos:
        return ""
    puntos = "\n".join(f"- {h}" for h in hechos)
    return ("\n\nNotas de la base de conocimiento para este caso. Usalas todas "
            f"en tu respuesta:\n{puntos}")

# Abanico de estilos para la recolección, no es una lista de estilos buenos:
# es una forma barata de que los dos candidatos de un par se diferencien en
# algo que el oraculo pueda puntuar...
# Sin esto, los dos candidatos salen de la misma politica con el mismo prompt 
# y difieren solo por el ruido del muestreo: el oraculo elegirá practicamente 
# al azar, la etiqueta no lleva senal y el DPO entrena con margenes cercanos a cero (o negativos).
#
# Tres propiedades que el codigo verifica:
#   1. El conjunto es fijo: no cambia entre rondas ni entre fases. Si cambiara
#      con la fase, el sistema estaria leyendo la respuesta del examen.
#   2. Cubre las dos puntas de cada eje de estilo (largo/corto, pasos/prosa),
#      asi que sirve igual para la fase didactica y para la operativa.
#   3. Lo unico que se persiste es (prompt, chosen, rejected): el sistema ve textos,
#      nunca de que instruccion salio cada uno.

# - Cuatro instrucciones de estilo distintas
# - El mismo modelo, la misma consulta, cuatro respuestas que difieren en algo que el oráculo puede puntuar
PERSONAS = (
    ("prosa_larga",
     "Responde en uno o dos parrafos corridos, explicando el porque de cada "
     "cosa. No uses listas ni numeracion."),
    ("pasos_secos",
     "Responde unicamente con una lista numerada de pasos. Un paso por linea, "
     "empezando cada linea con '1.', '2.', '3.'. Sin introduccion ni cierre."),
    ("breve",
     "Responde en dos o tres oraciones como maximo, directo al grano."),
    ("calido_detallado",
     "Responde de forma amable y detallada: saluda, explica con calma y "
     "ofrece ayuda adicional al final."),
)


def aplicar_plantilla(tok, consulta, persona=None):
    """Arma el prompt: persona solo se usa al recolectar, no al evaluar

    La evaluacion genera siempre con la instruccion neutra: lo que se mide es
    lo que la politica hace por su cuenta, no lo que hace cuando se le pide el
    estilo de memoria


    SIN PERSONA (al evaluar)
    <|im_start|>system
    Eres soporte tecnico de un router hogareño. Responde en español, siempre con
    indicaciones concretas que el usuario pueda seguir. Nunca te niegues a responder
    ni derives a otro canal.

    Notas de la base de conocimiento para este caso. Usalas todas en tu respuesta:
    - reiniciar
    - firmware
    - banda 2.4<|im_end|>
    <|im_start|>user
    no me anda el wifi despues de la actualizacion. Soy usuario nuevo y no manejo terminos tecnicos.<|im_end|>
    <|im_start|>assistant


    CON PERSONA (al recolectar)
    Cambia una sola cosa, el final de la primera línea del bloque de sistema:

    ... ni derives a otro canal. Responde unicamente con una lista numerada de pasos.
    Un paso por linea, empezando cada linea con '1.', '2.', '3.'. Sin introduccion ni cierre.

    Notas de la base de conocimiento...
    """

    sistema = SISTEMA_BASE if persona is None else f"{SISTEMA_BASE} {persona}"
    sistema += _contexto(consulta)
    mensajes = [
        {"role": "system", "content": sistema},
        {"role": "user", "content": consulta["texto"]},
    ]
    return tok.apply_chat_template(mensajes, tokenize=False,
                                   add_generation_prompt=True)


def generar_lote(modelo, tok, consultas, cfg, semilla, temperatura=0.85,
                 tam_lote=16, persona=None):
    """Genera una respuesta por consulta, en lotes
    devuelve (prompts, textos)

    prompts = [
    "<|im_start|>system\nEres soporte tecnico...",   # el de c1
    "<|im_start|>system\nEres soporte tecnico...",   # el de c2
    "<|im_start|>system\nEres soporte tecnico...",   # el de c3
    ]

    textos = [
    "Hola, entiendo la molestia. Lo primero es reiniciar el equipo: desconectalo treinta segundos...",
    "El problema puede venir del firmware. Revisa la version instalada y...",
    "Prueba conectarte a la banda 2.4, que tiene mas alcance...",
    ]
    """
    import torch

    prompts = [aplicar_plantilla(tok, c, persona) for c in consultas]
    textos = []

    for inicio in range(0, len(prompts), tam_lote):
        trozo = prompts[inicio:inicio + tam_lote]
        entradas = tok(trozo, return_tensors="pt", padding=True,
                       truncation=True, max_length=cfg["dpo"]["max_prompt_length"]
                       ).to(modelo.device)
        torch.manual_seed(semilla + inicio)
        with torch.no_grad():
            salida = modelo.generate(
                **entradas,
                do_sample=True,
                temperature=temperatura,
                top_p=cfg["generacion"]["top_p"],
                max_new_tokens=cfg["generacion"]["max_new_tokens"],
                repetition_penalty=cfg["generacion"]["repetition_penalty"],
                pad_token_id=tok.pad_token_id,
            )
        largo_prompt = entradas["input_ids"].shape[1]
        for fila in salida:
            textos.append(tok.decode(fila[largo_prompt:],
                                     skip_special_tokens=True).strip())

    return prompts, textos


def generar_par(modelo, tok, consultas, cfg, semilla, temperatura=0.85,
                tam_lote=16):
    """Dos candidatos por consulta, con semillas distintas.

    Se conserva para el control negativo de diversidad: mide que pasa cuando
    los candidatos salen del mismo prompt y solo los separa el muestreo.
    """
    prompts, a = generar_lote(modelo, tok, consultas, cfg, semilla,
                              temperatura, tam_lote)
    _, b = generar_lote(modelo, tok, consultas, cfg, semilla + 10 ** 6,
                        temperatura, tam_lote)
    return prompts, a, b


def generar_abanico(modelo, tok, consultas, cfg, semilla, temperatura=0.85,
                    tam_lote=16, k=4):
    """Un candidato por persona y por consulta.

    Devuelve (prompts_neutros, candidatos) donde candidatos[i] es la lista de
    k textos para la consulta i, en el orden de personas. El prompt que se
    guarda y con el que despues se entrena es el neutro: el DPO nunca ve la
    instruccion de estilo que produjo cada texto, solo el texto.



    [
    [ "Cuando una actualizacion deja el wifi sin funcionar suele ser porque el firmware...",   # prosa_larga
        "1. Reinicia el router.\n2. Verifica la version de firmware.\n3. Conecta en banda 2.4.", # pasos_secos
        "Reinicia el equipo y revisa el firmware. Si sigue igual, usa la banda 2.4.",            # breve
        "Hola, que lastima lo que te pasa. Vamos por partes: primero reinicia...",               # calido_detallado
    ],
    [ ... otros 4 para la consulta 2 ... ],
    [ ... otros 4 para la consulta 3 ... ],
    ]
    """
    k = min(k, len(PERSONAS))
    prompts = [aplicar_plantilla(tok, c, None) for c in consultas]
    columnas = []
    for j, (nombre, instruccion) in enumerate(PERSONAS[:k]):
        _, textos = generar_lote(modelo, tok, consultas, cfg,
                                 semilla + j * 10 ** 6, temperatura, tam_lote,
                                 persona=instruccion)
        print(f"    abanico [{j + 1}/{k}] {nombre}: {len(textos)} respuestas")
        columnas.append(textos)
    candidatos = [[columnas[j][i] for j in range(k)] for i in range(len(consultas))]
    return prompts, candidatos


# Divergencia contra la referencia

def _logprob_media(modelo, tok, prompt, respuesta, max_length):
    """Log-probabilidad media por token de la respuesta, dado el prompt.
    
    - Es la log-probabilidad promedio por token de esa respuesta, siempre negativo, 
    - porque es el logaritmo de una probabilidad. Más cerca de cero significa "el modelo 
    - encuentra esta respuesta más natural"
    - devuelve 0.0 si la respuesta quedó vacía después de truncar

"""
    import torch

    entrada = tok(prompt + respuesta, return_tensors="pt", truncation=True,
                  max_length=max_length).to(modelo.device)
    n_prompt = tok(prompt, return_tensors="pt", truncation=True,
                   max_length=max_length)["input_ids"].shape[1]

    with torch.no_grad():
        logits = modelo(**entrada).logits[:, :-1, :]
    objetivos = entrada["input_ids"][:, 1:]
    logprobs = torch.log_softmax(logits.float(), dim=-1)
    tomados = logprobs.gather(2, objetivos.unsqueeze(2)).squeeze(2)

    # Solo la parte de la respuesta.
    trozo = tomados[:, n_prompt - 1:]
    if trozo.numel() == 0:
        return 0.0
    return float(trozo.mean())


def divergencia_real(modelo, tok, prompts, respuestas, max_length=768,
                     maximo=40):
    """Estimacion de la KL por token entre la politica y su referencia.

    Reemplaza al proxy sobre el vector de estilo del modo simulado. Se calcula
    puntuando las mismas respuestas con el adaptador activo y desactivado: la
    diferencia media de log-probabilidad por token es una estimacion de una
    muestra de la KL en la direccion de la politica.

    "maximo" acota cuantas respuestas se puntuan, porque cada una cuesta dos
    pasadas hacia adelante y esto corre en cada ronda.
    """
    pares = list(zip(prompts, respuestas))[:maximo]
    if not pares:
        return 0.0

    total = 0.0
    for prompt, respuesta in pares:
        con_adaptador = _logprob_media(modelo, tok, prompt, respuesta, max_length)
        with modelo.disable_adapter():
            sin_adaptador = _logprob_media(modelo, tok, prompt, respuesta, max_length)
        total += con_adaptador - sin_adaptador

    return total / len(pares)


def cargar_adaptador(modelo, ruta):
    """Activa un adaptador guardado sobre el modelo base ya cargado."""
    from peft import PeftModel

    if hasattr(modelo, "unload"):
        modelo = modelo.unload()
    if ruta is None:
        return modelo
    modelo = PeftModel.from_pretrained(modelo, ruta)
    modelo.eval()
    return modelo


def tamaño_adaptador(ruta):
    total = 0
    for raiz, _, archivos in os.walk(ruta):
        for a in archivos:
            total += os.path.getsize(os.path.join(raiz, a))
    return total
