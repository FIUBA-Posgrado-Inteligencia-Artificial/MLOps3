"""Armado del lote de entrenamiento.

Un adaptador sin hash de lote no es promocionable: el hash es lo que permite
reconstruir, meses despues, con que pares exactos se entreno cada version.
"""

import hashlib
import random

from store import db


def _se_distinguen(par, minimo_tokens):
    """Criterio observable de que un par tiene algo que ensenar."""
    from simulador.rasgos import tiene_pasos_numerados
    largo = abs(len(par["chosen"].split()) - len(par["rejected"].split()))
    formato = tiene_pasos_numerados(par["chosen"]) != tiene_pasos_numerados(par["rejected"])
    return largo >= minimo_tokens or formato


def hash_de_lote(pares):
    ids = sorted(p["par_id"] for p in pares)
    return hashlib.sha256("\n".join(ids).encode()).hexdigest()[:16]


def armar_lote(con, corrida, ronda_actual, cfg_exp, control="bucle", semilla=0):
    """Ventana deslizante de rondas. La ventana es, en los hechos, el
    hiperparametro que gobierna la velocidad de adaptacion: decidirlo y
    justificarlo es parte del TP."""
    ventana = cfg_exp["entrenamiento"]["ventana_rondas"]
    desde = max(1, ronda_actual - ventana + 1)

    if control == "oraculo":
        # Cota superior: este brazo, y solo este, tiene el privilegio de leer la
        # etiqueta de fase, y entrena unicamente con los pares de la fase
        # vigente. Ningun sistema real puede hacer esto; sirve para medir cuanto
        # cuesta tener que detectar el cambio en lugar de saberlo.
        todos = db.leer_pares_para_analisis(con, corrida)
        fase = next((p["fase_oraculo"] for p in todos if p["ronda"] == ronda_actual), None)
        pares = [p for p in todos
                 if p["fase_oraculo"] == fase and not p["es_duplicado"]
                 and desde <= p["ronda"] <= ronda_actual]
    else:
        pares = db.leer_pares_para_el_sistema(con, corrida, desde, ronda_actual)

    # Contrato de datos, ANTES de la curacion por margen.
    #
    # El orden importa: la curacion por margen mide la diferencia de longitud
    # con .split(), y un bloque en un alfabeto sin espacios cuenta como pocos
    # tokens. Eso hacia que un par contaminado pareciera de contraste ejemplar
    # y pasara. Filtrando primero, ese par ya no llega a la curacion.
    from store import validacion as val
    pares, _ = val.filtrar(pares)

    minimo = cfg_exp["entrenamiento"].get("margen_minimo_tokens", 0)
    if minimo:
        # Curacion por margen OBSERVABLE: se descartan los pares donde las dos
        # respuestas no se distinguen en nada que el sistema pueda ver, porque
        # ahi la etiqueta la decide el ruido del anotador y no la preferencia.
        #
        # "Distinguirse" es longitud O formato. Solo longitud no alcanza: una
        # lista numerada corta y un parrafo corto pueden tener el mismo largo y
        # ser opuestos en el eje que importa, y descartarlos dejaba afuera
        # justo los pares que ensenan el cambio de fase.
        #
        # Es una senal observable (contar tokens, buscar "1." al inicio de
        # linea), no la utilidad del oraculo: el sistema no esta espiando.
        antes = len(pares)
        pares = [p for p in pares if _se_distinguen(p, minimo)]
        print(f"    curacion por margen: {antes} -> {len(pares)} pares "
              f"(>= {minimo} tokens de diferencia o distinto formato)")

    if control == "negativo":
        # Control negativo: mismo volumen, misma ventana, etiquetas permutadas.
        # Si el sistema mejora igual, la ganancia no venia de la preferencia.
        rng = random.Random(semilla + 777)
        pares = [dict(p) for p in pares]
        for p in pares:
            if rng.random() < 0.5:
                p["chosen"], p["rejected"] = p["rejected"], p["chosen"]

    return pares, hash_de_lote(pares), (desde, ronda_actual)
