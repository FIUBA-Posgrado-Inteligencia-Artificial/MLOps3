"""
los rasgos observables de una respuesta

- este modulo es la unica entrada a las caracteristicas que el oraculo
mirará
- se mide sobre el texto, no sobre los parametros que lo generaron (sino seria trampa)
"""

import re
import unicodedata

# busca lineas que empiecen con un número y un punto o paréntesis
PATRON_PASOS = re.compile(r"(?m)^\s*\d+[\.\)]\s+\S")

MARCADORES_CORTESIA = (
    "por favor",
    "gracias",
    "con gusto",
    "quedo a disposicion",
    "espero que",
    "no dudes en",
    "lamento",
    "entiendo que",
)


def _normalizar(texto):
    sin_tildes = unicodedata.normalize("NFKD", texto)
    sin_tildes = "".join(c for c in sin_tildes if not unicodedata.combining(c))
    return sin_tildes.lower()


def contar_tokens(texto):
    return len(texto.split())


def tiene_pasos_numerados(texto):
    return 1.0 if len(PATRON_PASOS.findall(texto)) >= 2 else 0.0


def contar_cortesia(texto):
    plano = _normalizar(texto)
    return float(sum(plano.count(m) for m in MARCADORES_CORTESIA))


# Marcadores de que la respuesta se fue del español. No es un detector de
# idioma serio: es un guardarrail barato, y alcanza porque el colapso que hay
# que atrapar no es sutil (portugués, inglés y chino mezclados en la misma
# respuesta). Un detector de idioma de verdad seria otra dependencia y otro
# modelo cargado en memoria, y aca lo que importa es que el gate mire ALGO.
CARACTERES_AJENOS = "ãõçâêôàÃÕÇ"
PALABRAS_AJENAS = (
    # portugues
    "voce", "nao", "uma", "fazer", "pode", "entao", "escolha", "reinicie o",
    "consulte o", "execute o", "abra o", "bandeira", "atualize", "arquivo",
    "configuracao", "documentacao", "verifique", "desligue", "ou ",
    # ingles
    " the ", " and ", " for ", " with ", " found ", " update ", " example ",
    " usually ", " in the ", " router's ",
)


def fraccion_fuera_de_idioma(texto):
    """Cuanto de la respuesta no esta en español, entre 0 y 1.

    Suma dos evidencias: caracteres que el español no usa (incluye cualquier
    cosa fuera del alfabeto latino, como los ideogramas que aparecieron en la
    corrida) y marcadores lexicos de portugues o ingles.
    """
    if not texto.strip():
        return 1.0
    ajenos = sum(1 for c in texto if c in CARACTERES_AJENOS or ord(c) > 0x2000)
    plano = " " + _normalizar(texto) + " "
    palabras = max(1, len(plano.split()))
    marcas = sum(plano.count(p) for p in PALABRAS_AJENAS)
    return min(1.0, (ajenos / max(1, len(texto))) * 4.0 + marcas / palabras)


def _hecho_presente(plano, hecho):
    """Coincidencia tolerante.

    La coincidencia literal va bien para el texto de plantilla, pero no para la
    salida de un modelo real: nadie escribe "192.168.1.1" o "banda 2.4" tal
    cual. Se acepta el hecho si aparece completo, o si aparece su palabra mas
    informativa (la mas larga de cuatro letras o mas)
    """
    h = _normalizar(hecho)
    if h in plano:
        return True
    palabras = [p for p in h.split() if len(p) >= 4]
    if not palabras:
        return False
    return max(palabras, key=len) in plano


def cobertura_de_hechos(texto, hechos_clave):
    if not hechos_clave:
        return 1.0
    plano = _normalizar(texto)
    presentes = sum(1 for h in hechos_clave if _hecho_presente(plano, h))
    return presentes / len(hechos_clave)


def recortar_a_oracion_completa(texto):
    """Descarta la ultima oracion si quedo cortada por el limite de tokens.

    Un modelo real casi siempre termina la generacion en mitad de una frase
    porque se le acabaron los tokens. Eso no es una respuesta degenerada: es
    una respuesta truncada por presupuesto, y penalizarla confunde el
    experimento entero.
    """
    limpio = texto.strip()
    if limpio.endswith((".", "!", "?", ":")):
        return limpio
    corte = max(limpio.rfind("."), limpio.rfind("!"), limpio.rfind("?"))
    return limpio[:corte + 1].strip() if corte > 0 else limpio


UMBRAL_FUERA_DE_IDIOMA = 0.08

# Interruptor del guardarrail de idioma. Existe para poder correr el mismo
# codigo en las dos configuraciones y comparar: sin el guardarrail el sistema
# hackea la metrica, con el guardarrail no puede. Es la unica diferencia entre
# la corrida A y la corrida B del experimento real.
_GUARDARRAIL_IDIOMA = True


def activar_guardarrail_idioma(activo):
    global _GUARDARRAIL_IDIOMA
    _GUARDARRAIL_IDIOMA = bool(activo)


def guardarrail_idioma_activo():
    return _GUARDARRAIL_IDIOMA


def es_degenerada(texto):
    """Respuesta vacia, repetitiva o fuera de idioma.

    La truncadura por limite de tokens NO cuenta como degenerada: ver
    recortar_a_oracion_completa.

    El tercer criterio se agrego despues de la primera corrida que funciono, y
    la historia vale mas que el codigo: el bucle promovio cuatro veces seguidas
    mientras la politica se iba al portugues mezclado con ingles y chino. Las
    cuatro condiciones del gate dieron bien igual, porque ninguna miraba el
    idioma: el win-rate mejoraba (mas corta, con pasos numerados), la
    correccion mejoraba (los hechos aparecian como titulos de lista) y la tasa
    de degeneradas era cero (el texto no se repetia, simplemente no estaba en
    español).

    Es el caso de libro de optimizar la metrica en lugar del objetivo. La
    leccion no es que el criterio de idioma faltaba: es que SIEMPRE falta
    alguno, y por eso el presupuesto de divergencia existe. Fue lo unico que
    noto algo, en la ronda 5.
    """
    limpio = recortar_a_oracion_completa(texto)
    if len(limpio) < 20:
        return True
    oraciones = [o.strip() for o in re.split(r"[.!?]\s+", limpio) if o.strip()]
    if len(oraciones) >= 4 and len(set(oraciones)) / len(oraciones) < 0.6:
        return True
    if _GUARDARRAIL_IDIOMA and fraccion_fuera_de_idioma(limpio) > UMBRAL_FUERA_DE_IDIOMA:
        return True
    return False


def medir_rasgos(texto, hechos_clave):
    return {
        "longitud": float(contar_tokens(texto)),
        "pasos": tiene_pasos_numerados(texto),
        "cortesia": contar_cortesia(texto),
        "cobertura": cobertura_de_hechos(texto, hechos_clave),
        "fuera_de_idioma": fraccion_fuera_de_idioma(texto),
        "degenerada": 1.0 if es_degenerada(texto) else 0.0,
    }
