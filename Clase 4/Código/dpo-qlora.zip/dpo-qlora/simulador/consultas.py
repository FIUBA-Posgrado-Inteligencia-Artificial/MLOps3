"""
aca tenemos el banco de consultas de soporte tecnico
el producto ficticio es un router hogareño
- cada consulta trae sus hechos clave, que son lo que el oraculo usa para medir correccion
- y particion fija por hash (la misma consulta cae siempre en el mismo split)
"""

import hashlib
import json
import os

# aca tenemos quince averías de router, cada una viene con una 
# lista de hechos clave: los terminos que una respuesta correcta debería mencionar

# es la unica definición de "correcto" que tiene el sistema, el oráculo no entiende 
# de routers: mira si la respuesta contiene esos términos y con eso 

# esto (en un escenario real) seria un conjunto de evaluación curado por expertos

SINTOMAS = [
    ("no me anda el wifi despues de la actualizacion",
     ["reiniciar", "firmware", "banda 2.4"]),
    ("la señal se corta cada quince minutos",
     ["interferencia", "canal", "registro de eventos"]),
    ("no puedo entrar al panel de administracion",
     ["192.168.1.1", "credenciales", "restablecer"]),
    ("la velocidad bajo a la mitad",
     ["prueba de velocidad", "cable", "banda 5"]),
    ("el equipo se reinicia solo",
     ["temperatura", "fuente", "firmware"]),
    ("no reconoce el cable de fibra",
     ["puerto wan", "conector", "luz de estado"]),
    ("los dispositivos nuevos no se conectan",
     ["limite de dispositivos", "filtro mac", "dhcp"]),
    ("la red invitados no tiene internet",
     ["aislamiento", "dhcp", "regla de salida"]),
    ("perdi la clave del wifi",
     ["restablecer", "etiqueta inferior", "panel de administracion"]),
    ("el reenvio de puertos no funciona",
     ["nat", "ip fija", "cgnat"]),
    ("la vpn se desconecta al rato",
     ["mtu", "keepalive", "registro de eventos"]),
    ("hay mucha latencia en videollamadas",
     ["qos", "banda 5", "interferencia"]),
    ("el repetidor no toma la red principal",
     ["mismo ssid", "canal", "wps"]),
    ("no aparece la red de 5 ghz",
     ["banda 5", "region", "firmware"]),
    ("el control parental bloquea todo",
     ["horario", "perfil", "regla"]),
]

# esto cambia cómo se ve el texto, no cuál es la respuesta 
# correcta,  los hechos clave siguen siendo los del sintoma mencionado antes
# esto sirve para que el modelo vea redacciones distintas del mismo problema
CONTEXTOS = [
    "Soy usuario nuevo y no manejo terminos tecnicos.",
    "Ya probe reiniciar el equipo dos veces.",
    "Trabajo desde casa y necesito resolverlo hoy.",
    "El problema empezo despues de una tormenta electrica.",
    "Tengo tres equipos y solo falla uno.",
    "Me pasa solo de noche.",
    "El tecnico vino la semana pasada y no encontro nada.",
    "Uso el router provisto por el proveedor de internet.",
    "Tengo la ultima version de firmware instalada.",
    "El cableado de la casa es viejo.",
]

# al usar hash, esta funcion es determinista
#recoleccion: para fabricar los pares con los que se entrena
#evaluacion: para medir si el modelo nuevo es mejor (win rate)
#canary: para vigilar que no se haya roto nada

def _split_de(consulta_id):
    h = int(hashlib.sha256(consulta_id.encode()).hexdigest()[:8], 16) % 100
    if h < 15:
        return "canary"
    if h < 55:
        return "evaluacion"
    return "recoleccion"

'''
esto arma una lista de 750 diccionarios, combinando cada síntoma con cada contexto, cinco veces
15 síntomas × 10 contextos × 5 copias = 750

ejemplo:
{  "consulta_id": "q_00000",
  "texto": "no me anda el wifi despues de la actualizacion. Soy usuario nuevo y no manejo terminos tecnicos.",
  "hechos_clave": ["reiniciar", "firmware", "banda 2.4"],
  "split": "canary"
}
'''
def construir_banco():
    banco = []
    for i, (sintoma, hechos) in enumerate(SINTOMAS):
        for j, contexto in enumerate(CONTEXTOS):
            for k in range(5):
                cid = f"q_{i:02d}{j:02d}{k:d}"
                banco.append({
                    "consulta_id": cid,
                    "texto": f"{sintoma}. {contexto}",
                    "hechos_clave": hechos,
                    "split": _split_de(cid),
                })
    return banco


# Genera las 750 consultas y las guarda en data/consultas.jsonl, 
# una por línea en formato json, creando la carpeta data/ si hace falta
def escribir_banco(ruta="data/consultas.jsonl"):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    banco = construir_banco()
    with open(ruta, "w", encoding="utf-8") as f:
        for c in banco:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")
    return banco

# Lee el archivo y devuelve las 750 consultas como lista de diccionarios, 
# salteando las líneas vacías
def leer_banco(ruta="data/consultas.jsonl"):
    if not os.path.exists(ruta):
        return escribir_banco(ruta)
    with open(ruta, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


# Filtra el banco y devuelve solo las consultas de un 
# grupo ("canary", "evaluacion" o "recoleccion"), ordenadas por identificador
def por_split(banco, split, n=None):
    seleccion = [c for c in banco if c["split"] == split]
    seleccion.sort(key=lambda c: c["consulta_id"])
    return seleccion if n is None else seleccion[:n]


if __name__ == "__main__":
    banco = escribir_banco()
    conteo = {}
    for c in banco:
        conteo[c["split"]] = conteo.get(c["split"], 0) + 1
    print(f"consultas: {len(banco)}  {conteo}")
