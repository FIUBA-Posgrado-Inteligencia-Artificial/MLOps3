"""Calibracion de tau para llevar el acuerdo entre anotadores a [0.70, 0.80].

Un oraculo sin ruido convierte el TP en un ejercicio de ajuste de curvas: el
sistema aprende la funcion exacta en una ronda y no hay nada que medir. Un
oraculo demasiado ruidoso hace que ninguna diferencia sea detectable con el
presupuesto de evaluacion disponible.

Uso:
    python -m simulador.calibrar_oraculo
Escribe el tau elegido por pantalla. Copiarlo a configs/oraculo.yaml y
volver a correr para confirmar. Esto se hace UNA vez, antes del pre-registro.
"""

import statistics

from serving.plantillas import generar_par, politica_inicial
from simulador import consultas as bc
from simulador import oraculo as orc

OBJETIVO = (0.70, 0.80)


def acuerdo_con_tau(tau, cfg, banco, n=400, semilla=7):
    cfg = dict(cfg)
    cfg["tau"] = tau
    rng = orc.nuevo_rng(semilla)
    politica = politica_inicial()
    iguales = []
    for i in range(n):
        consulta = banco[i % len(banco)]
        par = {"prompt": "", "hechos_clave": consulta["hechos_clave"],
               "candidatos": generar_par(consulta, politica, rng.randrange(10 ** 9))}
        perfil = "didactico"
        a1 = orc.anotar(par, perfil, cfg, rng)
        a2 = orc.anotar(par, perfil, cfg, rng)
        iguales.append(1.0 if a1["id_elegido"] == a2["id_elegido"] else 0.0)
    return statistics.mean(iguales)


def buscar_tau(cfg, banco, bajo=0.2, alto=8.0, iteraciones=14):
    objetivo = sum(OBJETIVO) / 2
    for _ in range(iteraciones):
        medio = (bajo + alto) / 2
        a = acuerdo_con_tau(medio, cfg, banco)
        if a > objetivo:        # demasiado acuerdo: mas temperatura
            bajo = medio
        else:
            alto = medio
    return (bajo + alto) / 2


if __name__ == "__main__":
    cfg = orc.cargar_config()
    banco = bc.por_split(bc.leer_banco(), "recoleccion")
    print("tau actual:", cfg["tau"], "-> acuerdo:",
          round(acuerdo_con_tau(cfg["tau"], cfg, banco), 3))
    tau = buscar_tau(cfg, banco)
    print("tau sugerido:", round(tau, 3), "-> acuerdo:",
          round(acuerdo_con_tau(tau, cfg, banco), 3))
    print("rango objetivo:", OBJETIVO)
