"""Recoleccion de preferencias: una ronda a la vez.

Pide pares a la politica en produccion, los hace anotar por la poblacion de la
ronda y los escribe al store. Duplica una fraccion de los pares para poder
medir el acuerdo entre anotaciones independientes, que es lo que calibra el
ruido del oraculo.
"""

from serving.cliente import pedir_par
from simulador import oraculo as orc
from store import db


def recolectar_ronda(con, corrida, ronda, politica, cfg_or, cfg_exp,
                     semilla, banco_recoleccion, policy_version):
    rng = orc.nuevo_rng(semilla, ronda, sufijo=1)
    n_pares = cfg_exp["recoleccion"]["pares_por_ronda"]
    n_dup = cfg_exp["recoleccion"]["pares_duplicados"]
    temp = cfg_exp["recoleccion"]["temperatura_generacion"]
    fase = cfg_or["calendario"][ronda]["fase"]
    expone_segmento = ronda >= cfg_or["ronda_desde_la_que_se_expone_segmento"]

    acuerdos = []
    probabilidades = []

    for i in range(n_pares):
        consulta = banco_recoleccion[(ronda * n_pares + i) % len(banco_recoleccion)]
        prompt, candidatos, version = pedir_par(
            consulta, politica, semilla=rng.randrange(10 ** 9), temperatura=temp)
        par = {"prompt": prompt, "hechos_clave": consulta["hechos_clave"],
               "candidatos": candidatos}

        perfil = orc.perfil_de_la_ronda(ronda, cfg_or, rng)
        anotacion = orc.anotar(par, perfil, cfg_or, rng)
        probabilidades.append(anotacion["p_a"])

        # Identificador deterministico: si fuera aleatorio, el orden de
        # lectura del lote cambiaria entre corridas y el experimento dejaria
        # de ser reproducible aun con la misma semilla.
        par_id = f"{corrida}-r{ronda:03d}-{i:05d}"
        db.guardar_par(con, {
            "par_id": par_id,
            "consulta_id": consulta["consulta_id"],
            "prompt": prompt,
            "chosen": anotacion["chosen"],
            "rejected": anotacion["rejected"],
            "policy_version": policy_version or version,
            "ronda": ronda,
            "corrida": corrida,
            "fase_oraculo": fase,
            "perfil_anotador": perfil,
            "segmento": perfil if expone_segmento else None,
            "margen_utilidad": anotacion["margen_utilidad"],
            "es_duplicado": 0,
        })

        # Segunda anotacion independiente del mismo par, para medir acuerdo.
        if i < n_dup:
            perfil2 = orc.perfil_de_la_ronda(ronda, cfg_or, rng)
            anot2 = orc.anotar(par, perfil2, cfg_or, rng)
            acuerdos.append(1.0 if anot2["id_elegido"] == anotacion["id_elegido"] else 0.0)
            db.guardar_par(con, {
                "par_id": f"{corrida}-r{ronda:03d}-{i:05d}-dup",
                "consulta_id": consulta["consulta_id"],
                "prompt": prompt,
                "chosen": anot2["chosen"],
                "rejected": anot2["rejected"],
                "policy_version": policy_version or version,
                "ronda": ronda,
                "corrida": corrida,
                "fase_oraculo": fase,
                "perfil_anotador": perfil2,
                "segmento": perfil2 if expone_segmento else None,
                "margen_utilidad": anot2["margen_utilidad"],
                "es_duplicado": 1,
            })

    con.commit()
    return {
        "ronda": ronda,
        "pares": n_pares,
        "acuerdo_observado": sum(acuerdos) / len(acuerdos) if acuerdos else None,
        "acuerdo_esperado": orc.tasa_de_acuerdo_esperada(probabilidades),
    }
