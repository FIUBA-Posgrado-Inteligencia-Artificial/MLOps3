"""
Oraculo de preferencias
- en resumen es lo que nos dice qué repuesta es mejor
- es la ground truth del experimento
- deterministico dado (par, semilla), con ruido controlado
- no es un LLM juez, hace falta conocer exactamente la funcion
de utilidad para poder afirmar si el sistema aprendio lo correcto.
- el peso de la correccion es el mismo en todos los perfiles, lo unico que cambia entre fases es el estilo


Simula al revisor que etiqueta los pares: mira las respuestas candidatas a una consulta, le pone una nota a cada una
"""

import math
import random

import yaml

from simulador.rasgos import medir_rasgos

RASGOS_DE_ESTILO = ("longitud", "pasos", "cortesia")


def cargar_config(ruta="configs/oraculo.yaml"):
    with open(ruta, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    # El calendario se lee con claves enteras.
    cfg["calendario"] = {int(k): v for k, v in cfg["calendario"].items()}
    _verificar_invariantes(cfg)
    return cfg


def _verificar_invariantes(cfg):
    for nombre, pesos in cfg["perfiles"].items():
        sobrantes = set(pesos) - set(RASGOS_DE_ESTILO)
        if sobrantes:
            raise ValueError(
                f"el perfil '{nombre}' define pesos fuera del estilo: {sorted(sobrantes)}. "
                "La correccion no puede depender de la fase."
            )
    if cfg["peso_correccion"] <= 0:
        raise ValueError("peso_correccion debe ser positivo")


def _z(valor, estadisticos):
    return (valor - estadisticos["mu"]) / estadisticos["sigma"]

# qué tan buena le parece esta respuesta a este tipo de usuario
def utilidad(texto, hechos_clave, perfil, cfg, ruido=0.0):
    rasgos = medir_rasgos(texto, hechos_clave)
    norm = cfg["normalizacion"]
    pesos = cfg["perfiles"][perfil]

    u = cfg["peso_correccion"] * _z(rasgos["cobertura"], norm["cobertura"])
    for rasgo in RASGOS_DE_ESTILO:
        u += pesos[rasgo] * _z(rasgos[rasgo], norm[rasgo])
    # Una respuesta degenerada nunca puede ganar por estilo.
    if rasgos["degenerada"]:
        u -= 5.0
    return u + ruido


def probabilidad_de_elegir_a(u_a, u_b, tau):
    diferencia = (u_a - u_b) / tau
    diferencia = max(-40.0, min(40.0, diferencia))
    return 1.0 / (1.0 + math.exp(-diferencia))


def perfil_de_la_ronda(ronda, cfg, rng):
    p = cfg["calendario"][ronda]["p_didactico"]
    return "didactico" if rng.random() < p else "operativo"


def anotar(par, perfil, cfg, rng):
    """Devuelve la anotacion de un par por un anotador del perfil dado.

    `par` trae: prompt, hechos_clave, candidatos [{id, texto}, {id, texto}].
    """
    a, b = par["candidatos"]
    sigma = cfg["sigma_ruido"]
    u_a = utilidad(a["texto"], par["hechos_clave"], perfil, cfg, rng.gauss(0, sigma))
    u_b = utilidad(b["texto"], par["hechos_clave"], perfil, cfg, rng.gauss(0, sigma))
    p_a = probabilidad_de_elegir_a(u_a, u_b, cfg["tau"])
    elegido = a if rng.random() < p_a else b
    descartado = b if elegido is a else a
    return {
        "chosen": elegido["texto"],
        "rejected": descartado["texto"],
        "id_elegido": elegido["id"],
        "perfil": perfil,
        # Los dos campos siguientes son SOLO para el analisis post-hoc.
        # El sistema no puede leerlos: ver store/db.py, leer_pares_para_el_sistema.
        "margen_utilidad": abs(u_a - u_b),
        "p_a": p_a,
    }


def anotar_abanico(par, perfil, cfg, rng):
    """Anota un par eligiendo el mejor y el peor de k candidatos.

    Es best-of-n con n chico: el anotador ve k respuestas a la misma consulta,
    se queda con la que mas le gusta y descarta la que menos. El par que se
    guarda sigue teniendo la misma forma que antes (chosen, rejected), asi que
    nada aguas abajo cambia.

    Por que el mejor contra el peor y no dos al azar: lo que hace aprendible un
    par es el margen de utilidad entre sus dos lados. Con dos muestras del
    mismo prompt ese margen es ruido; con las dos puntas de un abanico de
    estilos es la preferencia. El ruido del anotador se mantiene: se suma antes
    de ordenar, asi que el anotador puede equivocarse de punta.

    `par` trae: prompt, hechos_clave, candidatos [{id, texto}, ...] (k >= 2).
    """
    sigma = cfg["sigma_ruido"]
    puntuados = [
        (utilidad(c["texto"], par["hechos_clave"], perfil, cfg, rng.gauss(0, sigma)), c)
        for c in par["candidatos"]
    ]
    puntuados.sort(key=lambda t: t[0], reverse=True)
    (u_alto, elegido), (u_bajo, descartado) = puntuados[0], puntuados[-1]
    return {
        "chosen": elegido["texto"],
        "rejected": descartado["texto"],
        "id_elegido": elegido["id"],
        "id_descartado": descartado["id"],
        "perfil": perfil,
        # Solo para analisis post-hoc: ver store/db.py.
        "margen_utilidad": u_alto - u_bajo,
        "p_a": probabilidad_de_elegir_a(u_alto, u_bajo, cfg["tau"]),
    }


def tasa_de_acuerdo_esperada(probabilidades):
    """Acuerdo entre dos anotaciones independientes del mismo par."""
    return sum(p * p + (1 - p) * (1 - p) for p in probabilidades) / len(probabilidades)


def nuevo_rng(semilla, ronda=0, sufijo=0):
    return random.Random((semilla * 1_000_003) + (ronda * 7919) + sufijo)
