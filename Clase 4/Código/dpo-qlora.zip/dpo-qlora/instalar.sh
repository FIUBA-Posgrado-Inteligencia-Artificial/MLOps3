#!/usr/bin/env bash
# Instalacion completa en un solo paso.
#
#   bash instalar.sh
#
# Crea el entorno virtual, instala lo necesario para el modo simulado,
# genera el banco de consultas y corre las pruebas. No instala MLflow ni
# usa Docker: para la demostracion no hacen falta.

set -e
cd "$(dirname "$0")"

echo "==> Verificando Python"
if ! command -v python3 > /dev/null; then
    echo "No encuentro python3. Instalalo desde python.org y volve a intentar."
    exit 1
fi
python3 --version

echo
echo "==> Creando el entorno virtual (.venv)"
python3 -m venv .venv
source .venv/bin/activate

echo
echo "==> Instalando dependencias (un par de minutos la primera vez)"
python -m pip install --quiet --upgrade pip
python -m pip install --quiet numpy scipy pyyaml matplotlib requests fastapi uvicorn pytest

echo
echo "==> Generando el banco de consultas"
python -m simulador.consultas

echo
echo "==> Corriendo las pruebas"
python -m pytest tests -q

echo
echo "======================================================================"
echo " Listo. Para trabajar, activa el entorno en cada terminal nueva con:"
echo
echo "     source .venv/bin/activate"
echo
echo " Y despues:"
echo
echo "     python -m orquestador.experimento --control bucle --semilla 11"
echo "     python -m orquestador.experimento --control bucle --semilla 11 --sabotear-gate"
echo "     python -m analisis.potencia"
echo "======================================================================"
