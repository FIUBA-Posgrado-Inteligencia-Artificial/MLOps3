"""Prueba de carga durante el cambio de adaptador.

Criterio de aceptacion de F1: el swap se completa en menos de 5 segundos y no
pierde ninguna peticion en vuelo. Se demuestra con esto, no con una afirmacion
en el informe.

Uso (con el servicio levantado):
    python -m serving.prueba_swap --url http://localhost:8000 \\
        --version adapter-r06 --ruta artefactos/bucle-s11-adapter-r06.json
"""

import argparse
import concurrent.futures as cf
import time

import requests


def golpear(url, n, resultados):
    for i in range(n):
        try:
            r = requests.post(f"{url}/chat",
                              json={"consulta": "no me anda el wifi",
                                    "hechos_clave": ["reiniciar"], "seed": i},
                              timeout=30)
            resultados.append(r.status_code)
        except Exception:                                  # noqa: BLE001
            resultados.append(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000")
    ap.add_argument("--version", required=True)
    ap.add_argument("--ruta", default=None)
    ap.add_argument("--hilos", type=int, default=8)
    ap.add_argument("--peticiones", type=int, default=40)
    args = ap.parse_args()

    resultados = []
    with cf.ThreadPoolExecutor(max_workers=args.hilos) as pool:
        futuros = [pool.submit(golpear, args.url, args.peticiones, resultados)
                   for _ in range(args.hilos)]
        time.sleep(0.5)
        inicio = time.time()
        r = requests.post(f"{args.url}/adaptador",
                          json={"version": args.version, "ruta": args.ruta},
                          timeout=60)
        segundos = time.time() - inicio
        r.raise_for_status()
        for f in futuros:
            f.result()

    errores = [c for c in resultados if c != 200]
    print(f"peticiones: {len(resultados)}  errores: {len(errores)}  "
          f"swap: {segundos:.2f} s")
    print("version activa:", requests.get(f"{args.url}/which", timeout=10).json())
    if errores or segundos > 5.0:
        raise SystemExit("criterio de aceptacion NO cumplido")
    print("criterio de aceptacion cumplido")


if __name__ == "__main__":
    main()
