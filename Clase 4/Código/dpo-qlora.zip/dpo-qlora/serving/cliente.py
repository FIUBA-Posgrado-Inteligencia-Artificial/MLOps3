"""Cliente unico de generacion.

El resto del sistema no sabe si detras hay un SLM o el generador del modo
simulado: pide pares y recibe pares. Cambiar de modo no toca ningun otro
modulo.
"""

import os

import requests

MODO = os.environ.get("MODO", "simulado")
URL = os.environ.get("SERVING_URL", "http://localhost:8000")


def pedir_par(consulta, politica, semilla, temperatura=0.85):
    if MODO == "real":
        r = requests.post(
            f"{URL}/pair",
            json={"consulta_id": consulta["consulta_id"],
                  "consulta": consulta["texto"],
                  "hechos_clave": consulta["hechos_clave"],
                  "seed": semilla, "temperatura": temperatura},
            timeout=180,
        )
        r.raise_for_status()
        datos = r.json()
        return datos["prompt"], datos["candidatos"], datos["policy_version"]

    from serving.plantillas import generar_par
    prompt = f"<|user|>\n{consulta['texto']}\n<|assistant|>\n"
    return prompt, generar_par(consulta, politica, semilla, temperatura), \
        politica.get("_version", "local")


def pedir_respuesta(consulta, politica, semilla, temperatura=0.7):
    if MODO == "real":
        r = requests.post(
            f"{URL}/chat",
            json={"consulta": consulta["texto"],
                  "hechos_clave": consulta["hechos_clave"],
                  "seed": semilla, "temperatura": temperatura},
            timeout=180,
        )
        r.raise_for_status()
        return r.json()["respuesta"]

    from serving.plantillas import generar
    return generar(consulta, politica, semilla, temperatura)


def activar_adaptador(version, ruta=None, hash_lote=None):
    if MODO != "real":
        return {"adaptador": version, "segundos": 0.0}
    r = requests.post(f"{URL}/adaptador",
                      json={"version": version, "ruta": ruta, "hash_lote": hash_lote},
                      timeout=120)
    r.raise_for_status()
    return r.json()
