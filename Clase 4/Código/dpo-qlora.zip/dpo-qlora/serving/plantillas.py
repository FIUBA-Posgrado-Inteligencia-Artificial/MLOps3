"""Generador de respuestas del modo simulado.

Sustituye al SLM para poder desarrollar y probar el andamiaje completo (store,
detector, gate, orquestador, rollback) sin GPU. La "politica" es un vector de
estilo; el texto se arma a partir de el y despues el oraculo lo mide leyendo el
texto, igual que haria con la salida de un modelo real.

No es el entregable: el experimento del informe se corre en modo real. Sirve
para que el bucle se pueda depurar en segundos en vez de en horas, y para que
los tests corran en integracion continua.
"""

import random

POLITICA_INICIAL = {
    "longitud_objetivo": 105.0,
    "p_pasos": 0.30,
    "p_cortesia": 0.55,
    "cobertura_objetivo": 0.70,
}

APERTURAS_CORTESES = [
    "Gracias por escribir, entiendo que es molesto.",
    "Con gusto te ayudo con esto.",
    "Lamento el inconveniente, vamos a resolverlo.",
]

CIERRES_CORTESES = [
    "Quedo a disposicion si el problema sigue.",
    "No dudes en escribir de nuevo si persiste.",
    "Espero que esto lo resuelva.",
]

RELLENO = [
    "Este comportamiento suele deberse a la configuracion de la red local.",
    "Conviene descartar primero las causas mas simples antes de avanzar.",
    "En la mayoria de los casos el problema aparece solo bajo cierta carga.",
    "El equipo guarda un historial que ayuda a ubicar el momento exacto de la falla.",
    "Si el sintoma cambia despues de cada prueba, conviene anotar que se modifico.",
    "Tener a mano el modelo exacto del equipo acelera el diagnostico.",
]

ACCIONES = [
    "revisar el estado de las luces del equipo",
    "anotar la hora exacta en que ocurre",
    "probar con un solo dispositivo conectado",
    "comparar el comportamiento con cable y sin cable",
    "dejar el equipo apagado un minuto completo",
]


def politica_inicial():
    return dict(POLITICA_INICIAL)


def _oracion_con_hecho(hecho):
    return f"Verifica lo relacionado con {hecho} antes de seguir."


def generar(consulta, politica, semilla, temperatura=0.85):
    """Arma una respuesta a partir del vector de estilo de la politica."""
    rng = random.Random(semilla)
    ruido = temperatura

    objetivo = max(25.0, rng.gauss(politica["longitud_objetivo"],
                                   0.22 * ruido * politica["longitud_objetivo"]))
    con_pasos = rng.random() < politica["p_pasos"]
    con_cortesia = rng.random() < politica["p_cortesia"]
    p_cobertura = min(1.0, max(0.0, rng.gauss(politica["cobertura_objetivo"],
                                              0.12 * ruido)))

    partes = []
    if con_cortesia:
        partes.append(rng.choice(APERTURAS_CORTESES))

    hechos = [h for h in consulta["hechos_clave"] if rng.random() < p_cobertura]
    if con_pasos:
        pasos = [f"{i + 1}. {_oracion_con_hecho(h)}" for i, h in enumerate(hechos)]
        while len(pasos) < 2:
            pasos.append(f"{len(pasos) + 1}. Es util {rng.choice(ACCIONES)}.")
        partes.append("\n".join(pasos))
    else:
        partes.extend(_oracion_con_hecho(h) for h in hechos)
        if not hechos:
            partes.append(f"Como primer paso conviene {rng.choice(ACCIONES)}.")

    # Relleno hasta acercarse a la longitud objetivo.
    while len(" ".join(partes).split()) < objetivo:
        partes.append(rng.choice(RELLENO))
        if len(partes) > 40:
            break

    if con_cortesia:
        partes.append(rng.choice(CIERRES_CORTESES))

    texto = "\n".join(partes).strip()
    if not texto.endswith((".", "!", "?", ":")):
        texto += "."
    return texto


def generar_par(consulta, politica, semilla, temperatura=0.85):
    return [
        {"id": "a", "texto": generar(consulta, politica, semilla * 2 + 1, temperatura),
         "params": {"temp": temperatura, "seed": semilla * 2 + 1}},
        {"id": "b", "texto": generar(consulta, politica, semilla * 2 + 2, temperatura),
         "params": {"temp": temperatura, "seed": semilla * 2 + 2}},
    ]
