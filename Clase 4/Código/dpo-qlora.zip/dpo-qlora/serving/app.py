"""Servicio de inferencia con adaptador intercambiable en caliente.

El modelo base se carga una sola vez. El adaptador LoRA se cambia sin reiniciar
el proceso y sin recargar los pesos base: las peticiones en vuelo terminan con
la version que tenian, las nuevas esperan al swap. Cero 5xx durante el cambio.

Endpoints
    POST /chat       una respuesta
    POST /pair       dos candidatos con semillas distintas (contrato del TP)
    POST /adaptador  carga una version del registry y la activa
    GET  /which      version activa, hash del lote que la produjo
    GET  /health     readiness real: 503 si el adaptador no esta cargado
"""

import asyncio
import os
import time

import yaml
from fastapi import Body, FastAPI, HTTPException, Response

MODO = os.environ.get("MODO", "simulado")
CONFIG = yaml.safe_load(open(os.environ.get("CONFIG_DPO", "configs/dpo.yaml"),
                             encoding="utf-8"))

app = FastAPI(title="serving-dpo-continuo")

# Estado del proceso. Sin clases: un diccionario de modulo y un lock.
ESTADO = {
    "modelo": None,
    "tokenizador": None,
    "adaptador": None,          # nombre de la version activa
    "hash_lote": None,
    "politica": None,           # modo simulado: vector de estilo
    "cargado_en": None,
    "en_vuelo": 0,
    "listo": False,
}
CERROJO = asyncio.Lock()


# --------------------------------------------------------------------------
# Carga
# --------------------------------------------------------------------------

def _cargar_base_real():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    cuant = CONFIG["cuantizacion"]
    bnb = BitsAndBytesConfig(
        load_in_4bit=cuant["cargar_en_4bits"],
        bnb_4bit_quant_type=cuant["tipo_cuantizacion"],
        bnb_4bit_use_double_quant=cuant["doble_cuantizacion"],
        bnb_4bit_compute_dtype=getattr(torch, cuant["dtype_computo"]),
    )
    tok = AutoTokenizer.from_pretrained(CONFIG["modelo_base"])
    modelo = AutoModelForCausalLM.from_pretrained(
        CONFIG["modelo_base"], quantization_config=bnb, device_map="auto")
    modelo.eval()
    return modelo, tok


@app.on_event("startup")
async def arrancar():
    if MODO == "real":
        ESTADO["modelo"], ESTADO["tokenizador"] = _cargar_base_real()
        ESTADO["adaptador"] = "base"
    else:
        from serving.plantillas import politica_inicial
        ESTADO["politica"] = politica_inicial()
        ESTADO["adaptador"] = "base"
    ESTADO["cargado_en"] = time.time()
    ESTADO["listo"] = True


# --------------------------------------------------------------------------
# Generacion
# --------------------------------------------------------------------------

def _generar_real(consulta, semilla, temperatura):
    import torch

    tok = ESTADO["tokenizador"]
    mensajes = [
        {"role": "system", "content": "Sos soporte tecnico. Responde en español."},
        {"role": "user", "content": consulta["texto"]},
    ]
    prompt = tok.apply_chat_template(mensajes, tokenize=False,
                                     add_generation_prompt=True)
    entradas = tok(prompt, return_tensors="pt").to(ESTADO["modelo"].device)
    torch.manual_seed(semilla)
    with torch.no_grad():
        salida = ESTADO["modelo"].generate(
            **entradas,
            do_sample=True,
            temperature=temperatura,
            top_p=CONFIG["generacion"]["top_p"],
            max_new_tokens=CONFIG["generacion"]["max_new_tokens"],
            repetition_penalty=CONFIG["generacion"]["repetition_penalty"],
            pad_token_id=tok.eos_token_id,
        )
    nuevo = salida[0][entradas["input_ids"].shape[1]:]
    return prompt, tok.decode(nuevo, skip_special_tokens=True).strip()


def _generar_simulado(consulta, semilla, temperatura):
    from serving.plantillas import generar
    prompt = f"<|user|>\n{consulta['texto']}\n<|assistant|>\n"
    return prompt, generar(consulta, ESTADO["politica"], semilla, temperatura)


def generar_una(consulta, semilla, temperatura):
    if MODO == "real":
        return _generar_real(consulta, semilla, temperatura)
    return _generar_simulado(consulta, semilla, temperatura)


# --------------------------------------------------------------------------
# Endpoints
# --------------------------------------------------------------------------

@app.get("/health")
async def health(response: Response):
    if not ESTADO["listo"]:
        raise HTTPException(status_code=503, detail="adaptador no cargado")
    return {"estado": "listo", "modo": MODO, "en_vuelo": ESTADO["en_vuelo"]}


@app.get("/which")
async def which():
    return {
        "adaptador": ESTADO["adaptador"],
        "hash_lote": ESTADO["hash_lote"],
        "modelo_base": CONFIG["modelo_base"],
        "cargado_en": ESTADO["cargado_en"],
        "modo": MODO,
    }


@app.post("/chat")
async def chat(cuerpo: dict = Body(...)):
    async with CERROJO:
        ESTADO["en_vuelo"] += 1
    try:
        consulta = {"texto": cuerpo["consulta"],
                    "hechos_clave": cuerpo.get("hechos_clave", [])}
        _, texto = generar_una(consulta, cuerpo.get("seed", 0),
                               cuerpo.get("temperatura", 0.85))
        return {"respuesta": texto, "policy_version": ESTADO["adaptador"]}
    finally:
        async with CERROJO:
            ESTADO["en_vuelo"] -= 1


@app.post("/pair")
async def pair(cuerpo: dict = Body(...)):
    async with CERROJO:
        ESTADO["en_vuelo"] += 1
    try:
        consulta = {"texto": cuerpo["consulta"],
                    "hechos_clave": cuerpo.get("hechos_clave", [])}
        semilla = int(cuerpo.get("seed", 0))
        temp = float(cuerpo.get("temperatura", 0.85))
        prompt, a = generar_una(consulta, semilla * 2 + 1, temp)
        _, b = generar_una(consulta, semilla * 2 + 2, temp)
        return {
            "consulta_id": cuerpo.get("consulta_id"),
            "consulta": cuerpo["consulta"],
            "prompt": prompt,
            "candidatos": [
                {"id": "a", "texto": a, "params": {"temp": temp, "seed": semilla * 2 + 1}},
                {"id": "b", "texto": b, "params": {"temp": temp, "seed": semilla * 2 + 2}},
            ],
            "policy_version": ESTADO["adaptador"],
            "base_model": CONFIG["modelo_base"],
        }
    finally:
        async with CERROJO:
            ESTADO["en_vuelo"] -= 1


@app.post("/adaptador")
async def cambiar_adaptador(cuerpo: dict = Body(...)):
    """Swap en caliente. Espera a que no queden peticiones en vuelo."""
    version = cuerpo["version"]
    ruta = cuerpo.get("ruta")
    inicio = time.time()

    async with CERROJO:
        espera = 0.0
        while ESTADO["en_vuelo"] > 0 and espera < 5.0:
            await asyncio.sleep(0.02)
            espera += 0.02

        try:
            if MODO == "real":
                from peft import PeftModel
                base = getattr(ESTADO["modelo"], "base_model", None)
                if base is not None and hasattr(ESTADO["modelo"], "unload"):
                    ESTADO["modelo"] = ESTADO["modelo"].unload()
                if version != "base":
                    ESTADO["modelo"] = PeftModel.from_pretrained(ESTADO["modelo"], ruta)
                    ESTADO["modelo"].eval()
            else:
                import json
                if version == "base":
                    from serving.plantillas import politica_inicial
                    ESTADO["politica"] = politica_inicial()
                else:
                    with open(ruta, encoding="utf-8") as f:
                        ESTADO["politica"] = json.load(f)["politica"]
        except Exception as e:                       # noqa: BLE001
            ESTADO["listo"] = False
            raise HTTPException(status_code=503, detail=f"fallo la carga: {e}")

        ESTADO["adaptador"] = version
        ESTADO["hash_lote"] = cuerpo.get("hash_lote")
        ESTADO["cargado_en"] = time.time()
        ESTADO["listo"] = True

    return {"adaptador": version, "segundos": round(time.time() - inicio, 3)}
