"""Evaluacion offline de dos politicas sobre el conjunto retenido.

El conjunto de evaluacion y el canary nunca entran al entrenamiento. El chequeo
de contaminacion esta automatizado en verificar_fuga(): si alguna consulta de
evaluacion aparecio en un lote de entrenamiento, el pipeline corta.
"""

import numpy as np

from gate import estadistica as est
from serving.cliente import pedir_respuesta
from simulador import oraculo as orc
from simulador.rasgos import medir_rasgos


def _respuestas(politica, consultas, semilla, temperatura=0.7, generador=None):
    """Genera una respuesta por consulta.

    `generador` permite inyectar el motor de generacion. En modo simulado y en
    modo real por HTTP se usa el cliente; el bucle real de Colab pasa su propia
    funcion, que genera por lotes en GPU dentro del mismo proceso.
    """
    if generador is not None:
        return generador(politica, consultas, semilla)
    rng = orc.nuevo_rng(semilla, sufijo=3)
    return [pedir_respuesta(c, politica, rng.randrange(10 ** 9), temperatura)
            for c in consultas]


def comparar(politica_a, politica_b, consultas, cfg_or, p_didactico,
             semilla, replicas=10000, alfa=0.05, generador=None,
             unilateral=False):
    """Win-rate de A sobre B segun el oraculo, con la poblacion de la ronda."""
    rng = orc.nuevo_rng(semilla, sufijo=5)
    resp_a = _respuestas(politica_a, consultas, semilla + 1, generador=generador)
    resp_b = _respuestas(politica_b, consultas, semilla + 2, generador=generador)

    indicadores, longitudes_a, u_a_todas, u_b_todas = [], [], [], []
    for consulta, ta, tb in zip(consultas, resp_a, resp_b):
        perfil = "didactico" if rng.random() < p_didactico else "operativo"
        sigma = cfg_or["sigma_ruido"]
        ua = orc.utilidad(ta, consulta["hechos_clave"], perfil, cfg_or, rng.gauss(0, sigma))
        ub = orc.utilidad(tb, consulta["hechos_clave"], perfil, cfg_or, rng.gauss(0, sigma))
        p = orc.probabilidad_de_elegir_a(ua, ub, cfg_or["tau"])
        indicadores.append(1.0 if rng.random() < p else 0.0)
        longitudes_a.append(medir_rasgos(ta, consulta["hechos_clave"])["longitud"])
        u_a_todas.append(ua)
        u_b_todas.append(ub)

    boot = est.bootstrap_pareado(indicadores, replicas=replicas, alfa=alfa,
                                 semilla=semilla, unilateral=unilateral)
    wil = est.wilcoxon_pareado(u_a_todas, u_b_todas)
    degeneradas = np.mean([medir_rasgos(t, [])["degenerada"] for t in resp_a])
    return {
        "win_rate": boot["media"],
        "ic": boot["ic"],
        "n": boot["n"],
        "p_wilcoxon": wil["p"],
        "longitud_media": float(np.mean(longitudes_a)),
        "tasa_degeneradas": float(degeneradas),
        "indicadores": indicadores,
        "respuestas_a": resp_a,
    }


def correccion(politica, canary, semilla, generador=None):
    """Cobertura de hechos clave. Es la metrica que protege de reward hacking."""
    respuestas = _respuestas(politica, canary, semilla + 9, generador=generador)
    cobertura = [medir_rasgos(t, c["hechos_clave"])["cobertura"]
                 for t, c in zip(respuestas, canary)]
    aciertos = [1 if v >= 0.5 else 0 for v in cobertura]
    return {"cobertura_media": float(np.mean(cobertura)),
            "tasa_acierto": float(np.mean(aciertos)),
            "aciertos": aciertos}


def regresion_de_correccion(aciertos_nuevo, aciertos_viejo):
    b = sum(1 for n, v in zip(aciertos_nuevo, aciertos_viejo) if n == 1 and v == 0)
    c = sum(1 for n, v in zip(aciertos_nuevo, aciertos_viejo) if n == 0 and v == 1)
    prueba = est.mcnemar(b, c)
    caida = (sum(aciertos_viejo) - sum(aciertos_nuevo)) / max(1, len(aciertos_viejo))
    return {"caida": float(caida), "p_mcnemar": prueba["p"],
            "discordantes": prueba["discordantes"]}


def divergencia(politica_nueva, politica_referencia):
    """Modo simulado: proxy de KL sobre el vector de estilo, normalizado.

    En modo real esto se reemplaza por la KL implicita que loguea el DPOTrainer;
    el proxy existe para que el gate tenga la misma forma en los dos modos, y en
    el informe se reporta como proxy, nunca como KL.
    """
    escala = {"longitud_objetivo": 60.0, "p_pasos": 1.0,
              "p_cortesia": 1.0, "cobertura_objetivo": 1.0}
    total = 0.0
    for clave, s in escala.items():
        total += ((politica_nueva[clave] - politica_referencia[clave]) / s) ** 2
    return float(np.sqrt(total))


def verificar_fuga(pares_entrenamiento, consultas_evaluacion):
    ids_eval = {c["consulta_id"] for c in consultas_evaluacion}
    contaminados = sorted({p["consulta_id"] for p in pares_entrenamiento
                           if p["consulta_id"] in ids_eval})
    if contaminados:
        raise RuntimeError(
            f"fuga del conjunto de evaluacion: {len(contaminados)} consultas "
            f"aparecen en el lote de entrenamiento, por ejemplo {contaminados[:3]}")
    return True
