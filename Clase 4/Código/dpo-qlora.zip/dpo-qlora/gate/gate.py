"""Gate de promocion: automatico y numerico.

Las cuatro condiciones son conjuntivas. Si el gate no bloqueo nada en doce
rondas, el gate no existe: esta mal calibrado o no esta conectado. Eso se
corrige como si faltara.
"""


def decidir(metricas, cfg_gate):
    causas = []

    ic_inferior = metricas["ic"][0]
    if not ic_inferior > cfg_gate["win_rate_ic_inferior"]:
        causas.append(
            f"win-rate sin evidencia: IC95 inferior {ic_inferior:.3f} "
            f"<= {cfg_gate['win_rate_ic_inferior']:.2f}")

    caida = metricas["caida_correccion"]
    if caida > cfg_gate["caida_maxima_correccion"]:
        causas.append(
            f"regresion de correccion: caida {caida:.3f} > "
            f"{cfg_gate['caida_maxima_correccion']:.3f} "
            f"(p McNemar {metricas.get('p_mcnemar', float('nan')):.3f})")

    if metricas["divergencia"] > cfg_gate["presupuesto_kl"]:
        causas.append(
            f"fuera del presupuesto de divergencia: {metricas['divergencia']:.3f} "
            f"> {cfg_gate['presupuesto_kl']:.3f}")

    if metricas["tasa_degeneradas"] >= cfg_gate["tasa_maxima_degeneradas"]:
        causas.append(
            f"colapso de formato: {metricas['tasa_degeneradas']:.3f} respuestas "
            f"degeneradas")

    return {"aprueba": not causas, "causas": causas}


def hay_que_revertir(metricas_post, cfg_gate):
    """Se revierte si la version recien promovida empeora en la ronda siguiente."""
    if metricas_post["ic"][1] < 0.50:
        return True, (f"la version promovida pierde contra la anterior "
                      f"(IC95 superior {metricas_post['ic'][1]:.3f} < 0.50)")
    if metricas_post["caida_correccion"] > cfg_gate["caida_maxima_correccion"]:
        return True, (f"correccion degradada tras promover: "
                      f"{metricas_post['caida_correccion']:.3f}")
    return False, None
