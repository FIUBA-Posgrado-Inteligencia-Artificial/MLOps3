"""Estadistica del TP. Todo lo que el informe afirme sale de aca.

Nada de comparar promedios a ojo: comparaciones pareadas, intervalos por
bootstrap sobre consultas, y correccion por multiplicidad cuando hay mas de
una hipotesis.
"""

import math

import numpy as np
from scipy import stats


def bootstrap_pareado(indicadores, replicas=10000, alfa=0.05, semilla=0,
                      unilateral=False):
    """IC percentil para la media de indicadores pareados (1 gana A, 0 gana B, 0.5 empate).

    El remuestreo es sobre CONSULTAS, no sobre respuestas: cada consulta aporta
    una observacion y es la unidad independiente del diseño.

    `unilateral=True` pone toda la masa de error en la cola de abajo. Es lo
    correcto cuando la hipotesis es direccional ("el candidato es MEJOR") y no
    bilateral ("es distinto"), que es exactamente lo que pregunta el gate. Gana
    potencia sin relajar el nivel de significacion: con n=200, el efecto minimo
    detectable baja de 0.605 a 0.595 y la potencia para un efecto real de 0.60
    sube de 0.59 a 0.86. La decision va declarada en el pre-registro.
    """
    x = np.asarray(indicadores, dtype=float)
    if x.size == 0:
        return {"media": float("nan"), "ic": (float("nan"), float("nan")), "n": 0}
    rng = np.random.default_rng(semilla)
    idx = rng.integers(0, x.size, size=(replicas, x.size))
    medias = x[idx].mean(axis=1)
    if unilateral:
        li, ls = np.percentile(medias, [100 * alfa, 100.0])
    else:
        li, ls = np.percentile(medias, [100 * alfa / 2, 100 * (1 - alfa / 2)])
    return {"media": float(x.mean()), "ic": (float(li), float(ls)), "n": int(x.size)}


def mcnemar(a_bien_b_mal, a_mal_b_bien):
    """Test exacto de McNemar (binomial) sobre pares discordantes."""
    n = a_bien_b_mal + a_mal_b_bien
    if n == 0:
        return {"p": 1.0, "discordantes": 0}
    k = min(a_bien_b_mal, a_mal_b_bien)
    p = min(1.0, 2 * stats.binom.cdf(k, n, 0.5))
    return {"p": float(p), "discordantes": int(n)}


def wilcoxon_pareado(x, y):
    d = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    if np.allclose(d, 0):
        return {"estadistico": 0.0, "p": 1.0}
    res = stats.wilcoxon(d, zero_method="wilcox", alternative="two-sided")
    return {"estadistico": float(res.statistic), "p": float(res.pvalue)}


def holm_bonferroni(pvalores, alfa=0.05):
    """Devuelve, para cada p en el orden de entrada, si se rechaza y su p ajustado."""
    m = len(pvalores)
    orden = sorted(range(m), key=lambda i: pvalores[i])
    ajustados = [0.0] * m
    acumulado = 0.0
    for rango, i in enumerate(orden):
        valor = min(1.0, (m - rango) * pvalores[i])
        acumulado = max(acumulado, valor)     # monotonia
        ajustados[i] = acumulado
    return [{"p": pvalores[i], "p_ajustado": ajustados[i],
             "rechaza": ajustados[i] < alfa} for i in range(m)]


def potencia_pareada(p_verdadera, n, alfa=0.05, replicas=4000, semilla=0):
    """Potencia simulada para detectar win-rate distinto de 0.5 con n consultas."""
    rng = np.random.default_rng(semilla)
    exitos = rng.binomial(n, p_verdadera, size=replicas)
    p_valores = 2 * np.minimum(
        stats.binom.cdf(exitos, n, 0.5),
        stats.binom.sf(exitos - 1, n, 0.5))
    return float(np.mean(np.minimum(p_valores, 1.0) < alfa))


def n_para_potencia(p_verdadera, potencia_objetivo=0.80, alfa=0.05,
                    n_min=30, n_max=6000):
    """Menor n que alcanza la potencia objetivo. Busqueda binaria sobre n."""
    bajo, alto = n_min, n_max
    if potencia_pareada(p_verdadera, alto, alfa) < potencia_objetivo:
        return None
    while bajo < alto:
        medio = (bajo + alto) // 2
        if potencia_pareada(p_verdadera, medio, alfa) >= potencia_objetivo:
            alto = medio
        else:
            bajo = medio + 1
    return bajo


def efecto_minimo_detectable(n, potencia_objetivo=0.80, alfa=0.05, paso=0.005):
    """Si el n esta limitado por el presupuesto, esto es lo que hay que declarar."""
    p = 0.50
    while p < 0.95:
        p += paso
        if potencia_pareada(p, n, alfa) >= potencia_objetivo:
            return round(p, 4)
    return None


def psi(referencia, actual, bins=10):
    """Population Stability Index entre dos muestras continuas."""
    ref = np.asarray(referencia, dtype=float)
    act = np.asarray(actual, dtype=float)
    if ref.size == 0 or act.size == 0:
        return 0.0
    cortes = np.unique(np.quantile(ref, np.linspace(0, 1, bins + 1)))
    if cortes.size < 3:
        return 0.0
    cortes[0], cortes[-1] = -np.inf, np.inf
    p_ref, _ = np.histogram(ref, bins=cortes)
    p_act, _ = np.histogram(act, bins=cortes)
    p_ref = np.maximum(p_ref / max(1, p_ref.sum()), 1e-6)
    p_act = np.maximum(p_act / max(1, p_act.sum()), 1e-6)
    return float(np.sum((p_act - p_ref) * np.log(p_act / p_ref)))


def ks(referencia, actual):
    if len(referencia) == 0 or len(actual) == 0:
        return {"estadistico": 0.0, "p": 1.0}
    res = stats.ks_2samp(referencia, actual)
    return {"estadistico": float(res.statistic), "p": float(res.pvalue)}


def media_y_ic_normal(valores, alfa=0.05):
    x = np.asarray(valores, dtype=float)
    if x.size < 2:
        return {"media": float(x.mean()) if x.size else float("nan"),
                "ic": (float("nan"), float("nan"))}
    z = stats.norm.ppf(1 - alfa / 2)
    er = x.std(ddof=1) / math.sqrt(x.size)
    return {"media": float(x.mean()),
            "ic": (float(x.mean() - z * er), float(x.mean() + z * er))}
